package rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.aktivnosti;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DodajKategorijuAkt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(rma.etf.unsa.ba.spirala1.R.layout.activity_dodaj_kategoriju_akt);
    }
}
