package rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

import rma.etf.unsa.ba.spirala1.R;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.Kategorija;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.Kviz;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.Pitanje;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.PitanjeAdapter;
import rma.etf.unsa.ba.spirala1.ba.unsa.etf.rma.klase.SpinnerAdapter;

public class DodajKvizAkt extends AppCompatActivity {

    private ArrayList<Pitanje> razlikeUPitanjima(ArrayList<Pitanje> uKvizu, ArrayList<Pitanje> svaPitanja) {
        ArrayList<Pitanje> povratna = new ArrayList<>(svaPitanja);
        //povratna.removeAll(uKvizu);
        for(int i = 0; i < uKvizu.size(); i++)
            for(int j = 0; j < povratna.size(); j++)
                if(uKvizu.get(i).equals(povratna.get(j)))
                    povratna.remove(j);
        return povratna;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(rma.etf.unsa.ba.spirala1.R.layout.activity_dodaj_kviz_akt);
        final int position;
        final Kviz kviz;
        final ArrayList<Kategorija> kategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("Kategorije");
        final ArrayList<Pitanje> svaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("SvaPitanja");
        final ArrayList<Kviz> sviKvizovi = (ArrayList<Kviz>)getIntent().getSerializableExtra("SviKvizovi");
        final boolean novi = getIntent().getBooleanExtra("Novi", false);
        final ArrayList<Pitanje> pitanjaNisuUKvizu;




        Spinner spinnerKategorije = findViewById(R.id.spKategorije);
        final TextView textViewNaziv = findViewById(R.id.etNaziv);
        ListView pitanjaUKvizu = findViewById(R.id.lvDodanaPitanja);
        ListView pitanjaVanKviza = findViewById(R.id.lvMogucaPitanja);
        final Button dodajKviz = findViewById(R.id.btnDodajKviz);

        if(!novi) {
            kviz = (Kviz) sviKvizovi.get(getIntent().getIntExtra("Indeks", 0));
            pitanjaNisuUKvizu = razlikeUPitanjima(kviz.getPitanja(), svaPitanja);
            textViewNaziv.setText(kviz.getNaziv());
        }
        else {
            kviz = new Kviz(null, new ArrayList<Pitanje>(), kategorije.get(0));
            pitanjaNisuUKvizu = svaPitanja;
        }

        SpinnerAdapter kategorijeAdapter = new SpinnerAdapter(this, R.layout.kviz_list_item, kategorije);
        final PitanjeAdapter pitanjaAdapter = new PitanjeAdapter(this, R.layout.kviz_list_item, kviz.getPitanja());
        final PitanjeAdapter svaPitanjaAdapter = new PitanjeAdapter(this, R.layout.kviz_list_item, pitanjaNisuUKvizu);


        spinnerKategorije.setAdapter(kategorijeAdapter);
        kategorijeAdapter.notifyDataSetChanged();
        pitanjaUKvizu.setAdapter(pitanjaAdapter);
        pitanjaVanKviza.setAdapter(svaPitanjaAdapter);


        pitanjaVanKviza.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(pitanjaNisuUKvizu.get(position).getId() != 0) {
                    kviz.getPitanja().add(pitanjaNisuUKvizu.get(position));
                    pitanjaNisuUKvizu.remove(position);
                    pitanjaAdapter.notifyDataSetChanged();
                    svaPitanjaAdapter.notifyDataSetChanged();
                }
                else {
                    Intent novoPitanje = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    novoPitanje.putExtra("SvaPitanja", svaPitanja);
                    startActivityForResult(novoPitanje, 0);
                }
            }
        });

        pitanjaUKvizu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pitanjaNisuUKvizu.add(kviz.getPitanja().get(position));
                kviz.getPitanja().remove(position);
                pitanjaAdapter.notifyDataSetChanged();
                svaPitanjaAdapter.notifyDataSetChanged();
            }
        });

        dodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int indeks;
                boolean valid = true;
                kviz.setNaziv(textViewNaziv.getText().toString());

                for(int i = 0; i < sviKvizovi.size(); i++){
                    if(sviKvizovi.get(i).getNaziv().equals(kviz.getNaziv()) && sviKvizovi.get(i).getId() != kviz.getId())
                        valid = false;
                }
                if(novi)
                    sviKvizovi.add(0, kviz);

                if(valid) {
                    sviKvizovi.remove(getIntent().getIntExtra("Indeks", 0));
                    sviKvizovi.add(getIntent().getIntExtra("Indeks", 0), kviz);
                    Intent povratni = new Intent();
                    povratni.putExtra("SvaPitanja", svaPitanja);
                    povratni.putExtra("SviKvizovi", sviKvizovi);
                    povratni.putExtra("Kategorije", kategorije);
                    setResult(RESULT_OK, povratni);
                    finish();
                }
                else{
                    textViewNaziv.setBackgroundColor(getColor(R.color.red));
                }
            }
        });
    }
}
