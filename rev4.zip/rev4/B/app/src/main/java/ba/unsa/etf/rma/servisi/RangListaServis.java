package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;
import android.util.Pair;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Konverzija;

public class RangListaServis extends IntentService {

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;
    Bundle bundle = new Bundle();

    public RangListaServis() {
        super(null);
    }
    public RangListaServis(String name) {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }
    @Override
    public void onCreate() {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }
    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver resultReceiver = intent.getParcelableExtra("RISIVER");
        String ime = intent.getStringExtra("IME");
        Double procenat = intent.getDoubleExtra("PROCENAT", 0);
        String kviz = intent.getStringExtra("KVIZ");
        ArrayList<Pair<String, Double>> listaParova = new ArrayList<>();

        try{

            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            String TOKEN = credentials.getAccessToken();
            Log.d("TOKEN", TOKEN);

            URL urlObj;
            HttpURLConnection urlConnection;
            String nazivKviza = URLEncoder.encode(kviz,"utf-8");
            try{
                String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Rangliste/" + nazivKviza + "?access_token=";
                urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = Konverzija.convertStreamToString(in);
                Log.d("REZULTAT", rezultat);
                JSONObject jo = new JSONObject(rezultat);

                Log.d("RangLista", "POSTOJI");
                //vadi se sve
                try {
                    JSONObject polja1 = jo.getJSONObject("fields");

                    JSONObject nazivKvizaHelp = polja1.getJSONObject("nazivKviza");
                    nazivKviza = nazivKvizaHelp.getString("stringValue");

                    JSONObject lista = polja1.getJSONObject("lista");
                    JSONObject mapa1 = lista.getJSONObject("mapValue");
                    JSONObject polja2 = mapa1.getJSONObject("fields");

                    boolean ide = true;
                    int brojac = 1;

                    while (ide) {
                        Pair<String, Double> jedanElement;

                        try {
                            JSONObject pozicija = polja2.getJSONObject(String.valueOf(brojac));
                            JSONObject mapa2 = pozicija.getJSONObject("mapValue");
                            JSONObject polja3 = mapa2.getJSONObject("fields");

                            String imeIgracaHelp1 = polja3.toString();
                            String[] imeIgracaHelp2 = imeIgracaHelp1.split("\"");
                            String imeIgracaHelp3 = imeIgracaHelp2[1];

                            JSONObject imeIgraca = polja3.getJSONObject(imeIgracaHelp3);
                            double rez = imeIgraca.getDouble("doubleValue");

                            jedanElement = new Pair<>(imeIgracaHelp3, rez);
                            listaParova.add(jedanElement);

                            brojac++;
                        } catch (JSONException e) {
                            ide = false;
                        }
                    }
                    listaParova.add(new Pair<String, Double>(ime,procenat));
                    Collections.sort(listaParova, new Comparator<Pair<String, Double>>() {
                        @Override
                        public int compare(Pair<String, Double> stringDoublePair, Pair<String, Double> t1) {
                            if(stringDoublePair.second > t1.second) return 1;
                            else if(stringDoublePair.second < t1.second) return -1;
                            return 0;
                        }
                    });
                    for(int i=0;i<listaParova.size();i++){
                        Log.d("IME", listaParova.get(i).first);
                    }

                    try
                    {
                        String urlUpdate = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Rangliste/" + nazivKviza + "?currentDocument.exists=true&access_token=";
                        urlObj = new URL(urlUpdate + URLEncoder.encode(TOKEN,"UTF-8"));
                        urlConnection = (HttpURLConnection) urlObj.openConnection();
                        urlConnection.setRequestMethod("PATCH");
                        urlConnection.setRequestProperty("Content-Type", "application/json");
                        urlConnection.setRequestProperty("Accept", "application/json");


                        StringBuilder dokument = new StringBuilder("{ \"fields\": " +
                                "{ \"nazivKviza\": { \"stringValue\": \"" + kviz + "\"}, " +
                                " \"lista\" : { \"mapValue\" : { \"fields\" : { ");
                        int pozicija = 1;
                        for(int i = listaParova.size()-1; i>=0; i--)
                        {
                            dokument.append(" \""+pozicija+"\" : { \"mapValue\" : { \"fields\" : { " +
                                    " \"" + listaParova.get(i).first + "\" : { \"doubleValue\" : \"" + listaParova.get(i).second + "\"}}}}");

                            if(i != 0)
                                dokument.append(", ");

                            pozicija++;
                        }
                        dokument.append(" }}}}}");

                        OutputStream outputStream = urlConnection.getOutputStream();
                        byte[] unos = dokument.toString().getBytes();
                        outputStream.write(unos, 0, unos.length);

                        InputStream odgovor = urlConnection.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while((responseLine = bufferedReader.readLine()) != null)
                            response.append(responseLine.trim());

                        Log.d("ODGOVOR", response.toString());
                    }
                    catch (IOException e)
                    {
                        //nije dobro upisalo
                        e.printStackTrace();
                    }

                }
                catch (JSONException e){
                    e.printStackTrace();
                    return;
                }
            }
            catch (FileNotFoundException | JSONException e){
                e.printStackTrace();
                //ne postoji
                //pravljenje i ubacivanje prvog
                String urlUploadanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Rangliste?documentId=" + nazivKviza + "&access_token=";
                urlObj = new URL(urlUploadanje + URLEncoder.encode(TOKEN,"UTF-8"));
                urlConnection = (HttpURLConnection) urlObj.openConnection();
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json");
                urlConnection.setRequestProperty("Accept", "application/json");

                StringBuilder dokument = new StringBuilder("{ \"fields\": " +
                        "{ \"nazivKviza\": { \"stringValue\": \"" + kviz + "\"}, " +
                        " \"lista\" : { \"mapValue\" : { \"fields\" : { " +
                        " \"1\" : { \"mapValue\" : { \"fields\" : { " +
                        " \"" + ime + "\" : { \"doubleValue\" : \"" + procenat + "\"}}}}" +
                        " }}}}}");

                try(OutputStream os = urlConnection.getOutputStream()){
                    byte[] input = dokument.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = urlConnection.getResponseCode();
                InputStream odgovor = urlConnection.getInputStream();
                try(BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))){
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null){
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
                listaParova.add(new Pair<String, Double>(ime, procenat));
            }
            ArrayList<String> rangLista = new ArrayList<>();
            for(int i = 0;i<listaParova.size();i++){
                rangLista.add(String.valueOf(i+1) + ". " + listaParova.get(listaParova.size()-1-i).first + " " + String.valueOf(listaParova.get(listaParova.size()-1-i).second));
            }
            bundle.putStringArrayList("LISTA", rangLista);
            resultReceiver.send(STATUS_FINISHED,bundle);

        }
        catch(IOException e){
            e.printStackTrace();
        }

    }
}
