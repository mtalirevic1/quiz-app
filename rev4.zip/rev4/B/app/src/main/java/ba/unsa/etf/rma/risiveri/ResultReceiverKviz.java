package ba.unsa.etf.rma.risiveri;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;

public class ResultReceiverKviz extends ResultReceiver {

    private ReceiverKviz mReceiver;
    public ResultReceiverKviz(Handler handler) {
        super(handler);
    }
    public void setReceiver(ReceiverKviz receiver) {
        mReceiver = receiver;
    }
    /* Deklaracija interfejsa koji će se trebati implementirati */
    public interface ReceiverKviz {
        public void onReceiveResultKviz(int resultCode, Bundle resultData);
    }
    @Override
    protected void onReceiveResult(int resultCode, Bundle resultData) {
        if (mReceiver != null) {
            mReceiver.onReceiveResultKviz(resultCode, resultData);
        }
    }
}
