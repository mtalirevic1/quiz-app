package ba.unsa.etf.rma.servisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.fasterxml.jackson.core.JsonEncoding;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviServis extends IntentService {

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    URL urlObj;
    HttpURLConnection urlConnection;
    String TOKEN;

    public KvizoviServis() {
        super(null);
    }
    public KvizoviServis(String name) {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }
    @Override
    public void onCreate() {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }
    @Override
    protected void onHandleIntent(Intent intent) {
        final ResultReceiver resultReceiver = intent.getParcelableExtra("RISIVER");
        ArrayList<Kviz> sviKvizovi = new ArrayList<>();
        try{
            InputStream is = getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            TOKEN = credentials.getAccessToken();
            Log.d("TOKEN", TOKEN);

            String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kvizovi?access_token=";
            urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
            urlConnection = (HttpURLConnection) urlObj.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String rezultat = Konverzija.convertStreamToString(in);
            JSONObject jo = new JSONObject(rezultat);
            Log.d("REZULTAT", rezultat);
            JSONArray documents = new JSONArray();
            try {
                documents = jo.getJSONArray("documents");
            }
            catch (JSONException e){
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("KVIZOVI", sviKvizovi);
                resultReceiver.send(STATUS_FINISHED,bundle);
                return;
            }
            for(int i = 0; i < documents.length(); i++){
                JSONObject dokument = documents.getJSONObject(i);
                JSONObject polja = dokument.getJSONObject("fields");
                JSONObject nazivHelp = polja.getJSONObject("naziv");
                String naziv = nazivHelp.getString("stringValue");
                JSONObject idKategorijeHelp = polja.getJSONObject("idKategorije");
                String idKategorije = idKategorijeHelp.getString("stringValue");
                JSONObject pitanjaHelp = polja.getJSONObject("pitanja");
                JSONObject pitanjaHelp1 = pitanjaHelp.getJSONObject("arrayValue");
                ArrayList<String> naziviPitanja = new ArrayList<>();
                ArrayList<Pitanje> pitanja;
                try {
                    JSONArray pitanjaHelp2 = pitanjaHelp1.getJSONArray("values");
                    for(int j = 0; j<pitanjaHelp2.length(); j++){
                        naziviPitanja.add(pitanjaHelp2.getJSONObject(j).getString("stringValue"));
                    }
                    pitanja = dajPitanja(naziviPitanja);
                }
                catch (JSONException e){
                    pitanja = new ArrayList<>();
                }
                Kviz kviz = new Kviz();
                kviz.setNaziv(naziv);
                kviz.setPitanja(pitanja);
                kviz.setKategorija(dajKategoriju(idKategorije));
                sviKvizovi.add(kviz);
            }

            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("KVIZOVI", sviKvizovi);
            resultReceiver.send(STATUS_FINISHED,bundle);

        }
        catch(IOException | JSONException e){
            e.printStackTrace();
        }
    }
    public ArrayList<Pitanje> dajPitanja(ArrayList<String> pitanja){

        ArrayList<Pitanje> pitanjaIzKviza = new ArrayList<>();

        try{
            String urlPitanja = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Pitanja?access_token=";
            urlObj = new URL(urlPitanja + URLEncoder.encode(TOKEN, "UTF-8"));
            urlConnection = (HttpURLConnection) urlObj.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String rezultat = Konverzija.convertStreamToString(in);
            //Log.d("dokumenti",rezultat);
            JSONObject jo = new JSONObject(rezultat);

            JSONArray documents = jo.getJSONArray("documents");
            for(int i=0;i<documents.length();i++){
                JSONObject dokument = documents.getJSONObject(i);
                JSONObject fields = dokument.getJSONObject("fields");
                JSONObject nazivHelp = fields.getJSONObject("naziv");
                String naziv = nazivHelp.getString("stringValue");
                JSONObject indexTacnogHelp = fields.getJSONObject("indexTacnog");
                int indexTacnog = indexTacnogHelp.getInt("integerValue");
                JSONObject odgovoriHelp = fields.getJSONObject("odgovori");
                JSONObject odgovoriHelp1 = odgovoriHelp.getJSONObject("arrayValue");
                JSONArray odgovoriHelp2 = odgovoriHelp1.getJSONArray("values");
                ArrayList<String> odgovori = new ArrayList<>();
                for (int j = 0; j < odgovoriHelp2.length(); j++) {
                    odgovori.add(odgovoriHelp2.getJSONObject(j).getString("stringValue"));
                }
                Pitanje pitanje = new Pitanje();
                pitanje.setNaziv(naziv);
                pitanje.setOdgovori(odgovori);
                pitanje.setTacan(odgovori.get(indexTacnog));
                pitanje.setTekstPitanja(naziv);
                if(pitanja.contains(naziv)) pitanjaIzKviza.add(pitanje);
            }
        }
        catch(JSONException | IOException e){
            e.printStackTrace();
        }
        return pitanjaIzKviza;
    }
    public Kategorija dajKategoriju(String kategorija){
        Kategorija kategorijaNova = new Kategorija();
        try{
            String urlDohvatanje = "https://firestore.googleapis.com/v1/projects/kvizovi18067/databases/(default)/documents/Kategorije/" + URLEncoder.encode(kategorija) + "?access_token=";
            urlObj = new URL(urlDohvatanje + URLEncoder.encode(TOKEN, "UTF-8"));
            urlConnection = (HttpURLConnection) urlObj.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String rezultat = Konverzija.convertStreamToString(in);
            JSONObject jo = new JSONObject(rezultat);

            Log.d("KATEGORIJA", rezultat);

            JSONObject polja = jo.getJSONObject("fields");
            JSONObject nazivHelp = polja.getJSONObject("naziv");
            String naziv = nazivHelp.getString("stringValue");
            JSONObject idIkoniceHelp = polja.getJSONObject("idIkonice");
            int idIkonice = idIkoniceHelp.getInt("integerValue");
            kategorijaNova.setNaziv(naziv);
            kategorijaNova.setId(String.valueOf(idIkonice));

        }
        catch (IOException | JSONException e){
            e.printStackTrace();
        }
        return kategorijaNova;
    }
}
