package ba.unsa.etf.rma.fragmenti;

import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class PitanjeFrag extends Fragment {
    private ArrayList<String> odgovori = new ArrayList<>();
    private OnItemClick oic;
    private Pitanje pitanje;
    private int tacanPozicija = -1;
    private int netacanPozicija = -1;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        return inflater.inflate(R.layout.pitanje_fragment, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments().containsKey("pitanje")){
            pitanje = getArguments().getParcelable("pitanje");
            odgovori = pitanje.dajRandomOdgovore();
            ListView lv = (ListView)getView().findViewById(R.id.odgovoriPitanja);
            final ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, odgovori){
                @Override
                public View getView(int position, View convertView, ViewGroup parent){
                    View view = super.getView(position,convertView,parent);
                    if(position == tacanPozicija)
                    {
                        view.setBackgroundColor(getResources().getColor(R.color.zelena));
                    }
                    else if(position == netacanPozicija){
                        view.setBackgroundColor(getResources().getColor(R.color.crvena));
                    }
                    else{
                        view.setBackgroundColor(Color.parseColor("#00000000"));
                    }
                    return view;
                }
            };
            lv.setAdapter(adapter);
            TextView tv = (TextView)getView().findViewById(R.id.tekstPitanja);
            tv.setText(pitanje.getNaziv());
            try {
                oic = (OnItemClick)getActivity();
            } catch (ClassCastException e) {
                throw new ClassCastException(getActivity().toString() +
                        "Treba implementirati OnItemClick");
            }
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    boolean tacanOdgovor = false;
                    if(odgovori.get(position).equals(pitanje.getTacan())){
                        tacanPozicija = position;
                        tacanOdgovor = true;
                    }else{
                        netacanPozicija = position;
                        tacanPozicija = odgovori.indexOf(pitanje.getTacan());
                    }
                    adapter.notifyDataSetChanged();
                    oic.onItemClicked(position, tacanOdgovor);
                }
            });
        }
    }
    public interface OnItemClick {
        public void onItemClicked(int pos, boolean tacanOdgovor);
    }
}
