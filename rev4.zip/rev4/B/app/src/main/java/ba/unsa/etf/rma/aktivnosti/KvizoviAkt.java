package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.app.FragmentManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.CalendarContentResolver;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizoviAktAdapter;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangLista;
import ba.unsa.etf.rma.klase.SQLBaza;
import ba.unsa.etf.rma.risiveri.ResultReceiverRangLista;
import ba.unsa.etf.rma.risiveri.ResultReceiverRangListe;
import ba.unsa.etf.rma.risiveri.ResultRecieverKategorije;
import ba.unsa.etf.rma.risiveri.ResultRecieverKvizoviIzKategorije;
import ba.unsa.etf.rma.risiveri.ResultRecieverMogucaPitanja;
import ba.unsa.etf.rma.risiveri.ResultRecieverSviKvizovi;
import ba.unsa.etf.rma.servisi.KategorijeServis;
import ba.unsa.etf.rma.servisi.KvizoviIzKategorijeServis;
import ba.unsa.etf.rma.servisi.KvizoviServis;
import ba.unsa.etf.rma.servisi.MogucaPitanjaServis;
import ba.unsa.etf.rma.servisi.RangListeServis;
import ba.unsa.etf.rma.servisi.SveRangListeServis;


public class KvizoviAkt extends AppCompatActivity implements ListaFrag.OnItemClick, ResultRecieverKategorije.Receiver, ResultRecieverKvizoviIzKategorije.ReceiverKvizovi, ResultRecieverSviKvizovi.ReceiverSviKvizovi, ResultReceiverRangListe.ReceiverRangListe {

    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;
    private KvizoviAktAdapter kvizoviAktAdapter;
    public static ArrayList<Kviz> kvizovi = new ArrayList<>();
    private KategorijeAdapter kategorijeAdapterKvizoviAkt;
    public static ArrayList<Kviz> odabraniKvizovi = new ArrayList<>();
    public static ArrayList<Kategorija> kategorije = new ArrayList<>();
    private Boolean siriL;
    Kategorija svi;
    private View footerView;
    private SQLBaza baza = new SQLBaza(this);
    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE")){
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                //ovo netinfo==null provjerava jel u airplane modu(pise na netu)
                if(netInfo == null || netInfo.isConnected() == false){
                    Toast.makeText(context, "Nestalo je interneta!",Toast.LENGTH_LONG).show();
                    kategorije.clear();
                    kategorije.addAll(baza.ucitajKategorije());
                    if(!kategorije.contains(svi)) kategorije.add(svi);
                    kategorijeAdapterKvizoviAkt.notifyDataSetChanged();
                    kvizovi.clear();
                    kvizovi.addAll(baza.ucitajKvizove());

                    if(lvKvizovi != null)
                        lvKvizovi.setOnItemLongClickListener(null);

                    spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            odabraniKvizovi.clear();
                            Kategorija izabrana = (Kategorija) spPostojeceKategorije.getSelectedItem();
                            if (izabrana.equals(svi)) {
                                odabraniKvizovi.addAll(kvizovi);
                            } else {
                                for (int j = 0; j < kvizovi.size(); j++) {
                                    if (kvizovi.get(j).getKategorija().equals(izabrana))
                                        odabraniKvizovi.add(kvizovi.get(j));
                                }
                            }
                            kvizoviAktAdapter = new KvizoviAktAdapter(KvizoviAkt.this, odabraniKvizovi);
                            lvKvizovi.setAdapter(kvizoviAktAdapter);

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                }
                else{

                    Toast.makeText(context, "Ima interneta!\nNe diraj nista ucitava se!",Toast.LENGTH_LONG).show();

                    Intent kategorijeIntent = new Intent(Intent.ACTION_SYNC, null, KvizoviAkt.this, KategorijeServis.class);
                    ResultRecieverKategorije risiver = new ResultRecieverKategorije(new Handler());
                    risiver.setReceiver(KvizoviAkt.this);
                    kategorijeIntent.putExtra("RISIVER", risiver);
                    startService(kategorijeIntent);

                    lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                        @Override
                        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                            Intent dodajKviz = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            dodajKviz.putExtra("Pozicija", i);
                            KvizoviAkt.this.startActivity(dodajKviz);
                            return true;
                        }
                    });
                    spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                            //odabraniKvizovi.clear();
                            Kategorija izabrana = (Kategorija) spPostojeceKategorije.getSelectedItem();
                            if (izabrana.equals(svi)) {
                                Intent kvizoviSviIntent = new Intent(Intent.ACTION_SYNC, null, KvizoviAkt.this, KvizoviServis.class);
                                ResultRecieverSviKvizovi reciever = new ResultRecieverSviKvizovi(new Handler());
                                reciever.setReceiver(KvizoviAkt.this);
                                kvizoviSviIntent.putExtra("RISIVER", reciever);
                                startService(kvizoviSviIntent);
                            } else {
                                Intent kvizoviIntent = new Intent(Intent.ACTION_SYNC, null, KvizoviAkt.this, KvizoviIzKategorijeServis.class);
                                ResultRecieverKvizoviIzKategorije reciever = new ResultRecieverKvizoviIzKategorije(new Handler());
                                reciever.setReceiver(KvizoviAkt.this);
                                kvizoviIntent.putExtra("RISIVER", reciever);
                                kvizoviIntent.putExtra("KATEGORIJA", izabrana);
                                startService(kvizoviIntent);
                        /*for (int j = 0; j < kvizovi.size(); j++) {
                            if (kvizovi.get(j).getKategorija().equals(izabrana))
                                odabraniKvizovi.add(kvizovi.get(j));
                        }*/
                            }
                            kvizoviAktAdapter = new KvizoviAktAdapter(KvizoviAkt.this, odabraniKvizovi);
                            lvKvizovi.setAdapter(kvizoviAktAdapter);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> adapterView) {
                        }
                    });
                    //kad se pojavi internet ucitava se sve iz firebase-a, a onda iz lokalne baze, sortira pa u firebase;
                    Intent rangListeIntent = new Intent(Intent.ACTION_SYNC, null, KvizoviAkt.this, RangListeServis.class);
                    ResultReceiverRangListe receiver = new ResultReceiverRangListe(new Handler());
                    receiver.setReceiver(KvizoviAkt.this);
                    rangListeIntent.putExtra("RISIVER", receiver);
                    startService(rangListeIntent);

                    Intent rangListeUpdateIntent = new Intent(Intent.ACTION_SYNC, null, KvizoviAkt.this, SveRangListeServis.class);
                    rangListeUpdateIntent.putParcelableArrayListExtra("LISTA", baza.dajRangListe());
                    startService(rangListeUpdateIntent);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //baza.obrisiSve();

        svi = new Kategorija();
        svi.setId("608");
        svi.setNaziv("Svi");
        //ovo ne treba sad jer se ucitava iz baze svaki put
        //if(!kategorije.contains(svi))kategorije.add(svi);

        siriL = false;
        FrameLayout listPlace = (FrameLayout)findViewById(R.id.listPlace);

        if(listPlace!=null){
            FragmentManager fm = getFragmentManager();
            siriL = true;
            ListaFrag listaFrag;
            listaFrag = (ListaFrag) fm.findFragmentById(R.id.listPlace);

            if(listaFrag==null) {
                listaFrag = new ListaFrag();
                fm.beginTransaction().replace(R.id.listPlace, listaFrag).commit();
            }
            DetailFrag detailFrag;
            detailFrag =(DetailFrag)fm.findFragmentById(R.id.detailPlace);

            if(detailFrag==null){
                Bundle bundle = new Bundle();
                //stavila ovdje svi, bilo kategorije.get(0);
                bundle.putParcelable("kategorija", svi);
                detailFrag = new DetailFrag();
                detailFrag.setArguments(bundle);
                fm.beginTransaction().replace(R.id.detailPlace,detailFrag).commit();
            }
        }else {

            spPostojeceKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
            lvKvizovi = (ListView) findViewById(R.id.lvKvizovi);

            footerView = getLayoutInflater().inflate(R.layout.listview_footer_kviz, null);
            lvKvizovi.addFooterView(footerView);

            kategorijeAdapterKvizoviAkt = new KategorijeAdapter(this, kategorije);
            spPostojeceKategorije.setAdapter(kategorijeAdapterKvizoviAkt);

            /*kvizoviAktAdapter = new KvizoviAktAdapter(KvizoviAkt.this, odabraniKvizovi);
            lvKvizovi.setAdapter(kvizoviAktAdapter);*/


            lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    if(i==odabraniKvizovi.size()) return;


                    String pattern = "yyyy-MM-dd";
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
                    Date sad = new Date();
                    Map<String, String> mapa = new CalendarContentResolver(KvizoviAkt.this).procitajPodatke();

                        for (Map.Entry<String, String> entry : mapa.entrySet()) {
                            long time = Long.parseLong((entry.getKey()));
                            long kraj = Long.parseLong(entry.getValue());
                            Date datum = new Date(time);
                            if(simpleDateFormat.format(sad).equals(simpleDateFormat.format(datum))){

                                int trajanjeKviza = (int)Math.ceil(kvizovi.get(i).getPitanja().size()/2.);
                                long miliSad = sad.getTime();
                                long miliEvent = datum.getTime();
                                long miliTrajanjeKviza = TimeUnit.MINUTES.toMillis(trajanjeKviza);
                                int minuteDoEventa = (int) (TimeUnit.MILLISECONDS.toMinutes(miliEvent - miliSad) + 1);

                                if(time < miliSad && miliSad < kraj){
                                    new AlertDialog.Builder(KvizoviAkt.this)
                                            .setTitle("Pokusaj igranja")
                                            .setMessage("Imate aktivan događaj u kalendaru!")
                                            .setNegativeButton(android.R.string.ok, null)
                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                                    return;
                                }

                                if(miliSad + miliTrajanjeKviza > miliEvent && miliSad < miliEvent){
                                    new AlertDialog.Builder(KvizoviAkt.this)
                                            .setTitle("Pokusaj igranja")
                                            .setMessage("Imate događaj u kalendaru za " + minuteDoEventa + " minuta!")
                                            .setNegativeButton(android.R.string.ok, null)
                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                                    return;
                                }
                            }
                        }

                    Intent igrajKviz = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                    igrajKviz.putExtra("Pozicija", i);
                    KvizoviAkt.this.startActivity(igrajKviz);
                }
            });

            IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
            registerReceiver(broadcastReceiver, intentFilter1);
        }
    }
    @Override
    public void onItemClicked(int pos){
        Bundle bundle = new Bundle();
        bundle.putParcelable("kategorija",kategorije.get(pos));
        DetailFrag newDetaljiFrag = new DetailFrag();
        newDetaljiFrag.setArguments(bundle);
        getFragmentManager().beginTransaction().replace(R.id.detailPlace,newDetaljiFrag).commit();
    }
    @Override
    public void onResume(){
        super.onResume();
        Kategorija kategorija = new Kategorija();
        kategorija.setNaziv("Dodaj kategoriju");
        if(kategorije.contains(kategorija)) kategorije.remove(kategorija);
    }
    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KategorijeServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KategorijeServis.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                kategorije.clear();
                kategorije.addAll(resultData.<Kategorija>getParcelableArrayList("KATEGORIJE"));
                kategorijeAdapterKvizoviAkt.notifyDataSetChanged();
                //stavim na svi da bi se uvijek kad udjemo u ovu akt ucitali svi kvizovi, da bude stanje kao u bazi
                spPostojeceKategorije.setSelection(kategorije.indexOf(svi));
                baza.azurirajBazuKategorije();
                break;
            case KategorijeServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    public void onReceiveResultKvizovi(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KvizoviIzKategorijeServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KvizoviIzKategorijeServis.STATUS_FINISHED:
                odabraniKvizovi.clear();
                odabraniKvizovi.addAll(resultData.<Kviz>getParcelableArrayList("KVIZOVI"));
                kvizoviAktAdapter.notifyDataSetChanged();
                for(int i=0;i<odabraniKvizovi.size();i++){
                    if(!kvizovi.contains(odabraniKvizovi.get(i))) kvizovi.add(odabraniKvizovi.get(i));
                }
                break;
            case KvizoviIzKategorijeServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    public void onReceiveResultSviKvizovi(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KvizoviServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KvizoviServis.STATUS_FINISHED:
                odabraniKvizovi.clear();
                kvizovi.clear();
                kvizovi.addAll(resultData.<Kviz>getParcelableArrayList("KVIZOVI"));
                odabraniKvizovi.addAll(kvizovi);
                kvizoviAktAdapter.notifyDataSetChanged();
                baza.azurirajBazuKvizovi();
                break;
            case KvizoviServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    public void onReceiveResultRangListe(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case RangListeServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case RangListeServis.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                ArrayList<RangLista> rangListas = new ArrayList<>();
                rangListas.addAll(resultData.<RangLista>getParcelableArrayList("LISTA"));
                for(int i=0;i<rangListas.size();i++){
                    baza.dodajRezultat(rangListas.get(i).getKviz(), rangListas.get(i).getIgrac(), rangListas.get(i).getRezultat());
                }
                break;
            case RangListeServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    protected void onStop()
    {
        super.onStop();
        try{
            unregisterReceiver(broadcastReceiver);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }
    public static void napuniKvizove(){
        Kviz kviz1 = new Kviz(), kviz2=new Kviz(), kviz3=new Kviz();
        kviz1.setNaziv("Kviz1");
        kviz2.setNaziv("Kviz2");
        kviz3.setNaziv("Kviz3");
        kvizovi.add(kviz1);
        kvizovi.add(kviz2);
        kvizovi.add(kviz3);
        Pitanje pitanje1 = new Pitanje();
        pitanje1.setNaziv("Pitanje 1");
        Pitanje pitanje2 = new Pitanje();
        pitanje2.setNaziv("Pitanje 2");
        Pitanje pitanje3 = new Pitanje();
        pitanje3.setNaziv("Pitanje 3");
        Pitanje pitanje4 = new Pitanje();
        pitanje4.setNaziv("Pitanje 4");
        Pitanje pitanje5 = new Pitanje();
        pitanje5.setNaziv("Pitanje 5");
        Kategorija kategorija1 = new Kategorija();
        kategorija1.setNaziv("Kategorija 1");
        Kategorija kategorija2 = new Kategorija();
        kategorija2.setNaziv("Kategorija 2");
        kategorija1.setId(String.valueOf(1));
        kategorija2.setId(String.valueOf(2));
        kategorije.add(kategorija1);
        kategorije.add(kategorija2);
        kviz1.setKategorija(kategorija1);
        kviz2.setKategorija(kategorija2);
        kviz3.setKategorija(kategorija2);
        kviz1.dodajPitanje(pitanje1);
        kviz2.dodajPitanje(pitanje2);
        kviz3.dodajPitanje(pitanje3);
        kviz1.dodajPitanje(pitanje4);
        kviz2.dodajPitanje(pitanje5);

    }
}
