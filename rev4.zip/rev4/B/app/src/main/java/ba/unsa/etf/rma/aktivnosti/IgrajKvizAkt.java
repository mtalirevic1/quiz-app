package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.provider.AlarmClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Date;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick{

    private Kviz kviz;
    private ArrayList<Pitanje> pitanja = new ArrayList<>();
    private int brojTacnih = 0;
    private int brojPreostalih = 0;
    private double procenatTacnih = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        int pozicija = getIntent().getIntExtra("Pozicija",-1);
        kviz = kvizovi.get(pozicija);
        pitanja = kviz.dajRandomPitanja();
        brojPreostalih = pitanja.size();


        Date date = new Date();


        int sati = date.getHours();
        int minute = date.getMinutes();

        int n = (int)Math.ceil(pitanja.size()/2.);

        if(minute + n >= 60){
            sati+=1;
            minute = minute + n - 60;
        }
        else minute+=n;

        Log.d("MINUTE", String.valueOf(minute));

        if(n!=0) {
            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
            alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, sati);
            alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            alarmIntent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            IgrajKvizAkt.this.startActivity(alarmIntent);
        }

        FragmentManager fm = getFragmentManager();

        InformacijeFrag inf =(InformacijeFrag) fm.findFragmentById(R.id.informacijePlace);
        if(inf==null){
            inf = new InformacijeFrag();
            Bundle bundle = new Bundle();
            bundle.putString("naziv kviza", kviz.getNaziv());
            bundle.putInt("broj tacnih",brojTacnih);
            bundle.putInt("broj preostalih", brojPreostalih);
            bundle.putDouble("procenat tacnih", procenatTacnih);
            inf.setArguments(bundle);
            fm.beginTransaction().replace(R.id.informacijePlace,inf).commit();
        }
        PitanjeFrag pf = (PitanjeFrag) fm.findFragmentByTag("Lista");
        if(pf==null){
            pf = new PitanjeFrag();
            Bundle bundle = new Bundle();
            if(brojPreostalih>0) bundle.putParcelable("pitanje",pitanja.get(brojPreostalih-1));
            else
            {
                Pitanje kraj = new Pitanje();
                kraj.setNaziv("Kviz je završen!");
                bundle.putParcelable("pitanje", kraj);
            }
            pf.setArguments(bundle);
            fm.beginTransaction().replace(R.id.pitanjePlace,pf,"Lista").commit();
        }
    }
    @Override
    public void onItemClicked(int pos, boolean tacanOdgovor){
        if(tacanOdgovor){
            brojTacnih++;
        }
        brojPreostalih--;
        procenatTacnih = Double.valueOf(brojTacnih)/(pitanja.size()-brojPreostalih);
        if(brojPreostalih>0) {
            Bundle pit = new Bundle();
            pit.putParcelable("pitanje", pitanja.get(brojPreostalih - 1));

            final PitanjeFrag pitanjeFrag = new PitanjeFrag();
            pitanjeFrag.setArguments(pit);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    getFragmentManager().beginTransaction().replace(R.id.pitanjePlace, pitanjeFrag).commit();
                }
            }, 2000);
        }
        else{

            final EditText editText = new EditText(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
            );
            editText.setLayoutParams(layoutParams);

            new AlertDialog.Builder(this)
                    .setTitle("Unos imena:")
                    .setMessage("Unesite ime:")
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String ime = editText.getText().toString();
                            Bundle bundle = new Bundle();
                            bundle.putString("IME", ime);
                            bundle.putDouble("PROCENAT", procenatTacnih);
                            bundle.putString("KVIZ", kviz.getNaziv());
                            final RangLista rangLista = new RangLista();
                            rangLista.setArguments(bundle);
                            getFragmentManager().beginTransaction().replace(R.id.pitanjePlace, rangLista).commit();
                        }
                    })
                    .setView(editText)
                    .create().show();
        }
        Bundle info = new Bundle();
        info.putString("naziv kviza", kviz.getNaziv());
        info.putInt("broj tacnih", brojTacnih);
        info.putInt("broj preostalih", brojPreostalih);
        info.putDouble("procenat tacnih", procenatTacnih);

        InformacijeFrag informacijeFrag = new InformacijeFrag();
        informacijeFrag.setArguments(info);
        getFragmentManager().beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
    }
}
