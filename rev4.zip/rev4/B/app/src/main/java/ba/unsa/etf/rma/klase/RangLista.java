package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

public class RangLista implements Parcelable {

    String kviz;
    String igrac;
    double rezultat;

    public RangLista(String kviz, String igrac, double rezultat) {
        this.kviz = kviz;
        this.igrac = igrac;
        this.rezultat = rezultat;
    }

    public RangLista() {
    }

    protected RangLista(Parcel in) {
        kviz = in.readString();
        igrac = in.readString();
        rezultat = in.readDouble();
    }

    public static final Creator<RangLista> CREATOR = new Creator<RangLista>() {
        @Override
        public RangLista createFromParcel(Parcel in) {
            return new RangLista(in);
        }

        @Override
        public RangLista[] newArray(int size) {
            return new RangLista[size];
        }
    };

    public String getKviz() {
        return kviz;
    }

    public void setKviz(String kviz) {
        this.kviz = kviz;
    }

    public String getIgrac() {
        return igrac;
    }

    public void setIgrac(String igrac) {
        this.igrac = igrac;
    }

    public double getRezultat() {
        return rezultat;
    }

    public void setRezultat(double rezultat) {
        this.rezultat = rezultat;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(kviz);
        parcel.writeString(igrac);
        parcel.writeDouble(rezultat);
    }
}
