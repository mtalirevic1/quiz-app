package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.risiveri.ResultReceiverKategorija;
import ba.unsa.etf.rma.servisi.KategorijaServis;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kategorije;
import static ba.unsa.etf.rma.aktivnosti.DodajKvizAkt.backPressed;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback, ResultReceiverKategorija.ReceiverKategorija {

    private Icon[] selectedIcons;
    private TextView etNaziv, etIkona;
    private Button btnDodajIkonu, btnDodajKategoriju;
    Kategorija kategorija;
    int povratnaPozicija;
    String povratniNaziv;
    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE")){
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                //ovo netinfo==null provjerava jel u airplane modu(pise na netu)
                if(netInfo == null || netInfo.isConnected() == false){
                    Toast.makeText(context, "Nestalo je interneta!",Toast.LENGTH_LONG).show();
                    btnDodajKategoriju.setOnClickListener(null);
                }
                else{
                    Toast.makeText(context, "Ima interneta!",Toast.LENGTH_LONG).show();
                    btnDodajKategoriju.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View v){
                            boolean validno = true;
                            boolean kategorijaPostoji = false;
                            kategorija = new Kategorija();
                            if(etNaziv.getText().length()>0){
                                for(int i=0;i<kategorije.size();i++){
                                    if(kategorije.get(i).getNaziv().equals(etNaziv.getText().toString())){
                                        validno=false;
                                        kategorijaPostoji = true;
                                        etNaziv.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                                        break;
                                    }
                                }
                                if(validno)kategorija.setNaziv(etNaziv.getText().toString());
                            }else{
                                validno = false;
                                etNaziv.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                            }
                            if(etIkona.getText().length()>0){
                                kategorija.setId(etIkona.getText().toString());
                            }else{
                                validno = false;
                                etIkona.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                            }
                            if(validno){

                                Intent dodajKategoriju = new Intent(Intent.ACTION_SYNC, null, DodajKategorijuAkt.this, KategorijaServis.class);
                                ResultReceiverKategorija reciever = new ResultReceiverKategorija(new Handler());
                                reciever.setReceiver(DodajKategorijuAkt.this);
                                dodajKategoriju.putExtra("RISIVER", reciever);
                                dodajKategoriju.putExtra("KATEGORIJA", kategorija);
                                startService(dodajKategoriju);

                            }
                            else{
                                if(kategorijaPostoji)
                                    new AlertDialog.Builder(DodajKategorijuAkt.this)
                                            .setTitle("Dodavanje kategorije")
                                            .setMessage("Unesena kategorija već postoji!")
                                            .setNegativeButton(android.R.string.ok, null)
                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                            }
                        }
                    });
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        final IconDialog iconDialog = new IconDialog();

        etNaziv = (TextView)findViewById(R.id.etNaziv);
        etIkona = (TextView)findViewById(R.id.etIkona);
        btnDodajIkonu = (Button)findViewById(R.id.btnDodajIkonu);
        btnDodajKategoriju = (Button)findViewById(R.id.btnDodajKategoriju);

        etNaziv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etNaziv.setBackgroundColor(getResources().getColor(R.color.transparent));
            }
        });

        etIkona.setEnabled(false);
        final Intent intent = getIntent();
        povratnaPozicija =  intent.getIntExtra("Pozicija", -1);
        povratniNaziv = intent.getStringExtra("Naziv novog kviza");

        btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etIkona.setBackgroundColor(getResources().getColor(R.color.transparent));
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }
    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        etIkona.setText(String.valueOf(selectedIcons[0].getId()));
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            backPressed = true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    public void onReceiveResultKategorija(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KategorijaServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KategorijaServis.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                kategorije.add((Kategorija) resultData.getParcelable("KATEGORIJA"));
                if(resultData.containsKey("AlertDialog"))
                    new AlertDialog.Builder(DodajKategorijuAkt.this)
                            .setTitle("Dodavanje kategorije")
                            .setMessage("Unesena kategorija već postoji!(bit' će učitana ona iz baze)")
                            .setNegativeButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent myIntent = new Intent(DodajKategorijuAkt.this,DodajKvizAkt.class);
                                    myIntent.putExtra("Pozicija", povratnaPozicija);
                                    myIntent.putExtra("Naziv novog kviza",povratniNaziv);
                                    myIntent.putExtra("Kategorija novog kviza", kategorije.size()-1);
                                    DodajKategorijuAkt.this.startActivity(myIntent);
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                else {
                    Intent myIntent = new Intent(DodajKategorijuAkt.this, DodajKvizAkt.class);
                    myIntent.putExtra("Pozicija", povratnaPozicija);
                    myIntent.putExtra("Naziv novog kviza", povratniNaziv);
                    myIntent.putExtra("Kategorija novog kviza", kategorije.size() - 1);
                    DodajKategorijuAkt.this.startActivity(myIntent);
                }
                break;
            case KategorijaServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    protected void onStop()
    {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }
}
