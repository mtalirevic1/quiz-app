package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;


public class KategorijeAdapter extends ArrayAdapter<Kategorija>
{
    public KategorijeAdapter(Context context, ArrayList<Kategorija> users) {
        super(context, 0, users);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Kategorija kategorija = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.samo_textview, parent, false);
        }
        TextView textView = (TextView) convertView.findViewById(R.id.textView);
        textView.setText(kategorija.getNaziv());
        return convertView;
    }
    //za spinner treba implementirati ovu metodu:
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent){
        Kategorija kategorija = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.samo_textview, parent, false);
        }
        TextView textView = (TextView) convertView.findViewById(R.id.textView);
        textView.setText(kategorija.getNaziv());
        return convertView;
    }
}
