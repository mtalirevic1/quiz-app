package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.risiveri.ResultReceiverPitanje;
import ba.unsa.etf.rma.servisi.PitanjeServis;

import static ba.unsa.etf.rma.aktivnosti.DodajKvizAkt.dodanaPitanja;


public class DodajPitanjeAkt extends AppCompatActivity implements ResultReceiverPitanje.ReceiverPitanje {

    private EditText etNaziv, etOdgovor;
    private ListView lvOdgovori;
    private Button btnDodajOdgovor, btnDodajTacan, btnDodajPitanje;
    public static ArrayList<String> odgovori = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    public static int tacanPozicija=-1;
    Pitanje pitanje;
    int povratnaPozicija;
    String povratniNaziv;
    int povratnaKategorija;
    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE")){
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                //ovo netinfo==null provjerava jel u airplane modu(pise na netu)
                if(netInfo == null || netInfo.isConnected() == false){
                    Toast.makeText(context, "Nestalo je interneta!",Toast.LENGTH_LONG).show();
                    btnDodajPitanje.setOnClickListener(null);
                }
                else{
                    Toast.makeText(context, "Ima interneta!",Toast.LENGTH_LONG).show();
                    btnDodajPitanje.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            pitanje = new Pitanje();
                            boolean validno = true;
                            boolean pitanjePostoji = false;
                            if(etNaziv.getText().length()>0){
                                for(int i=0;i<dodanaPitanja.size();i++){
                                    if(dodanaPitanja.get(i).getNaziv().equals(etNaziv.getText().toString())){
                                        validno=false;
                                        pitanjePostoji = true;
                                        etNaziv.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                                        break;
                                    }
                                }
                                if(validno){
                                    pitanje.setNaziv(etNaziv.getText().toString());
                                    pitanje.setTekstPitanja(etNaziv.getText().toString());
                                }
                            }else{
                                etNaziv.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                                validno = false;
                            }
                            if(tacanPozicija!=-1 && odgovori.size()>0){
                                pitanje.setTacan(odgovori.get(tacanPozicija));
                                pitanje.getOdgovori().addAll(odgovori);
                            }
                            else {
                                lvOdgovori.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                                validno = false;
                            }
                            if(validno){

                                Intent dodajPitanje = new Intent(Intent.ACTION_SYNC, null, DodajPitanjeAkt.this, PitanjeServis.class);
                                ResultReceiverPitanje reciever = new ResultReceiverPitanje(new Handler());
                                reciever.setReceiver(DodajPitanjeAkt.this);
                                dodajPitanje.putExtra("RISIVER", reciever);
                                dodajPitanje.putExtra("PITANJE", pitanje);
                                startService(dodajPitanje);
                            }
                            else{
                                if(pitanjePostoji)
                                    new AlertDialog.Builder(DodajPitanjeAkt.this)
                                            .setTitle("Dodavanje pitanja")
                                            .setMessage("Uneseno pitanje već postoji!")
                                            .setNegativeButton(android.R.string.ok, null)
                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                            }
                        }
                    });
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);

        etNaziv = (EditText)findViewById(R.id.etNaziv);
        etOdgovor = (EditText)findViewById(R.id.etOdgovor);
        lvOdgovori = (ListView) findViewById(R.id.lvOdgovori);
        btnDodajOdgovor = (Button) findViewById(R.id.btnDodajOdgovor);
        btnDodajTacan = (Button) findViewById(R.id.btnDodajTacan);
        btnDodajPitanje = (Button) findViewById(R.id.btnDodajPitanje);

        final Intent intent = getIntent();
        povratnaPozicija =  intent.getIntExtra("Pozicija", -1);
        povratniNaziv = intent.getStringExtra("Naziv novog kviza");
        povratnaKategorija = intent.getIntExtra("Kategorija novog kviza",-1);

        adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, odgovori){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){
                View view = super.getView(position,convertView,parent);
                if(position == tacanPozicija)
                {
                    view.setBackgroundColor(Color.parseColor("#70db70"));
                }
                else{
                    view.setBackgroundColor(Color.parseColor("#00000000"));
                }
                return view;
            }
        };
        lvOdgovori.setAdapter(adapter);
        lvOdgovori.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
        etNaziv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etNaziv.setBackgroundColor(getResources().getColor(R.color.transparent));
            }
        });
        etOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etOdgovor.setBackgroundColor(getResources().getColor(R.color.transparent));
                etOdgovor.setText("");
            }
        });
        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                odgovori.remove(i);
            }
        });

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etOdgovor.getText().length()<=0) etOdgovor.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                else {
                    int i;
                    for (i = 0; i < odgovori.size(); i++) {
                        if(etOdgovor.getText().toString().equals(odgovori.get(i))){
                            etOdgovor.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                            break;
                        }
                    }
                    if(i==odgovori.size()) {
                        odgovori.add(0, etOdgovor.getText().toString());
                        adapter.notifyDataSetChanged();
                        if (tacanPozicija != -1) tacanPozicija++;
                    }
                }
            }
        });
        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etOdgovor.getText().length()<=0) etOdgovor.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                else {
                    int i;
                    for (i = 0; i < odgovori.size(); i++) {
                        if(etOdgovor.getText().toString().equals(odgovori.get(i))){
                            etOdgovor.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                            break;
                        }
                    }
                    if(i==odgovori.size()) {
                        lvOdgovori.setBackgroundColor(getResources().getColor(R.color.transparent));
                        odgovori.add(0, etOdgovor.getText().toString());
                        adapter.notifyDataSetChanged();
                        tacanPozicija = lvOdgovori.getFirstVisiblePosition();
                        btnDodajTacan.setEnabled(false);
                        btnDodajTacan.setClickable(false);
                    }
                }
            }
        });

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            odgovori.clear();
            tacanPozicija = -1;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onReceiveResultPitanje(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case PitanjeServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case PitanjeServis.STATUS_FINISHED:
                if(resultData.getParcelable("PITANJE")!=null) dodanaPitanja.add((Pitanje) resultData.getParcelable("PITANJE"));
                odgovori.clear();
                tacanPozicija = -1;
                if(resultData.containsKey("AlertDialog")){
                    new AlertDialog.Builder(DodajPitanjeAkt.this)
                            .setTitle("Dodavanje pitanja")
                            .setMessage("Uneseno pitanje već postoji u bazi!(bit' će učitano u moguća pitanja)")
                            .setNegativeButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    //vraca se na prethodnu aktivnost i azuriraju se moguca pitanja
                                    Intent newIntent = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
                                    newIntent.putExtra("Pozicija", povratnaPozicija);
                                    newIntent.putExtra("Naziv novog kviza", povratniNaziv);
                                    newIntent.putExtra("Kategorija novog kviza", povratnaKategorija);
                                    DodajPitanjeAkt.this.startActivity(newIntent);
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }
                else {
                    Intent newIntent = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
                    newIntent.putExtra("Pozicija", povratnaPozicija);
                    newIntent.putExtra("Naziv novog kviza", povratniNaziv);
                    newIntent.putExtra("Kategorija novog kviza", povratnaKategorija);
                    DodajPitanjeAkt.this.startActivity(newIntent);
                }
                break;
            case PitanjeServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    protected void onStop()
    {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }
}
