package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Konverzija;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.SQLBaza;
import ba.unsa.etf.rma.risiveri.ResultReceiverKategorija;
import ba.unsa.etf.rma.risiveri.ResultReceiverKviz;
import ba.unsa.etf.rma.risiveri.ResultReceiverPitanje;
import ba.unsa.etf.rma.servisi.KategorijaServis;
import ba.unsa.etf.rma.servisi.KvizServis;
import ba.unsa.etf.rma.servisi.MogucaPitanjaServis;
import ba.unsa.etf.rma.klase.PitanjaAdapter;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.risiveri.ResultRecieverMogucaPitanja;
import ba.unsa.etf.rma.servisi.PitanjaZaImportServis;
import ba.unsa.etf.rma.servisi.PitanjeServis;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kategorije;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.odabraniKvizovi;

public class DodajKvizAkt extends AppCompatActivity implements ResultRecieverMogucaPitanja.Receiver, ResultReceiverKviz.ReceiverKviz, ResultReceiverKategorija.ReceiverKategorija, ResultReceiverPitanje.ReceiverPitanje{
    private static final int READ_REQUEST_CODE = 42;

    private Spinner spKategorije;
    private EditText etNaziv;
    private Button btnDodajKviz,btnImportKviz;
    private ListView lvDodanaPitanja, lvMogucaPitanja;
    private ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();
    public static ArrayList<Pitanje> dodanaPitanja = new ArrayList<>();
    private PitanjaAdapter dodanaAdapter, mogucaAdapter;
    private KategorijeAdapter kategorijeAdapter;
    //private boolean kvizDodan = false;
    private boolean kvizoviAktIntent = true;
    private String nazivNovogKviza;
    private int kategorijaNovogKviza;
    private int position;
    public static boolean backPressed = false;
    private static int pozicijaKategorijePrijeBack = 0;
    private Kategorija dodajKategoriju;
    private String ucitaniKviz;
    Kviz dodajKviz;
    Kviz kviz;
    Kviz kvizZaBrisanjeIzBaze = null;
    private SQLBaza baza = new SQLBaza(this);
    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE")){
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();
                //ovo netinfo==null provjerava jel u airplane modu(pise na netu)
                if(netInfo == null || netInfo.isConnected() == false) {
                    Toast.makeText(context, "Nestalo je interneta!\nMožete ući u svaku aktivnost, ali su dugmad za dodavanje onemogućena!", Toast.LENGTH_LONG).show();
                    btnDodajKviz.setOnClickListener(null);
                }
                else{
                    Toast.makeText(context, "Ima interneta!",Toast.LENGTH_LONG).show();
                    btnDodajKviz.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            boolean kvizPostoji = false;
                            boolean validno = true;
                            kviz = new Kviz();
                            if(etNaziv.getText().length()>0){
                                for(int i=0;i<kvizovi.size();i++){
                                    if(kvizovi.get(i).getNaziv().equals(etNaziv.getText().toString()) && i != position){
                                        validno=false;
                                        kvizPostoji = true;
                                        etNaziv.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                                        break;
                                    }
                                }
                                if(validno)kviz.setNaziv(etNaziv.getText().toString());
                            }
                            else{
                                etNaziv.setBackgroundColor(getResources().getColor(R.color.svijetlo_crvena));
                                validno = false;
                            }
                            kviz.getPitanja().addAll(dodanaPitanja);
                            kviz.setKategorija((Kategorija) spKategorije.getSelectedItem());
                            if(validno){

                                Intent dodajKvizIntent = new Intent(Intent.ACTION_SYNC, null, DodajKvizAkt.this, KvizServis.class);
                                ResultReceiverKviz reciever = new ResultReceiverKviz(new Handler());
                                reciever.setReceiver(DodajKvizAkt.this);
                                dodajKvizIntent.putExtra("RISIVER", reciever);
                                if(position == odabraniKvizovi.size() || (position==odabraniKvizovi.size()-1 && odabraniKvizovi.contains(dodajKviz))){
                                    dodajKvizIntent.putExtra("UPDATE", false);
                                }
                                else{
                                    if(!kvizovi.get(position).getNaziv().equals(kviz.getNaziv())) kvizZaBrisanjeIzBaze = kvizovi.get(position);
                                    dodajKvizIntent.putExtra("UPDATE", true);
                                    //ovdje treba update kviza
                                    baza.azurirajBazuKategorije();
                                    baza.editujKviz(kvizovi.get(position), kviz);
                                }
                                dodajKvizIntent.putExtra("KVIZ", kviz);
                                dodajKvizIntent.putExtra("KVIZBRISANJE", kvizZaBrisanjeIzBaze);
                                startService(dodajKvizIntent);
                            }
                            else{
                                if(kvizPostoji)
                                    new AlertDialog.Builder(DodajKvizAkt.this)
                                            .setTitle("Dodavanje/Editovanje kviza")
                                            .setMessage("Uneseni kviz već postoji!")
                                            .setNegativeButton(android.R.string.ok, null)
                                            .setIcon(android.R.drawable.ic_dialog_alert)
                                            .show();
                            }
                        }
                    });
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        spKategorije = (Spinner) findViewById(R.id.spKategorije);
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        btnDodajKviz = (Button) findViewById(R.id.btnDodajKviz);
        btnImportKviz = (Button) findViewById(R.id.btnImportKviz);
        lvDodanaPitanja = (ListView)findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = (ListView)findViewById(R.id.lvMogucaPitanja);

        View footerViewPitanje = getLayoutInflater().inflate(R.layout.listview_footer_pitanje, null);
        lvDodanaPitanja.addFooterView(footerViewPitanje);

        dodajKategoriju = new Kategorija();
        dodajKategoriju.setNaziv("Dodaj kategoriju");
        dodajKategoriju.setId("22");

        if(!kategorije.contains(dodajKategoriju))kategorije.add(dodajKategoriju);
        //kad intent dolazi iz kvizoviakt ima samo poziciju, medjutim kad dolazi iz dodaj pitanje ili kategoriju
        // ima i poziciju i naziv i kategoriju
        final Intent intent = getIntent();
        if(intent.hasExtra("Pozicija")) position = intent.getIntExtra("Pozicija",-1);
        if(intent.hasExtra("Naziv novog kviza") && intent.hasExtra("Kategorija novog kviza")){
            nazivNovogKviza = intent.getStringExtra("Naziv novog kviza");
            kategorijaNovogKviza = intent.getIntExtra("Kategorija novog kviza",-1);
            kvizoviAktIntent = false;
        }

        dodanaAdapter = new PitanjaAdapter(this,dodanaPitanja);
        mogucaAdapter = new PitanjaAdapter(this,mogucaPitanja);
        kategorijeAdapter = new KategorijeAdapter(this,kategorije);

        lvDodanaPitanja.setAdapter(dodanaAdapter);
        lvMogucaPitanja.setAdapter(mogucaAdapter);
        spKategorije.setAdapter(kategorijeAdapter);

        lvDodanaPitanja.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent motionEvent) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
        lvMogucaPitanja.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent motionEvent) {
                v.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });

        //ako je intent dosao iz kvizoviakt
        dodajKviz = new Kviz();
        dodajKviz.setNaziv("Dodaj kviz");
        if(((position != odabraniKvizovi.size() && !odabraniKvizovi.contains(dodajKviz)) || (position != odabraniKvizovi.size()-1 && odabraniKvizovi.contains(dodajKviz))) && kvizoviAktIntent ){
            for(int i = 0;i<kategorije.size()-1;i++){
                if(kategorije.get(i).getId().equals(odabraniKvizovi.get(position).getKategorija().getId()))
                    spKategorije.setSelection(i);
            }
            etNaziv.setText(odabraniKvizovi.get(position).getNaziv());
            if(dodanaPitanja.isEmpty()) dodanaPitanja.addAll(odabraniKvizovi.get(position).getPitanja());
        }//ako je dosao iz dodajpitanje ili dodajkategoriju
        else{
            //pozova se i u slucaju da dolazi iz landscape KvizoviAkt
            etNaziv.setText(nazivNovogKviza);
            spKategorije.setSelection(kategorijaNovogKviza);
        }
        //dodavanje mogucih pitanja
        Intent mogucaPitanjaIntent = new Intent(Intent.ACTION_SYNC, null, this, MogucaPitanjaServis.class);
        ResultRecieverMogucaPitanja risiver = new ResultRecieverMogucaPitanja(new Handler());
        risiver.setReceiver(DodajKvizAkt.this);
        mogucaPitanjaIntent.putParcelableArrayListExtra("DODANA PITANJA", dodanaPitanja);
        mogucaPitanjaIntent.putExtra("RISIVER", risiver);
        startService(mogucaPitanjaIntent);

       spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Kategorija odabrana = (Kategorija) spKategorije.getSelectedItem();
                if(odabrana.getNaziv().equals("Dodaj kategoriju")){
                    nazivNovogKviza = etNaziv.getText().toString();
                    Intent newIntent = new Intent(DodajKvizAkt.this,DodajKategorijuAkt.class);
                    newIntent.putExtra("Pozicija",position);
                    newIntent.putExtra("Naziv novog kviza", nazivNovogKviza);
                    DodajKvizAkt.this.startActivity(newIntent);
                }
                else{
                    pozicijaKategorijePrijeBack = kategorije.indexOf(odabrana);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        etNaziv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etNaziv.setBackgroundColor(getResources().getColor(R.color.transparent));
            }
        });

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==dodanaPitanja.size()){
                    nazivNovogKviza = etNaziv.getText().toString();
                    kategorijaNovogKviza = spKategorije.getSelectedItemPosition();
                    Intent myIntent = new Intent(DodajKvizAkt.this,DodajPitanjeAkt.class);
                    myIntent.putExtra("Pozicija",position);
                    myIntent.putExtra("Naziv novog kviza", nazivNovogKviza);
                    myIntent.putExtra("Kategorija novog kviza",kategorijaNovogKviza);
                    DodajKvizAkt.this.startActivity(myIntent);
                }else{
                    mogucaPitanja.add(0,dodanaPitanja.get(i));
                    dodanaPitanja.remove(i);
                    dodanaAdapter.notifyDataSetChanged();
                    mogucaAdapter.notifyDataSetChanged();
                }
            }
        });
        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                dodanaPitanja.add(0,mogucaPitanja.get(i));
                mogucaPitanja.remove(i);
                mogucaAdapter.notifyDataSetChanged();
                dodanaAdapter.notifyDataSetChanged();
            }
        });
        btnImportKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

                intent.addCategory(Intent.CATEGORY_OPENABLE);

                intent.setType("text/*");
                startActivityForResult(intent, READ_REQUEST_CODE);
            }
        });

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            dodanaPitanja.clear();
        }
        return super.onKeyDown(keyCode, event);
    }
    @Override
    public void onResume(){
        super.onResume();
        if(backPressed){
            spKategorije.setSelection(pozicijaKategorijePrijeBack);
            backPressed = false;
            dodanaAdapter.notifyDataSetChanged();
        }
    }
    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case MogucaPitanjaServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case MogucaPitanjaServis.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                mogucaPitanja.clear();
                mogucaPitanja.addAll(resultData.<Pitanje>getParcelableArrayList("MOGUCA PITANJA"));
                mogucaAdapter.notifyDataSetChanged();
                break;
            case MogucaPitanjaServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    public void onReceiveResultKviz(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case KvizServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case KvizServis.STATUS_FINISHED:
                if(resultData.getBoolean("UPDATE")){
                    if(resultData.containsKey("AlertDialog")){
                        new AlertDialog.Builder(DodajKvizAkt.this)
                                .setTitle("Editovanje kviza")
                                .setMessage("Kviz koji želite editovati već postoji u bazi!(bit' će učitan)")
                                .setNegativeButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dodanaPitanja.clear();
                                        Intent intent1 = new Intent(DodajKvizAkt.this,KvizoviAkt.class);
                                        DodajKvizAkt.this.startActivity(intent1);
                                    }
                                })
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                    }
                    else{
                        kvizovi.remove(position);
                        kvizovi.add(position,(Kviz) resultData.getParcelable("KVIZ"));
                        dodanaPitanja.clear();
                        Intent intent1 = new Intent(DodajKvizAkt.this,KvizoviAkt.class);
                        DodajKvizAkt.this.startActivity(intent1);
                    }
                }
                else{
                    if(resultData.containsKey("AlertDialog")){
                        new AlertDialog.Builder(DodajKvizAkt.this)
                                .setTitle("Dodavanje kviza")
                                .setMessage("Uneseni kviz već postoji u bazi!(bit' će učitan)")
                                .setNegativeButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dodanaPitanja.clear();
                                        Intent intent1 = new Intent(DodajKvizAkt.this,KvizoviAkt.class);
                                        DodajKvizAkt.this.startActivity(intent1);
                                    }
                                })
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                    }
                    else{
                        kvizovi.add(position,(Kviz) resultData.getParcelable("KVIZ"));
                        dodanaPitanja.clear();
                        Intent intent1 = new Intent(DodajKvizAkt.this,KvizoviAkt.class);
                        DodajKvizAkt.this.startActivity(intent1);
                    }
                }
                break;
            case KvizServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {

        if (requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();
                String imeKviza;
                ArrayList<Pitanje> pitanja;
                try {
                    ucitaniKviz = readTextFromUri(uri);
                    String[] kviz = ucitaniKviz.split("\n");
                    String[] prviRed = kviz[0].split(",");
                    imeKviza = prviRed[0].trim();
                    String kategorija = prviRed[1].trim();
                    boolean postoji = false;
                    for(int k=0;k<kategorije.size();k++){
                        if(kategorije.get(k).getNaziv().equals(kategorija)){
                            postoji = true;
                            spKategorije.setSelection(k);
                            break;
                        }
                    }
                    if(!postoji){
                        Kategorija newKategorija = new Kategorija();
                        newKategorija.setNaziv(kategorija);
                        newKategorija.setId("7");

                        Intent dodajKategoriju = new Intent(Intent.ACTION_SYNC, null, DodajKvizAkt.this, KategorijaServis.class);
                        ResultReceiverKategorija reciever = new ResultReceiverKategorija(new Handler());
                        reciever.setReceiver(DodajKvizAkt.this);
                        dodajKategoriju.putExtra("RISIVER", reciever);
                        dodajKategoriju.putExtra("KATEGORIJA", newKategorija);
                        startService(dodajKategoriju);

                    }
                    String brojPitanja = prviRed[2].trim();
                    for(int i=0;i<kvizovi.size();i++){
                        if(imeKviza.equals(kvizovi.get(i).getNaziv())){
                            new AlertDialog.Builder(this)
                                    .setTitle("Import kviza")
                                    .setMessage("Kviz kojeg imporujete već postoji!")
                                    .setNegativeButton(android.R.string.ok, null)
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show();
                                    return;
                        }
                    }
                    if(Integer.parseInt(brojPitanja)!=kviz.length-1 || Integer.parseInt(brojPitanja)<=0){
                        new AlertDialog.Builder(this)
                                .setTitle("Import kviza")
                                .setMessage("Kviz kojeg imporujete ima neispravan broj pitanja!")
                                .setNegativeButton(android.R.string.ok, null)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                        return;
                    }
                    pitanja = new ArrayList<>();
                    for(int i=1;i<=Integer.parseInt(brojPitanja);i++){
                        String[] pitanje = kviz[i].split(",");
                        String tekstPitanja = pitanje[0].trim();
                        int brojOdgovora = Integer.parseInt(pitanje[1].trim());
                        int tacno = Integer.parseInt(pitanje[2].trim());
                        if(brojOdgovora<=0 || brojOdgovora!=pitanje.length-3){
                            new AlertDialog.Builder(this)
                                    .setTitle("Import kviza")
                                    .setMessage("Kviz kojeg importujete ima neispravan broj odgovora!")
                                    .setNegativeButton(android.R.string.ok, null)
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show();
                            return;
                        }
                        if(tacno<0 || tacno>=brojOdgovora){
                            new AlertDialog.Builder(this)
                                    .setTitle("Import kviza")
                                    .setMessage("Kviz kojeg importujete ima neispravan index tačnog odgovora!")
                                    .setNegativeButton(android.R.string.ok, null)
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show();
                            return;
                        }
                        ArrayList<String> odgovori = new ArrayList<>();
                        for(int j=3;j<pitanje.length;j++){
                            if(odgovori.contains(pitanje[j])){
                                new AlertDialog.Builder(this)
                                        .setTitle("Import kviza")
                                        .setMessage("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!")
                                        .setNegativeButton(android.R.string.ok, null)
                                        .setIcon(android.R.drawable.ic_dialog_alert)
                                        .show();
                                return;
                            }
                            odgovori.add(pitanje[j]);
                        }
                        Pitanje newPitanje = new Pitanje();
                        newPitanje.setNaziv(tekstPitanja);
                        newPitanje.setTekstPitanja(tekstPitanja);
                        newPitanje.setOdgovori(odgovori);
                        newPitanje.setTacan(odgovori.get(tacno));
                        if(pitanja.contains(newPitanje)){
                            new AlertDialog.Builder(this)
                                    .setTitle("Import kviza")
                                    .setMessage("Kviz nije ispravan postoje dva pitanja sa istim nazivom!")
                                    .setNegativeButton(android.R.string.ok, null)
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .show();
                            return;
                        }
                        pitanja.add(newPitanje);
                    }
                }
                catch (Exception e){
                    new AlertDialog.Builder(this)
                            .setTitle("Import kviza")
                            .setMessage("Datoteka kviza kojeg importujete nema ispravan format!")
                            .setNegativeButton(android.R.string.ok, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                    return;
                }
                dodanaPitanja.clear();
                Intent dodajPitanja = new Intent(Intent.ACTION_SYNC, null, DodajKvizAkt.this, PitanjaZaImportServis.class);
                ResultReceiverPitanje reciever = new ResultReceiverPitanje(new Handler());
                reciever.setReceiver(DodajKvizAkt.this);
                dodajPitanja.putExtra("RISIVER", reciever);
                dodajPitanja.putParcelableArrayListExtra("PITANJA", pitanja);
                startService(dodajPitanja);
                /*dodanaPitanja.clear();
                dodanaPitanja.addAll(pitanja);
                dodanaAdapter.notifyDataSetChanged();*/
                etNaziv.setText(imeKviza);
            }
        }
    }
    private String readTextFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line + "\n");
        }
        inputStream.close();
        return stringBuilder.toString();
    }

    @Override
    public void onReceiveResultKategorija(int resultCode, Bundle resultData) {
            switch (resultCode) {
                case KategorijaServis.STATUS_RUNNING:
                    /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                    break;
                case KategorijaServis.STATUS_FINISHED:
                    /* Dohvatanje rezultata i update UI */
                    kategorije.add((Kategorija) resultData.getParcelable("KATEGORIJA"));
                    spKategorije.setSelection(kategorije.size()-1);
                    break;
                case KategorijaServis.STATUS_ERROR:
                    /* Slučaj kada je došlo do greške */
                    String error = resultData.getString(Intent.EXTRA_TEXT);
                    Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                    break;
            }
    }
    @Override
    public void onReceiveResultPitanje(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case PitanjeServis.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case PitanjeServis.STATUS_FINISHED:
                {
                if(resultData.getParcelableArrayList("PITANJA")!=null) dodanaPitanja.addAll(resultData.<Pitanje>getParcelableArrayList("PITANJA"));
                dodanaAdapter.notifyDataSetChanged();
                Intent mogucaPitanjaIntent = new Intent(Intent.ACTION_SYNC, null, this, MogucaPitanjaServis.class);
                ResultRecieverMogucaPitanja risiver = new ResultRecieverMogucaPitanja(new Handler());
                risiver.setReceiver(DodajKvizAkt.this);
                mogucaPitanjaIntent.putParcelableArrayListExtra("DODANA PITANJA", dodanaPitanja);
                mogucaPitanjaIntent.putExtra("RISIVER", risiver);
                startService(mogucaPitanjaIntent);

                break;
                }
            case PitanjeServis.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }
    @Override
    protected void onStop()
    {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }
}
