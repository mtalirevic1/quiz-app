package ba.unsa.etf.rma.klase;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import android.widget.ImageView;
import android.widget.TextView;


import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
public class KvizoviAktAdapter extends ArrayAdapter<Kviz>{

    public KvizoviAktAdapter(Context context, ArrayList<Kviz> users) {
        super(context, 0, users);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Kviz kviz = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.listitem_1, parent, false);
        }
        TextView textView = (TextView) convertView.findViewById(R.id.textView);
        textView.setText(kviz.getNaziv());
        Log.d("IME", kviz.getNaziv());
        final ImageView imageView = (ImageView) convertView.findViewById(R.id.imageView);
        final IconHelper iconHelper = IconHelper.getInstance(convertView.getContext());
        iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
            @Override
            public void onDataLoaded() {
                if(kviz.getKategorija()!=null)imageView.setImageDrawable(iconHelper.getIcon(Integer.parseInt(kviz.getKategorija().getId())).getDrawable(getContext()));
            }
        });
        return convertView;
    }
}
