package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.rep.KategorijaRep;

public class KategorijaAdapter extends ArrayAdapter<Kategorija> {
    private ArrayList<Kategorija> Kategorije = KategorijaRep.Instance().getAll();


    public KategorijaAdapter(@NonNull Context context) {
        super(context, 0);

        Kategorije.add(getSpecial());
    }

    private Kategorija getSpecial() {
        Kategorija special = new Kategorija();
        special.setId("0");
        special.setNaziv("Sve");

        return special;
    }

    @Override
    public int getCount() {
        return Kategorije.size() + 1;
    }

    public Kategorija getItem(int position) {
        if (position < Kategorije.size())
            return Kategorije.get(position);

        return getSpecial();
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.kategorija_item, null);

        TextView naziv = (TextView) view.findViewById(R.id.kategorijaNaziv);
        naziv.setText(getItem(position).getNaziv());

        return view;
    }
}
