package ba.unsa.etf.rma.klase;

import android.util.Pair;

import java.io.Serializable;

public class Par implements Serializable
{
    //ATRIBUTI
    private String first;
    private Double second;

    //KONSTRUKTOR
    public Par(String first, Double second)
    {
            this.first = first;
            this.second = second;
    }

    //GETTERI I SETTERI
    public String getFirst() {
        return first;
    }

    public Double getSecond() {
        return second;
    }
}
