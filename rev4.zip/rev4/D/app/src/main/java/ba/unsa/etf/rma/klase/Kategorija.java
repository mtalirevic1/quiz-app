package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.Objects;

//implements Parcelable
public class Kategorija implements Serializable
{
    //ATRIBUTI
    private String naziv;
    private String id; //id predstvlja broj, pretovren u String, koji odgovara idu izabrane ikonice za kviz

    //KONSTRUKTOR
    public Kategorija(String naziv, String id)
    {
        this.naziv = naziv;
        this.id = id;
    }
    public Kategorija()
    {}

    //GETTERI I SETTERI
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    //EQUALS METODA
    @Override
    public boolean equals(Object o)
    {
        if( (o instanceof Kategorija) == false)
        {
            return false;
        }


        Kategorija druga = (Kategorija) o;

        return this.getNaziv().equals(druga.getNaziv());
    }

    //toString METODA
    @Override
    public String toString()
    {
        return naziv;
    }


    /*//METODE ZA IMPLEMENTACIJU INTERFEJSA "Parceable"
    @Override
    public int describeContents()
    {
        return 0;
    }

    // This is where you will write your member variables in Parcel. Here you
    // can write in any order. It is not necessary to write all members in Parcel.
    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeString(this.id);
        dest.writeString(this.naziv);
    }

    // In constructor you will read the variables from Parcel. Make sure to
    // read them in the same sequence in which you have written them in Parcel.
    public Kategorija(Parcel in)
    {
        id = in.readString();
        naziv = in.readString();
    }

    // This is to de-serialize the object
    public static final Parcelable.Creator<Kategorija> CREATOR = new Parcelable.Creator<Kategorija>()
            {
                public Kategorija createFromParcel(Parcel in)
                {
                    return new Kategorija(in);
                }

                public Kategorija[] newArray(int size)
                {
                    return new Kategorija[size];
                }
            };*/

}
