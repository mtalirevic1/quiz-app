package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Par;

public class AdapterRanglista extends ArrayAdapter<Par>
{
    private Context context;
    private ArrayList<Par> ranglista;

    public AdapterRanglista(Context context, int textViewResourceId, ArrayList<Par> values)
    {
        super(context, textViewResourceId, values);

        this.context = context;
        this.ranglista = values;
    }

    public int getCount()
    {
        return ranglista.size();
    }

    public Par getItem(int position){
        return ranglista.get(position);
    }

    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        final Par jedanRed = getItem(position);

        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.adapter_ranglista, parent, false);

        TextView redniBroj = (TextView) convertView.findViewById(R.id.tvRedniBroj);
        TextView username = (TextView) convertView.findViewById(R.id.tvUsername);
        TextView ostvareniUcinak = (TextView) convertView.findViewById(R.id.tvProcenatTacnoOdogovrenih);

        String redniBrojReda = String.valueOf(position+1);
        redniBroj.setText(redniBrojReda);
        username.setText(jedanRed.getFirst());
        ostvareniUcinak.setText(String.valueOf(jedanRed.getSecond()));

        return convertView;
    }

}
