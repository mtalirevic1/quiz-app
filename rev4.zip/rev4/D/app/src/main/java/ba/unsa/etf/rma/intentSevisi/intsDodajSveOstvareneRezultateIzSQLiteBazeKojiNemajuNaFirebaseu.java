package ba.unsa.etf.rma.intentSevisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Par;
import ba.unsa.etf.rma.klase.Ranglista;

public class intsDodajSveOstvareneRezultateIzSQLiteBazeKojiNemajuNaFirebaseu extends IntentService
{
    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public intsDodajSveOstvareneRezultateIzSQLiteBazeKojiNemajuNaFirebaseu()
    {
        super(null);
    }

    public intsDodajSveOstvareneRezultateIzSQLiteBazeKojiNemajuNaFirebaseu(String name)
    {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        // Kod koji se nalazi ovdje će se izvršavati u posebnoj niti
        // Ovdje treba da se nalazi funkcionalnost servisa koja je
        // vremenski zahtjevna
        final ResultReceiver resultReceiver = intent.getParcelableExtra("risiver");

        ArrayList<Ranglista> sveRanglisteIzSQLiteBaze = (ArrayList<Ranglista>) intent.getSerializableExtra("sve rangliste iz sqlitea");

        String token = null;
        token = dajToken();

        Bundle bundle = new Bundle();

        ArrayList<Par> alRezultatiJedneRangliste = new ArrayList<>();
        boolean uspjesnoNapravljenaRangLista = false;
        int brojUspjesnoUcitanihRezultataUFirebaseKojiSuOstavreniDokNijeBiloInterneta = 0;

        //ako se igralo vise kvizova dok nije bilo interneta, to zanci da se vise dokuemnata na firebaseu treba azurirati
        for(int i=0; i<sveRanglisteIzSQLiteBaze.size(); i++)
        {
            Kviz kvizNaKojiSeOdnosiRanglista = sveRanglisteIzSQLiteBaze.get(i).getKviz();
            ArrayList<Par> ostvareniRezultatiZaOvaKvizIzSQLitea = sveRanglisteIzSQLiteBaze.get(i).getOstavreniRezultati();

            //ova petlja se odnosi na samo ranglistu za jedna kviz, tj. na sve njene ostavrene rezultate
            for(int j=0; j<sveRanglisteIzSQLiteBaze.get(i).getOstavreniRezultati().size(); j++)
            {
                if (daLiVecPostojiRanglistaZaKvizKojiSeIgrao(kvizNaKojiSeOdnosiRanglista, token) == false)
                {
                    //ako kviz nikada do sad nije igran
                    try
                    {
                        String spojenoIme = URLEncoder.encode(kvizNaKojiSeOdnosiRanglista.getNaziv(), "utf-8");

                        String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Rangliste?documentId=RANGLISTA"+spojenoIme;

                        URL urlObjekat = new URL(url);
                        HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                        konekcija.setRequestProperty("Authorization", "Bearer " + token);
                        konekcija.setRequestMethod("POST");
                        konekcija.setRequestProperty("Content-Type", "appliction/json");
                        konekcija.setRequestProperty("Accept", "appliation/json");

                        StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                                "{ \"nazivKviza\": { \"stringValue\": \"" + kvizNaKojiSeOdnosiRanglista.getNaziv() + "\"}, " +
                                " \"lista\" : { \"mapValue\" : { \"fields\" : { " +
                                " \"1\" : { \"mapValue\" : { \"fields\" : { " +
                                " \"" + ostvareniRezultatiZaOvaKvizIzSQLitea.get(j).getFirst() + "\" : { \"doubleValue\" : \"" + ostvareniRezultatiZaOvaKvizIzSQLitea.get(j).getSecond() + "\"}}}}" +
                                " }}}}}");

                        String dokument = dokuemntBilder.toString();

                        OutputStream outputStream = konekcija.getOutputStream();
                        byte[] unos = dokument.getBytes();
                        outputStream.write(unos, 0, unos.length);

                        InputStream odgovor = konekcija.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while ((responseLine = bufferedReader.readLine()) != null)
                            response.append(responseLine.trim());

                        Log.d("DODANO U RANG LISTU", response.toString());
                        uspjesnoNapravljenaRangLista = true;

                        brojUspjesnoUcitanihRezultataUFirebaseKojiSuOstavreniDokNijeBiloInterneta++;
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }
                else {
                    //ako je vec igran taj kviz, treba dodati novi rezultat i sortirati rezultate
                    //prvo sve ucitamo, sortiramo, pa onda vratimo

                    alRezultatiJedneRangliste.clear();
                    boolean uspjesnoUcitanaRangLista = false;
                    try
                    {
                        String query = "{\n" +
                                "\"structuredQuery\": {\n" +
                                "\"where\": {\n" +
                                "\"fieldFilter\": {\n" +
                                "\"field\": {\"fieldPath\": \"nazivKviza\"}, \n" +
                                "\"op\": \"EQUAL\",\n" +
                                "\"value\": {\"stringValue\": \"" + kvizNaKojiSeOdnosiRanglista.getNaziv() + "\"}\n" +
                                "}\n" +
                                "},\n" +
                                "\"select\": {\"fields\": [ {\"fieldPath\": \"nazivKviza\"}, {\"fieldPath\": \"lista\"} ] }, \n" +
                                "\"from\": [{\"collectionId\" : \"Rangliste\"}], \n" +
                                "\"limit\" : 1000\n" +
                                "}\n" +
                                "}";

                        String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents:runQuery";

                        URL urlObjekat = new URL(url);

                        HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                        konekcija.setRequestProperty("Authorization", "Bearer " + token);
                        konekcija.setRequestMethod("POST");
                        konekcija.setRequestProperty("Content-Type", "appliction/json");
                        konekcija.setRequestProperty("Accept", "appliation/json");

                        OutputStream outputStream = konekcija.getOutputStream();
                        byte[] unos = query.getBytes();
                        outputStream.write(unos, 0, unos.length);

                        InputStream odgovor = konekcija.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while ((responseLine = bufferedReader.readLine()) != null)
                            response.append(responseLine.trim());

                        //------------------------
                        JSONArray rezultatiKverija = new JSONArray(response.toString());
                        try
                        {
                            //ovdje ce vec baciti izuzetak ako kveri nije dao rezultate
                            JSONObject jedanRezultatKverijaIzuzetak = rezultatiKverija.getJSONObject(0);
                            JSONObject documentsIzuzetak = jedanRezultatKverijaIzuzetak.getJSONObject("document");
                            //----

                            for (int k = 0; k < rezultatiKverija.length(); k++)
                            {
                                JSONObject jedanRezultatKverija = rezultatiKverija.getJSONObject(k);
                                JSONObject document = jedanRezultatKverija.getJSONObject("document");

                                JSONObject jsonFields = document.getJSONObject("fields");

                                JSONObject jsonNaziv = jsonFields.getJSONObject("nazivKviza");
                                String nazivKviza = jsonNaziv.getString("stringValue");

                                JSONObject jsonLista = jsonFields.getJSONObject("lista");
                                JSONObject jsonMapValue1 = jsonLista.getJSONObject("mapValue");
                                JSONObject jsonFields2 = jsonMapValue1.getJSONObject("fields");

                                boolean ponavljajUcitavanje = true;
                                int brojac = 1;

                                while(ponavljajUcitavanje)
                                {
                                    //"username", "ostavreniRezultat" su kljuc i vrijednost
                                    Par parJedanRezultatIgre;

                                    try
                                    {
                                        JSONObject jsonRedniBrojKviza = jsonFields2.getJSONObject(String.valueOf(brojac));
                                        JSONObject jsonMapValue2 = jsonRedniBrojKviza.getJSONObject("mapValue");
                                        JSONObject jsonFields3 = jsonMapValue2.getJSONObject("fields");

                                        String stringFields3 = jsonFields3.toString();
                                        String[] uzmiIme = stringFields3.split("\"");
                                        String username = uzmiIme[1];

                                        JSONObject jsonUsername = jsonFields3.getJSONObject(username);
                                        double ostverniRezultat = jsonUsername.getDouble("doubleValue");

                                        parJedanRezultatIgre = new Par(username, ostverniRezultat);
                                        alRezultatiJedneRangliste.add(parJedanRezultatIgre);

                                        brojac++;
                                    }
                                    catch(JSONException e)
                                    {
                                        ponavljajUcitavanje = false;
                                    }
                                }
                            }
                        }
                        catch (JSONException e)
                        {
                            //KVERI NIJE VRATIO REZULTATE
                        }

                        uspjesnoUcitanaRangLista = true;

                    }
                    catch (JSONException e)
                    {
                        e.printStackTrace();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                    //nakon sto su iznad procitani svi clanovi iz rang liste, ubacujemo rezultat zadnjeg igranja
                    // (tj. igranja koji je doveo u ovaj initent servis)
                    Par parZaOvajRezultat = new Par(
                            ostvareniRezultatiZaOvaKvizIzSQLitea.get(j).getFirst(),
                            ostvareniRezultatiZaOvaKvizIzSQLitea.get(j).getSecond());

                    boolean vecPostojiNaFirebaseuOvajUnos = false;

                    for(int k=0; k<alRezultatiJedneRangliste.size(); k++)
                    {
                        if(parZaOvajRezultat.getFirst().equalsIgnoreCase(alRezultatiJedneRangliste.get(k).getFirst()) &&
                            Math.abs(parZaOvajRezultat.getSecond() - alRezultatiJedneRangliste.get(k).getSecond()) < 0.0001)
                        {
                            //znaci da ovaj unos vec postoji na firebaseu, i ne treba se ponovo dodavati
                            vecPostojiNaFirebaseuOvajUnos = true;
                            break;
                        }
                    }

                    if(vecPostojiNaFirebaseuOvajUnos == false)
                    {
                        alRezultatiJedneRangliste.add(parZaOvajRezultat);

                        //treba sortirati sve ostverene rezultate u ovom kvizu
                        for(int k=0; k<alRezultatiJedneRangliste.size(); k++)
                        {
                            int indeksMaksimalnog = k;

                            for(int l=k+1; l<alRezultatiJedneRangliste.size(); l++)
                            {
                                if(alRezultatiJedneRangliste.get(indeksMaksimalnog).getSecond() < alRezultatiJedneRangliste.get(l).getSecond() )
                                {
                                    indeksMaksimalnog = k;
                                }
                            }

                            Collections.swap(alRezultatiJedneRangliste, indeksMaksimalnog, k);
                        }

                        boolean uspjesnoPromjenjenaRangLista = false;
                        try
                        {
                            String spojenoIme = URLEncoder.encode(kvizNaKojiSeOdnosiRanglista.getNaziv(), "utf-8");

                            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Rangliste/RANGLISTA"+spojenoIme+"?currentDocument.exists=true";

                            URL urlObjekat = new URL(url);
                            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                            konekcija.setRequestProperty("Authorization", "Bearer "+token);
                            konekcija.setRequestMethod("PATCH");
                            konekcija.setRequestProperty("Content-Type", "appliction/json");
                            konekcija.setRequestProperty("Accept", "appliation/json");

                            StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                                    "{ \"nazivKviza\": { \"stringValue\": \"" + kvizNaKojiSeOdnosiRanglista.getNaziv() + "\"}, " +
                                    " \"lista\" : { \"mapValue\" : { \"fields\" : { ");
                            int pozicija = 1;
                            for(int k=0; k<alRezultatiJedneRangliste.size(); k++)
                            {
                                dokuemntBilder.append(" \""+pozicija+"\" : { \"mapValue\" : { \"fields\" : { " +
                                        " \"" + alRezultatiJedneRangliste.get(k).getFirst() + "\" : { \"doubleValue\" : \"" + alRezultatiJedneRangliste.get(k).getSecond() + "\"}}}}");

                                if(k != (alRezultatiJedneRangliste.size()-1))
                                    dokuemntBilder.append(", ");

                                pozicija++;
                            }
                            dokuemntBilder.append(" }}}}}");

                            String dokument = dokuemntBilder.toString();

                            OutputStream outputStream = konekcija.getOutputStream();
                            byte[] unos = dokument.getBytes();
                            outputStream.write(unos, 0, unos.length);

                            InputStream odgovor = konekcija.getInputStream();
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                            StringBuilder response = new StringBuilder();
                            String responseLine = null;
                            while((responseLine = bufferedReader.readLine()) != null)
                                response.append(responseLine.trim());

                            Log.d("ODGOVOR", response.toString());

                            uspjesnoPromjenjenaRangLista = true;
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }

                        brojUspjesnoUcitanihRezultataUFirebaseKojiSuOstavreniDokNijeBiloInterneta++;
                    }
                }
            }
        }

        bundle.putString("zadatak", "updjetovane ranglite na firebaseu na osnovu podataka iz sqlitea");
        bundle.putSerializable("brojUcitanihRezultataNaFirebase", brojUspjesnoUcitanihRezultataUFirebaseKojiSuOstavreniDokNijeBiloInterneta);
        resultReceiver.send(STATUS_FINISHED, bundle);
    }

    private boolean daLiVecPostojiRanglistaZaKvizKojiSeIgrao(Kviz kvizKojiSeIgra, String token)
    {
        try {
            String query = "{\n" +
                    "\"structuredQuery\": {\n" +
                    "\"where\": {\n" +
                    "\"fieldFilter\": {\n" +
                    "\"field\": {\"fieldPath\": \"nazivKviza\"}, \n" +
                    "\"op\": \"EQUAL\",\n" +
                    "\"value\": {\"stringValue\": \"" + kvizKojiSeIgra.getNaziv() + "\"}\n" +
                    "}\n" +
                    "},\n" +
                    "\"select\": {\"fields\": [ {\"fieldPath\": \"nazivKviza\"}, {\"fieldPath\": \"lista\"} ] }, \n" +
                    "\"from\": [{\"collectionId\" : \"Rangliste\"}], \n" +
                    "\"limit\" : 1000\n" +
                    "}\n" +
                    "}";

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents:runQuery";

            URL urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer " + token);
            konekcija.setRequestMethod("POST");
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            konekcija.setRequestProperty("Accept", "appliation/json");

            OutputStream outputStream = konekcija.getOutputStream();
            byte[] unos = query.getBytes();
            outputStream.write(unos, 0, unos.length);

            InputStream odgovor = konekcija.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = bufferedReader.readLine()) != null)
                response.append(responseLine.trim());

            //------------------------
            JSONArray rezultatiKverija = new JSONArray(response.toString());

            try
            {
                JSONObject jsonJedanRezultat = rezultatiKverija.getJSONObject(0);
                JSONObject jsonDokument = jsonJedanRezultat.getJSONObject("document");
                return true;
            }
            catch (JSONException e)
            {
                return false;
            }
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return false;
    }

    public String dajToken()
    {
        String token = null;

        try
        {
            InputStream is = getBaseContext().getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = null;
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            token = credentials.getAccessToken();

            is.close();
            //Log.d("TOKEN", token);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return token;
    }

    public String convertStreamToString(InputStream is)
    {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        StringBuilder sb = new StringBuilder();
        String line = null;
        try
        {
            while ((line = reader.readLine()) != null)
                sb.append(line + "\n");
        }
        catch (IOException e)
        {
            e.getStackTrace();
        }
        finally
        {
            try
            {
                is.close();
            }
            catch (IOException e)
            {
                e.getStackTrace();
            }
        }

        return sb.toString();
    }
}

