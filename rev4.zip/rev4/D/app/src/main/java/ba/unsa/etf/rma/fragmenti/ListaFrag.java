package ba.unsa.etf.rma.fragmenti;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.SQLiteHelper.DAObazaHelper;
import ba.unsa.etf.rma.adapteri.AdapterListaKategorija;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

//OVO JE FRAGMENT POCETNOG PROZORA, TJ. "KvizoviAkt"
public class ListaFrag extends Fragment implements resultReceiverZaSveIntentServise.Receiver
{
    //ATRIBUTI
    private ListView listaKategorija;

    private ArrayList<Kviz> sviKvizovi;
    private ArrayList<Pitanje> svaPitanja;
    private ArrayList<Kategorija> sveKategorije;

    private AdapterListaKategorija adapterListaKategorija;

    private KadKlikneNaKategoriju kadKlikneNaKategoriju;

    private final Kategorija kategorijaSviFiktivnaKategorija = new Kategorija("Svi", "0");

    //INTERFEJS
    // (za spajajne fragmenta i aktivnosti)
    public interface KadKlikneNaKategoriju
    {
        public void klikNaKategoriju(Kategorija odabranaKategorija);
    }

    private boolean kreiranaFragmentIliOnRestart = true;
    private DAObazaHelper daoBazaHelper;
    private boolean imaInterneta = false;

    /*private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE"))
            {
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();

                if(kreiranaFragmentIliOnRestart == true)
                {
                    kreiranaFragmentIliOnRestart = false;
                    return;
                }

                //should check null because in airplane mode it will be null
                if(netInfo == null || netInfo.isConnected() == false)
                {
                    Log.w("BROADCAST:", "NEMA INTERNETA");
                    Toast.makeText(context, "NEMA INTERNETA FRAGMENT ListaFrag",Toast.LENGTH_LONG).show();

                    imaInterneta = false;

                    //KAD NEMA INTERNETA ZABRANJENO DODVANJE PITANJA, KVIZOVA, KATEGORIJA
                    if(listaKategorija != null)
                        listaKategorija.setOnItemClickListener(null);
                }
                else
                {
                    Toast.makeText(context, "IMA INTERNETA FRAGMENT ListaFrag",Toast.LENGTH_LONG).show();

                    imaInterneta = true;

                    if(listaKategorija != null)
                        staviOnItemClickListenerNaListuKategorija();

                    napuniAtributeNaOsnovuStanjaUFirebaseBaziDaBiApdejtovaoLoklanuSQLiteBazu();
                }
            }
        }
    };*/

    private void napuniAtributeNaOsnovuStanjaUFirebaseBaziDaBiApdejtovaoLoklanuSQLiteBazu()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, getActivity(), intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(ListaFrag.this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("apdejtovanje loklane SQLite baze", "apdjetuj");

        getActivity().startService(mojIntent);
    }

    private void postaviAtributKojiGovoriImaLiInterneta()
    {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        //should check null because in airplane mode it will be null
        if(netInfo == null || netInfo.isConnected() == false)
            imaInterneta = false;
        else
            imaInterneta = true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        kreiranaFragmentIliOnRestart = true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_lista, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);

        postaviAtributKojiGovoriImaLiInterneta();

        listaKategorija = (ListView) getView().findViewById(R.id.listaKategorija);

        if(getArguments() != null && getArguments().containsKey("sviKvizovi") && getArguments().containsKey("sveKategorije")
                && getArguments().containsKey("svaPitanja"))
        {
            sviKvizovi = (ArrayList<Kviz>) getArguments().getSerializable("sviKvizovi");
            sveKategorije = (ArrayList<Kategorija>) getArguments().getSerializable("sveKategorije");
            svaPitanja = (ArrayList<Pitanje>) getArguments().getSerializable("svaPitanja");

            adapterListaKategorija = new AdapterListaKategorija(getActivity(), R.layout.adapter_lista_s_ikonama, sveKategorije);
            listaKategorija.setAdapter(adapterListaKategorija);

            //if(imaInterneta == true)
            staviOnItemClickListenerNaListuKategorija();

            dodajFiktivnuKategorijuAkoNePostojiLokalno();
            azurirajSveInformacijeDaBuduKaoUBazi();
        }

        /*IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        getActivity().registerReceiver(broadcastReceiver, intentFilter1);*/
    }

    private void staviOnItemClickListenerNaListuKategorija()
    {
        listaKategorija.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                kadKlikneNaKategoriju = (KadKlikneNaKategoriju) getActivity();
                kadKlikneNaKategoriju.klikNaKategoriju(sveKategorije.get(position));
            }
        });
    }

    private void azurirajSveInformacijeDaBuduKaoUBazi()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, getActivity(), intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.class);

        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);

        getActivity().startService(mojIntent);
    }

    private void dodajFiktivnuKategorijuAkoNePostojiLokalno()
    {
        boolean imaKategorijeSvi = false;
        for(int i=0; i<sveKategorije.size(); i++)
        {
            if(sveKategorije.get(i).getNaziv().equalsIgnoreCase("Svi"))
            {
                imaKategorijeSvi = true;
                break;
            }
        }
        if(imaKategorijeSvi == false)
        {
            sveKategorije.add(kategorijaSviFiktivnaKategorija);
            adapterListaKategorija.notifyDataSetChanged();
        }
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        //getActivity().unregisterReceiver(broadcastReceiver);
    }

    //ovo je dodano da bi se vratile informacije iz intent servisa koji je pozvan
    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        switch (resultCode)
        {
            case intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */

                //AKO SE UCITAVAJU SVE INFORMACIJE IZ BAZE NA POCETKU RADA PROGRAMA
                if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeno sve iz baze"))
                {
                    sviKvizovi.clear();
                    sviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                    svaPitanja.clear();
                    svaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));

                    sveKategorije.clear();
                    sveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    dodajFiktivnuKategorijuAkoNePostojiLokalno();

                    adapterListaKategorija.notifyDataSetChanged();

                    /*for(int i = 0; i < sveKategorije.size(); i++)
                    {
                        if(sveKategorije.get(i).getNaziv().equals("Svi") && getActivity() != null)
                        {
                            kadKlikneNaKategoriju = (KadKlikneNaKategoriju) getActivity();
                            kadKlikneNaKategoriju.klikNaKategoriju(sveKategorije.get(i));
                        }
                    }*/

                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeni kvizovi iz kategorije"))
                {
                    //AKO SE UCITAVAJU KVIZOVI IZ SELEKTOVANE KATEGORIJE

                    ArrayList<Kviz> sviKvizoviIzBazeIzSelektovaneKategorije = (ArrayList<Kviz>) resultData.getSerializable("kvizoviIzOdabraneKategorije");
                    ArrayList<Pitanje> pitanjaIzKvizovaIzKategorije = (ArrayList<Pitanje>) resultData.getSerializable("svaPitanjaIzKvizovaIzKategorije");

                    //dodavanje kvizova lokalno, iz selektovane kategorije, kojih ima u bazi, a nema lokalno
                    for(int i=0; i < sviKvizoviIzBazeIzSelektovaneKategorije.size(); i++)
                    {
                        boolean dodajKviz = true;
                        for(int j=0; j < sviKvizovi.size(); j++)
                        {
                            if(sviKvizoviIzBazeIzSelektovaneKategorije.get(i).getNaziv().equals(sviKvizovi.get(j).getNaziv()))
                            {
                                dodajKviz = false;
                                break;
                            }
                        }

                        if(dodajKviz == true)
                            sviKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                    }

                    //dodavanje pitanja koji ne postoje lokalno, iz dobavlejnih kvizova su, a ima ih u bazi
                    for(int i=0; i < pitanjaIzKvizovaIzKategorije.size(); i++)
                    {
                        boolean dodajPitanje = true;
                        for(int j=0; j < svaPitanja.size(); j++)
                        {
                            if(pitanjaIzKvizovaIzKategorije.get(i).getNaziv().equals(svaPitanja.get(j).getNaziv()))
                            {
                                dodajPitanje = false;
                                break;
                            }
                        }

                        if(dodajPitanje == true)
                            sviKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                    }

                }
                adapterListaKategorija.notifyDataSetChanged();
                break;
            case intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kolekcije neke u bazi"))
                {
                    if(resultData.getSerializable("alSveKategorije") != null)
                    {
                        sveKategorije.clear();
                        sveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                        dodajFiktivnuKategorijuAkoNePostojiLokalno();
                    }

                    if(resultData.getSerializable("alSviKvizovi") != null)
                    {
                        sviKvizovi.clear();
                        sviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));
                    }

                    if(resultData.getSerializable("alSvaPitanja") != null)
                    {
                        svaPitanja.clear();
                        svaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                    }

                    /*for(int i = 0; i < sveKategorije.size(); i++)
                    {
                        if(sveKategorije.get(i).getNaziv().equals("Svi") && getActivity() != null)
                        {
                            kadKlikneNaKategoriju = (KadKlikneNaKategoriju) getActivity();
                            kadKlikneNaKategoriju.klikNaKategoriju(sveKategorije.get(i));
                        }
                    }*/
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kvizova u bazi"))
                {
                    Log.d("NEMA KVIZOVA U BAZI", "jos nije dodatn nijedan kviz u bazu");
                }

                break;
        }
    }
}
