package ba.unsa.etf.rma.SQLiteHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Par;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.Ranglista;


public class DAObazaHelper extends SQLiteOpenHelper
{
    //POSTO SU IMENA UNIKATNA, KORISTIT CEMO NJIH KAO id-EVE ZA KATEGORIJ, KVIZOVE I PITANJA, ALI NE I ODGOVORE I RANGLISTE

    //ime baze
    public static final String DATABASE_NAME = "kvizoviBaza.db";

    //tabele i njihove kolone
    public static final String DATABASE_TABLE_KATEGORIJE = "Kategorije";
    public static final String KATEGORIJA_ID = "_id";
    public static final String KATEGORIJA_IDIKONICE = "idIkonice";

    public static final String DATABASE_TABLE_KVIZOVI = "Kvizovi";
    public static final String KVIZ_ID = "_id";
    public static final String KVIZ_IDKATEGORIJE = "idKategorije";

    public static final String DATABASE_TABLE_PITANJA = "Pitanja";
    public static final String PITANJE_ID = "_id";
    //public static final String PITANJE_IDKVIZA = "idKviza";
    public static final String PITANJE_TACANODGOVOR = "tacanOdgovr";
    //bit ce kolona u tabeli odgovor u kojoj ce biti id kviza

    public static final String DATABASE_TABLE_ODGOVORI = "Odgovori";
    public static final String ODGOVORI_ID = "_id";
    public static final String ODGOVORI_IDPITANJA = "idPitanja";
    public static final String ODGOVORI_TEKST = "tekstOdgovora";

    public static final String DATABASE_TABLE_RANGLISTE = "Rangliste";
    public static final String RANGLISTA_ID = "_id";
    public static final String RANGLISTA_USERNAME = "username";
    public static final String RANGLISTA_OSTAVARENIREZULTAT = "ostvareniRezultat";
    public static final String RANGLISTA_IDKVIZA = "idKviza";

    public static final String DATABASE_TABLE_POVEZNA_KVIZ_PITANJE = "PoveznaKvizPitanje";
    public static final String POVEZNA_KVIZ_PITANJE_IDKVIZA = "idKviza";
    public static final String POVEZNA_KVIZ_PITANJE_IDPITANJA = "idPitanja";

    //verzija
    public static final int DATABASE_VERSION = 1;

    // SQL upiti za kreiranje baze
    //za "primary key" i "foreign key" se podrazumijeva da je "not null"
    private static final String napraviTabeluKategorije = "CREATE TABLE " + DATABASE_TABLE_KATEGORIJE +
                                                            " ( "+KATEGORIJA_ID+" TEXT PRIMARY KEY, "+
                                                            KATEGORIJA_IDIKONICE + " TEXT NOT NULL );";

    private static final String napraviTabeluKvizovi = "CREATE TABLE " + DATABASE_TABLE_KVIZOVI +
                                                        " ( "+KVIZ_ID+" TEXT PRIMARY KEY, " +
                                                        KVIZ_IDKATEGORIJE + " INTEGER NOT NULL, " +
            "CONSTRAINT constr_tab_kvizovi_idkategorije FOREIGN KEY ( "+KVIZ_IDKATEGORIJE+") REFERENCES "+DATABASE_TABLE_KATEGORIJE+" ( "+ KATEGORIJA_ID+" ) );";

    private static final String napraviPoveznuTabeluKvizPitanje = "CREATE TABLE " + DATABASE_TABLE_POVEZNA_KVIZ_PITANJE +
                                                                    " ( "+POVEZNA_KVIZ_PITANJE_IDKVIZA+" TEXT NOT NULL, "+
                                                                    POVEZNA_KVIZ_PITANJE_IDPITANJA + " TEXT NOT NULL, " +
            "CONSTRAINT constr_tab_povezna_idkviza FOREIGN KEY ( "+POVEZNA_KVIZ_PITANJE_IDKVIZA+") REFERENCES "+DATABASE_TABLE_KVIZOVI+" ( "+KVIZ_ID+" ), "+
            "CONSTRAINT constr_tab_povezna_idpitanja FOREIGN KEY ( "+POVEZNA_KVIZ_PITANJE_IDPITANJA+") REFERENCES "+DATABASE_TABLE_PITANJA+" ( "+PITANJE_ID+" ) "
            +");";

    private static final String napraviTabeluPitanja = "CREATE TABLE " + DATABASE_TABLE_PITANJA +
                                                        " ( "+PITANJE_ID+" TEXT PRIMARY KEY, " +
                                                        PITANJE_TACANODGOVOR + " TEXT NOT NULL);";
    //+" CONSTRAINT constr_tab_pitanja_idkviza FOREIGN KEY ( "+PITANJE_IDKVIZA+" ) REFERENCES "+DATABASE_TABLE_KVIZOVI+"("+ KVIZ_ID+") );";

    private static final String napraviTabeluOdgovori = "CREATE TABLE " + DATABASE_TABLE_ODGOVORI +
                                                        " ( "+ODGOVORI_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                                                        ODGOVORI_IDPITANJA + " TEXT NOT NULL, "+
                                                        ODGOVORI_TEKST + " TEXT NOT NULL, " +
            " CONSTRAINT constr_tab_odgovori_idpitanja FOREIGN KEY ( "+ODGOVORI_IDPITANJA+" ) REFERENCES "+DATABASE_TABLE_PITANJA+"("+PITANJE_ID+") );";


    private static final String napraviTabeluRangLista = "CREATE TABLE " + DATABASE_TABLE_RANGLISTE +
                                                        " ( "+RANGLISTA_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                                                        RANGLISTA_IDKVIZA + " TEXT NOT NULL, "+
                                                        RANGLISTA_OSTAVARENIREZULTAT + " REAL NOT NULL, "+
                                                        RANGLISTA_USERNAME + " TEXT NOT NULL, " +
            " CONSTRAINT constr_tab_ranglista_idkviza FOREIGN KEY ( "+RANGLISTA_IDKVIZA+" ) REFERENCES "+DATABASE_TABLE_KVIZOVI+"("+KVIZ_ID+"), "+
            " CONSTRAINT constr_tab_ranglista_ostvarenirezultat CHECK ( "+RANGLISTA_OSTAVARENIREZULTAT+" BETWEEN 0 AND 1) );";

    //KONSTRUKTOR
    public DAObazaHelper(Context context, String databaseName, SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, databaseName, factory, version);
    }

    public DAObazaHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //Poziva se kada ne postoji baza
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(napraviTabeluKategorije);
        db.execSQL(napraviTabeluKvizovi);
        db.execSQL(napraviTabeluPitanja);
        db.execSQL(napraviPoveznuTabeluKvizPitanje);
        db.execSQL(napraviTabeluOdgovori);
        db.execSQL(napraviTabeluRangLista);
    }

    // Poziva se kada se ne poklapaju verzije baze na disku i trenutne baze
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // KORAK I: Brisanje stare verzije
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_RANGLISTE);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_ODGOVORI);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_POVEZNA_KVIZ_PITANJE);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_PITANJA);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KVIZOVI);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KATEGORIJE);

        // KORAK II: Kreiranje nove
        onCreate(db);
    }

    public void izbrisiSveUnoseULoklnuSQLiteBazu(SQLiteDatabase db)
    {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_RANGLISTE);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_ODGOVORI);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_POVEZNA_KVIZ_PITANJE);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_PITANJA);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KVIZOVI);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_KATEGORIJE);

        db.execSQL(napraviTabeluKategorije);
        db.execSQL(napraviTabeluKvizovi);
        db.execSQL(napraviTabeluPitanja);
        db.execSQL(napraviPoveznuTabeluKvizPitanje);
        db.execSQL(napraviTabeluOdgovori);
        db.execSQL(napraviTabeluRangLista);
    }

    public boolean dodajKategorijuUTabeluKategorijeUSQLiteBazi(Kategorija kategorija)
    {
        if(postojiLiKvizUSQLiteBazi(kategorija.getNaziv()) == false)
        {
            ContentValues vrijednostiKojeSeUbacujuUTabelu = new ContentValues();

            vrijednostiKojeSeUbacujuUTabelu.put(KATEGORIJA_ID, kategorija.getNaziv());
            vrijednostiKojeSeUbacujuUTabelu.put(KATEGORIJA_IDIKONICE, kategorija.getId());

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_KATEGORIJE, null, vrijednostiKojeSeUbacujuUTabelu);

            return true;
        }

        return false;
    }

    public boolean dodajKvizUTabeluKvizoviUSQLiteBazi(Kviz kviz)
    {
        if(postojiLiKvizUSQLiteBazi(kviz.getNaziv()) == false)
        {
            ContentValues vrijednostiKojeSeUbacujuUTabelu = new ContentValues();

            vrijednostiKojeSeUbacujuUTabelu.put(KVIZ_ID, kviz.getNaziv());
            vrijednostiKojeSeUbacujuUTabelu.put(KVIZ_IDKATEGORIJE, kviz.getKategorija().getNaziv());

            for(int i=0; i<kviz.getPitanja().size(); i++)
            {
                if(postojiLiPitanjeUSQLiteBazi(kviz.getPitanja().get(i).getNaziv()) == false)
                    dodajPitanjeUTabeluPitanjaUSQLiteBazi(kviz.getPitanja().get(i));
            }

            dodajUPoveznuTabeluKvizovaIPitanjaSvePodatkeIzKviza(kviz);

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_KVIZOVI, null, vrijednostiKojeSeUbacujuUTabelu);

            return true;
        }

        return false;
    }

    public void dodajUPoveznuTabeluKvizovaIPitanjaSvePodatkeIzKviza(Kviz kviz)
    {
        for(int i=0; i<kviz.getPitanja().size(); i++)
        {
            if(postojiLiUnosUPoveznojTabeli(kviz, kviz.getPitanja().get(i)) == false)
            {
                ContentValues contentValues = new ContentValues();
                contentValues.put(POVEZNA_KVIZ_PITANJE_IDKVIZA, kviz.getNaziv());
                contentValues.put(POVEZNA_KVIZ_PITANJE_IDPITANJA, kviz.getPitanja().get(i).getNaziv());

                SQLiteDatabase db = this.getWritableDatabase();
                db.insert(DATABASE_TABLE_POVEZNA_KVIZ_PITANJE, null, contentValues);
            }
        }
    }

    public boolean dodajPitanjeUTabeluPitanjaUSQLiteBazi(Pitanje pitanje)
    {
        if(postojiLiPitanjeUSQLiteBazi(pitanje.getNaziv()) == false)
        {
            ContentValues vrijednostiKojeSeUbacujuUTabelu = new ContentValues();

            vrijednostiKojeSeUbacujuUTabelu.put(PITANJE_ID, pitanje.getNaziv());
            vrijednostiKojeSeUbacujuUTabelu.put(PITANJE_TACANODGOVOR, pitanje.getTacan());

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_PITANJA, null, vrijednostiKojeSeUbacujuUTabelu);

            for(int i=0; i<pitanje.getOdgovori().size(); i++)
                dodajOdgovorNaPitanjeUTabeluOdgovoriUSQLiteBazi(pitanje.getOdgovori().get(i), pitanje);

            return true;
        }

       return false;
    }

    public boolean dodajOdgovorNaPitanjeUTabeluOdgovoriUSQLiteBazi(String odgovor, Pitanje pitanje)
    {
        if(postojiLiOdgovorNaPitanjeUTabeliOdgovoriUSQLiteBazi(odgovor, pitanje) == false)
        {
            ContentValues vrijednostiKojeSeUbacujuUTabelu = new ContentValues();

            //ODGOVORI_ID je na autoincrement, sto znaci da ce se sam povecavati
            vrijednostiKojeSeUbacujuUTabelu.put(ODGOVORI_IDPITANJA, pitanje.getNaziv());
            vrijednostiKojeSeUbacujuUTabelu.put(ODGOVORI_TEKST, odgovor);

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_ODGOVORI, null, vrijednostiKojeSeUbacujuUTabelu);

            return true;
        }
        return false;
    }

    //ne posmatraj unos kao jednu ranglistu, vec kao jedan ostavreni rezultat prilikom igre kviza
    public boolean dodajJedanRezultatUTabeluRanglisteUSQLiteBazi(Par ostavreniRezultat, Kviz kviz)
    {
        if(postojiLiRezultatURanglistiUSQLiteBazi(kviz.getNaziv(), ostavreniRezultat.getFirst(), ostavreniRezultat.getSecond()) == false)
        {
            if(postojiLiKvizUSQLiteBazi(kviz.getNaziv()) == false)
                dodajKvizUTabeluKvizoviUSQLiteBazi(kviz);

            ContentValues vrijednostiKojeSeUbacujuUTabelu = new ContentValues();

            //RANLISTA_ID je na autoincrement, sto znaci da ce se sam povecavati
            vrijednostiKojeSeUbacujuUTabelu.put(RANGLISTA_IDKVIZA, kviz.getNaziv());
            vrijednostiKojeSeUbacujuUTabelu.put(RANGLISTA_OSTAVARENIREZULTAT, ostavreniRezultat.getSecond());
            vrijednostiKojeSeUbacujuUTabelu.put(RANGLISTA_USERNAME, ostavreniRezultat.getFirst());

            SQLiteDatabase db = this.getWritableDatabase();
            db.insert(DATABASE_TABLE_RANGLISTE, null, vrijednostiKojeSeUbacujuUTabelu);

            return true;
        }

        return false;
    }

    public void dodajSveRezultateZaJedanKvizUTabeluRanglisteUSQLiteBazi(ArrayList<Par> ostavreniRezultatiKviza, Kviz kviz)
    {
        for(int i=0; i<ostavreniRezultatiKviza.size(); i++)
        {
            if(postojiLiRezultatURanglistiUSQLiteBazi(kviz.getNaziv(), ostavreniRezultatiKviza.get(i).getFirst(),
                    ostavreniRezultatiKviza.get(i).getSecond()) == false)
            {
                ContentValues vrijednostiKojeSeUbacujuUTabelu = new ContentValues();

                //RANLISTA_ID je na autoincrement, sto znaci da ce se sam povecavati
                vrijednostiKojeSeUbacujuUTabelu.put(RANGLISTA_IDKVIZA, kviz.getNaziv());
                vrijednostiKojeSeUbacujuUTabelu.put(RANGLISTA_OSTAVARENIREZULTAT, ostavreniRezultatiKviza.get(i).getSecond());
                vrijednostiKojeSeUbacujuUTabelu.put(RANGLISTA_USERNAME, ostavreniRezultatiKviza.get(i).getFirst());

                SQLiteDatabase db = this.getWritableDatabase();
                db.insert(DATABASE_TABLE_RANGLISTE, null, vrijednostiKojeSeUbacujuUTabelu);
            }
        }
    }

    public void dodajSveUSQLiteBazu(ArrayList<Kategorija> sveKategorijeSaFirebasea, ArrayList<Kviz> sviKvizoviSaFirebasea,
                                    ArrayList<Pitanje> svaPitanjaSaFirebasea, ArrayList<Ranglista> sveRanglisteSaFirebasea)
    {
        for(int i=0; i<sveKategorijeSaFirebasea.size(); i++)
            dodajKategorijuUTabeluKategorijeUSQLiteBazi(sveKategorijeSaFirebasea.get(i));

        for(int i=0; i<svaPitanjaSaFirebasea.size(); i++)
            dodajPitanjeUTabeluPitanjaUSQLiteBazi(svaPitanjaSaFirebasea.get(i));

        for(int i=0; i<sviKvizoviSaFirebasea.size(); i++)
            dodajKvizUTabeluKvizoviUSQLiteBazi(sviKvizoviSaFirebasea.get(i));

        for(int i=0; i<sveRanglisteSaFirebasea.size(); i++)
        {
            for(int j=0; j<sveRanglisteSaFirebasea.get(i).getOstavreniRezultati().size(); j++)
            {
                dodajSveRezultateZaJedanKvizUTabeluRanglisteUSQLiteBazi(sveRanglisteSaFirebasea.get(i).getOstavreniRezultati(),
                        sveRanglisteSaFirebasea.get(i).getKviz());
            }
        }
    }

    //vrati sve iz baze
    public Bundle dajSveIzSQLiteBaze()
    {
        Bundle sviPodaciIzSQLiteBaze = new Bundle();

        ArrayList<Kategorija> sveKategorijeIzSQLiteBaze = dajSveKategorijeSQLiteBaze();
        ArrayList<Pitanje> svaPitanjaIzSQLiteBaze = dajSvaPitanjaSQLiteBaze();
        ArrayList<Kviz> sviKvizoviIzSQLiteBaze = dajSveKvizoveSQLiteBaze();

        sviPodaciIzSQLiteBaze.putSerializable("sveKategorijeIzSQLiteBaze", sveKategorijeIzSQLiteBaze);
        sviPodaciIzSQLiteBaze.putSerializable("svaPitanjaIzSQLiteBaze", svaPitanjaIzSQLiteBaze);
        sviPodaciIzSQLiteBaze.putSerializable("sviKvizoviIzSQLiteBaze", sviKvizoviIzSQLiteBaze);

        return sviPodaciIzSQLiteBaze;
    }

    //vrati sve iz jedne tabele
    public ArrayList<Kategorija> dajSveKategorijeSQLiteBaze()
    {
        ArrayList<Kategorija> sveKategorijeIzSQLiteBaze = new ArrayList<>();
        //sve kolone koje ce se naci u upitu
        String[] koloneUUpitu = new String[]{KATEGORIJA_ID, KATEGORIJA_IDIKONICE};
        String whereUslov = null;
        String whereArgs[] = null;
        String groupBy = null;
        String having = null;
        String orderBy = null;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor kursorUpitZaKategorije = db.query(DATABASE_TABLE_KATEGORIJE, koloneUUpitu, whereUslov, whereArgs, groupBy, having, orderBy);

        int INDEX_KOLONE_KATEGORIJA_ID = kursorUpitZaKategorije.getColumnIndexOrThrow(KATEGORIJA_ID);
        int INDEX_KOLONE_KATEGORIJA_IDIKONICE = kursorUpitZaKategorije.getColumnIndexOrThrow(KATEGORIJA_IDIKONICE);

        while(kursorUpitZaKategorije.moveToNext())
        {
            Kategorija upravoUcitanaKategorija = new Kategorija();
            upravoUcitanaKategorija.setNaziv(kursorUpitZaKategorije.getString(INDEX_KOLONE_KATEGORIJA_ID));
            upravoUcitanaKategorija.setId(kursorUpitZaKategorije.getString(INDEX_KOLONE_KATEGORIJA_IDIKONICE));

            sveKategorijeIzSQLiteBaze.add(upravoUcitanaKategorija);
        }

        kursorUpitZaKategorije.close();

        return sveKategorijeIzSQLiteBaze;
    }

    public String dajStringKojimJePrikazanoStanjeTabeleKategorijeULokalnojSQLiteBazi()
    {
        StringBuilder stanjeTabeleKategorijaUSQLiteu = new StringBuilder("TABELA KATEGORIJE: \n");
        String kolona1 = prosiriStringDaBiTabeleIzgledalePrirodnije("KATEGROIJA_ID");
        String kolona2 = prosiriStringDaBiTabeleIzgledalePrirodnije("KATEGORIJA_IDIKONICE");
        String okvirTabele = dajOkvirTabeleNaOsnovuBrojaKolona(2);
        stanjeTabeleKategorijaUSQLiteu.append("KOLONE:\n|"+kolona1+" | "+kolona2+" | \n");
        stanjeTabeleKategorijaUSQLiteu.append(okvirTabele);

        //sve kolone koje ce se naci u upitu
        String[] koloneUUpitu = new String[]{KATEGORIJA_ID, KATEGORIJA_IDIKONICE};
        String whereUslov = null;
        String whereArgs[] = null;
        String groupBy = null;
        String having = null;
        String orderBy = null;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor kursorUpitZaKategorije = db.query(DATABASE_TABLE_KATEGORIJE, koloneUUpitu, whereUslov, whereArgs, groupBy, having, orderBy);

        int INDEX_KOLONE_KATEGORIJA_ID = kursorUpitZaKategorije.getColumnIndexOrThrow(KATEGORIJA_ID);
        int INDEX_KOLONE_KATEGORIJA_IDIKONICE = kursorUpitZaKategorije.getColumnIndexOrThrow(KATEGORIJA_IDIKONICE);

        while(kursorUpitZaKategorije.moveToNext())
        {
            String stringKATEGORIJA_ID = kursorUpitZaKategorije.getString(INDEX_KOLONE_KATEGORIJA_ID);
            stringKATEGORIJA_ID = prosiriStringDaBiTabeleIzgledalePrirodnije(stringKATEGORIJA_ID);

            String stringKATEGORIJA_IDIKONICE = kursorUpitZaKategorije.getString(INDEX_KOLONE_KATEGORIJA_IDIKONICE);
            stringKATEGORIJA_IDIKONICE = prosiriStringDaBiTabeleIzgledalePrirodnije(stringKATEGORIJA_IDIKONICE);

            stanjeTabeleKategorijaUSQLiteu.append("|  "+stringKATEGORIJA_ID+" | "+stringKATEGORIJA_IDIKONICE+"  |\n");
        }
        kursorUpitZaKategorije.close();

        stanjeTabeleKategorijaUSQLiteu.append(okvirTabele+"\n");

        return stanjeTabeleKategorijaUSQLiteu.toString();
    }

    public ArrayList<Kviz> dajSveKvizoveSQLiteBaze()
    {
        ArrayList<Kviz> sviKvizoviIzSQLiteBaze = new ArrayList<>();

        //ucitavanje svih kvizova iz sqlite baze
        String query = "SELECT * FROM "+
                DATABASE_TABLE_KVIZOVI;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabeleKvizovi = db.rawQuery(query, null);

        int INDEX_KOLONE_KVIZ_ID = kursorPretragaCijeleTabeleKvizovi.getColumnIndexOrThrow(KVIZ_ID);
        int INDEX_KOLONE_KVIZ_IDKATEGORIJE = kursorPretragaCijeleTabeleKvizovi.getColumnIndexOrThrow(KVIZ_IDKATEGORIJE);

        while(kursorPretragaCijeleTabeleKvizovi.moveToNext())
        {
            Kviz novoprocitaniKviz =  new Kviz();
            novoprocitaniKviz.setNaziv(kursorPretragaCijeleTabeleKvizovi.getString(INDEX_KOLONE_KVIZ_ID));

            String nazivKategorije = kursorPretragaCijeleTabeleKvizovi.getString(INDEX_KOLONE_KVIZ_IDKATEGORIJE);
            //ucitavanje kategorije kviza na osnovu id-a kviza
            novoprocitaniKviz.setKategorija(pretraziTabeluKategorijePoIduKategorije(nazivKategorije));

            //ucitavanje pitanja kviza na osnovu id-a kviza
            novoprocitaniKviz.setPitanja(pretraziTabeluPitanjaPoIduKvizaUzPomocPovezne(novoprocitaniKviz.getNaziv()));

            sviKvizoviIzSQLiteBaze.add(novoprocitaniKviz);
        }

        kursorPretragaCijeleTabeleKvizovi.close();

        return sviKvizoviIzSQLiteBaze;
    }

    public String dajStringKojimJePrikazanoStanjeTabeleKvizoviULokalnojSQLiteBazi()
    {
        StringBuilder stanjeTabeleKvizoviUSQLiteu = new StringBuilder("TABELA KVIZOVI: \n");
        String kolona1 = prosiriStringDaBiTabeleIzgledalePrirodnije("KVIZ_ID");
        String kolona2 = prosiriStringDaBiTabeleIzgledalePrirodnije("KVIZ_IDKATEGORIJE");
        stanjeTabeleKvizoviUSQLiteu.append("KOLONE:\n|"+kolona1+" | "+kolona2+" | \n");
        String okviTabele = dajOkvirTabeleNaOsnovuBrojaKolona(2);
        stanjeTabeleKvizoviUSQLiteu.append(okviTabele);

        //ucitavanje svih kvizova iz sqlite baze
        String query = "SELECT * FROM "+
                DATABASE_TABLE_KVIZOVI;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabeleKvizovi = db.rawQuery(query, null);

        int INDEX_KOLONE_KVIZ_ID = kursorPretragaCijeleTabeleKvizovi.getColumnIndexOrThrow(KVIZ_ID);
        int INDEX_KOLONE_KVIZ_IDKATEGORIJE = kursorPretragaCijeleTabeleKvizovi.getColumnIndexOrThrow(KVIZ_IDKATEGORIJE);

        while(kursorPretragaCijeleTabeleKvizovi.moveToNext())
        {
            String stringKVIZ_ID = kursorPretragaCijeleTabeleKvizovi.getString(INDEX_KOLONE_KVIZ_ID);
            stringKVIZ_ID = prosiriStringDaBiTabeleIzgledalePrirodnije(stringKVIZ_ID);

            String stringKVIZ_IDKATEGORIJE = kursorPretragaCijeleTabeleKvizovi.getString(INDEX_KOLONE_KVIZ_IDKATEGORIJE);
            stringKVIZ_IDKATEGORIJE = prosiriStringDaBiTabeleIzgledalePrirodnije(stringKVIZ_IDKATEGORIJE);

            stanjeTabeleKvizoviUSQLiteu.append("|  "+stringKVIZ_ID+" | "+stringKVIZ_IDKATEGORIJE+"  |\n");
        }
        kursorPretragaCijeleTabeleKvizovi.close();

        stanjeTabeleKvizoviUSQLiteu.append(okviTabele+"\n");

        return stanjeTabeleKvizoviUSQLiteu.toString();
    }

    public ArrayList<Pitanje> dajSvaPitanjaSQLiteBaze()
    {
        ArrayList<Pitanje> svaPitanjaIzSQLiteBaze = new ArrayList<>();

        //ucitavanje svih pitanja iz sqlite baze
        String query = "SELECT * FROM "+
                DATABASE_TABLE_PITANJA;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabelePitanja = db.rawQuery(query, null);

        int INDEX_KOLONE_PITANJE_ID = kursorPretragaCijeleTabelePitanja.getColumnIndexOrThrow(PITANJE_ID);
        int INDEX_KOLONE_PITANJE_TACANODGOVOR = kursorPretragaCijeleTabelePitanja.getColumnIndexOrThrow(PITANJE_TACANODGOVOR);

        while(kursorPretragaCijeleTabelePitanja.moveToNext())
        {
            Pitanje novoprocitanoPitanje = new Pitanje();

            novoprocitanoPitanje.setNaziv(kursorPretragaCijeleTabelePitanja.getString(INDEX_KOLONE_PITANJE_ID));
            novoprocitanoPitanje.setTekstPitanja(novoprocitanoPitanje.getNaziv());
            novoprocitanoPitanje.setTacan(kursorPretragaCijeleTabelePitanja.getString(INDEX_KOLONE_PITANJE_TACANODGOVOR));

            //ucitavanje odgovora na pitanje na osnovu id-a pitanja (tj. naziva pitanja)
            novoprocitanoPitanje.setOdgovori(pretraziTabeluOdvogvoriPoIduPitanja(novoprocitanoPitanje.getNaziv()));

            svaPitanjaIzSQLiteBaze.add(novoprocitanoPitanje);
        }

        kursorPretragaCijeleTabelePitanja.close();

        return svaPitanjaIzSQLiteBaze;
    }

    public String dajStringKojimJePrikazanoStanjeTabelePitanjaULokalnojSQLiteBazi()
    {
        StringBuilder stanjeTabelePitanjaUSQLiteu = new StringBuilder("TABELA PITANJA: \n");
        String kolona1 = prosiriStringDaBiTabeleIzgledalePrirodnije("PITANJE_ID");
        String kolona2 = prosiriStringDaBiTabeleIzgledalePrirodnije("PITANJE_TACANODGVOR");
        stanjeTabelePitanjaUSQLiteu.append("KOLONE:\n|"+kolona1+" | "+kolona2+" | \n");
        String okvirTabele = dajOkvirTabeleNaOsnovuBrojaKolona(2);
        stanjeTabelePitanjaUSQLiteu.append(okvirTabele);

        String query = "SELECT * FROM "+
                DATABASE_TABLE_PITANJA;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabelePitanja = db.rawQuery(query, null);

        int INDEX_KOLONE_PITANJE_ID = kursorPretragaCijeleTabelePitanja.getColumnIndexOrThrow(PITANJE_ID);
        int INDEX_KOLONE_PITANJE_TACANODGOVOR = kursorPretragaCijeleTabelePitanja.getColumnIndexOrThrow(PITANJE_TACANODGOVOR);

        while(kursorPretragaCijeleTabelePitanja.moveToNext())
        {
            String stringPITANJE_ID = kursorPretragaCijeleTabelePitanja.getString(INDEX_KOLONE_PITANJE_ID);
            stringPITANJE_ID = prosiriStringDaBiTabeleIzgledalePrirodnije(stringPITANJE_ID);

            String stringPITANJETACANODGOVOR = kursorPretragaCijeleTabelePitanja.getString(INDEX_KOLONE_PITANJE_TACANODGOVOR);
            stringPITANJETACANODGOVOR = prosiriStringDaBiTabeleIzgledalePrirodnije(stringPITANJETACANODGOVOR);

            stanjeTabelePitanjaUSQLiteu.append("|  "+stringPITANJE_ID+" | "+stringPITANJETACANODGOVOR+"  |\n");
        }
        kursorPretragaCijeleTabelePitanja.close();

        stanjeTabelePitanjaUSQLiteu.append(okvirTabele+"\n");

        return stanjeTabelePitanjaUSQLiteu.toString();
    }

    public ArrayList<Ranglista> dajSveOstvareneRezultateIzTabeleRangListe()
    {
        ArrayList<Ranglista> sviRezultatiIzTabeleRangListe = new ArrayList<>();

        //ucitavanje svih ranglista iz sqlite baze
        String query = "SELECT * FROM "+
                DATABASE_TABLE_RANGLISTE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabeleRanglista = db.rawQuery(query, null);

        int INDEX_KOLONE_RANGLISTA_OSTAVARENIREZULTAT = kursorPretragaCijeleTabeleRanglista.getColumnIndexOrThrow(RANGLISTA_OSTAVARENIREZULTAT);
        int INDEX_KOLONE_RANGLISTA_IDKVIZA = kursorPretragaCijeleTabeleRanglista.getColumnIndexOrThrow(RANGLISTA_IDKVIZA);
        int INDEX_KOLONE_RANGLISTA_USERNAME = kursorPretragaCijeleTabeleRanglista.getColumnIndexOrThrow(RANGLISTA_USERNAME);

        while(kursorPretragaCijeleTabeleRanglista.moveToNext())
        {
            //posto klasa "Ranglista" ima samo konstruktor sa jednim parametnom u koji s eprosljedjuje kviz, prvo se on mora procitati
            String nazivKviza = kursorPretragaCijeleTabeleRanglista.getString(INDEX_KOLONE_RANGLISTA_IDKVIZA);
            boolean vecPostojiRanglistaZaOvajKviz = false;
            for(int i=0; i<sviRezultatiIzTabeleRangListe.size(); i++)
            {
                if(nazivKviza.equalsIgnoreCase(sviRezultatiIzTabeleRangListe.get(i).getKviz().getNaziv()))
                {
                    vecPostojiRanglistaZaOvajKviz = true;
                    break;
                }
            }

            if(vecPostojiRanglistaZaOvajKviz == false)
            {
                Kviz kvizKojemOdgovaraOvaRanglista = pretraziTabeluKvizoviPoIduKviza(nazivKviza);

                Ranglista novoprocitanaRanglista = new Ranglista(kvizKojemOdgovaraOvaRanglista);

                ArrayList<Par> rezultatiKojiOdgovorajuOvojRanglisti = pretraziTabeluRanglistaPoIduKviza(nazivKviza);
                novoprocitanaRanglista.setOstavreniRezultati(rezultatiKojiOdgovorajuOvojRanglisti);

                sviRezultatiIzTabeleRangListe.add(novoprocitanaRanglista);
            }
        }

        kursorPretragaCijeleTabeleRanglista.close();

        return sviRezultatiIzTabeleRangListe;
    }

    public String dajStringKojimJePrikazanoStanjeTabeleRanglistaULokalnojSQLiteBazi()
    {
        StringBuilder stanjeTabeleRanglistaUSQLiteu = new StringBuilder("TABELA RANGLISTA: \n");
        String kolona1 = prosiriStringDaBiTabeleIzgledalePrirodnije("RANGLISTA_ID");
        String kolona2 = prosiriStringDaBiTabeleIzgledalePrirodnije("RANGLISTA_IDKVIZA");
        String kolona3 = prosiriStringDaBiTabeleIzgledalePrirodnije("RANGLISTA_OSTVARENIREZULTAT");
        String kolona4 = prosiriStringDaBiTabeleIzgledalePrirodnije("RANGLISTA_USERNAME");
        stanjeTabeleRanglistaUSQLiteu.append("KOLONE:\n|"+kolona1+" | "+kolona2+" | "+kolona3+" | "+kolona4+" |\n");
        String okvirTabele = dajOkvirTabeleNaOsnovuBrojaKolona(4);
        stanjeTabeleRanglistaUSQLiteu.append(okvirTabele);

        //ucitavanje svih ranglista iz sqlite baze
        String query = "SELECT * FROM "+
                DATABASE_TABLE_RANGLISTE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabeleRanglista = db.rawQuery(query, null);

        int INDEX_KOLONE_RANGLISTA_ID = kursorPretragaCijeleTabeleRanglista.getColumnIndexOrThrow(RANGLISTA_ID);
        int INDEX_KOLONE_RANGLISTA_IDKVIZA = kursorPretragaCijeleTabeleRanglista.getColumnIndexOrThrow(RANGLISTA_IDKVIZA);
        int INDEX_KOLONE_RANGLISTA_OSTAVARENIREZULTAT = kursorPretragaCijeleTabeleRanglista.getColumnIndexOrThrow(RANGLISTA_OSTAVARENIREZULTAT);
        int INDEX_KOLONE_RANGLISTA_USERNAME = kursorPretragaCijeleTabeleRanglista.getColumnIndexOrThrow(RANGLISTA_USERNAME);

        while(kursorPretragaCijeleTabeleRanglista.moveToNext())
        {
            //posto klasa "Ranglista" ima samo konstruktor sa jednim parametnom u koji s eprosljedjuje kviz, prvo se on mora procitati
            String stringRANGLISTA_ID = kursorPretragaCijeleTabeleRanglista.getString(INDEX_KOLONE_RANGLISTA_ID);
            stringRANGLISTA_ID = prosiriStringDaBiTabeleIzgledalePrirodnije(stringRANGLISTA_ID);

            String stringRANGLISTA_IDKVIZA = kursorPretragaCijeleTabeleRanglista.getString(INDEX_KOLONE_RANGLISTA_IDKVIZA);
            stringRANGLISTA_IDKVIZA = prosiriStringDaBiTabeleIzgledalePrirodnije(stringRANGLISTA_IDKVIZA);

            String stringRANGLISTA_OSTVARENIREZULTAT = String.valueOf(kursorPretragaCijeleTabeleRanglista.getDouble(INDEX_KOLONE_RANGLISTA_OSTAVARENIREZULTAT));
            stringRANGLISTA_OSTVARENIREZULTAT = prosiriStringDaBiTabeleIzgledalePrirodnije(stringRANGLISTA_OSTVARENIREZULTAT);

            String stringRANGLISTA_USERNAME = kursorPretragaCijeleTabeleRanglista.getString(INDEX_KOLONE_RANGLISTA_USERNAME);
            stringRANGLISTA_USERNAME = prosiriStringDaBiTabeleIzgledalePrirodnije(stringRANGLISTA_USERNAME);

            stanjeTabeleRanglistaUSQLiteu.append("|  "+stringRANGLISTA_ID+" | "+stringRANGLISTA_IDKVIZA+" | "+stringRANGLISTA_OSTVARENIREZULTAT+
                    " | "+ stringRANGLISTA_USERNAME+"  |\n");
        }
        kursorPretragaCijeleTabeleRanglista.close();

        stanjeTabeleRanglistaUSQLiteu.append(okvirTabele+ "\n");

        return stanjeTabeleRanglistaUSQLiteu.toString();
    }

    public String dajStringKojimJePrikazanoStanjeTabeleOdgovoriULokalnojSQLiteBazi()
    {
        StringBuilder stanjeTabeleOdgovoriUSQLiteu = new StringBuilder("TABELA ODGVORI: \n");
        String kolona1 = prosiriStringDaBiTabeleIzgledalePrirodnije("ODGOVORI_ID");
        String kolona2 = prosiriStringDaBiTabeleIzgledalePrirodnije("ODGOVORI_IDPITANJA");
        String kolona3 = prosiriStringDaBiTabeleIzgledalePrirodnije("ODGOVORI_TEKST");
        stanjeTabeleOdgovoriUSQLiteu.append("KOLONE:\n|"+kolona1+" | "+kolona2+" | "+kolona3+" | \n");
        String okvirTabele = dajOkvirTabeleNaOsnovuBrojaKolona(3);
        stanjeTabeleOdgovoriUSQLiteu.append(okvirTabele);

        //ucitavanje svih ranglista iz sqlite baze
        String query = "SELECT * FROM "+
                DATABASE_TABLE_ODGOVORI;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabeleOdgovori = db.rawQuery(query, null);

        int INDEX_KOLONE_ODGOVORI_ID = kursorPretragaCijeleTabeleOdgovori.getColumnIndexOrThrow(ODGOVORI_ID);
        int INDEX_KOLONE_ODGOVORI_IDPITANJA = kursorPretragaCijeleTabeleOdgovori.getColumnIndexOrThrow(ODGOVORI_IDPITANJA);
        int INDEX_KOLONE_ODGOVORI_TEKST = kursorPretragaCijeleTabeleOdgovori.getColumnIndexOrThrow(ODGOVORI_TEKST);

        while(kursorPretragaCijeleTabeleOdgovori.moveToNext())
        {
            //posto klasa "Ranglista" ima samo konstruktor sa jednim parametnom u koji s eprosljedjuje kviz, prvo se on mora procitati
            String stringODGOVORI_ID = kursorPretragaCijeleTabeleOdgovori.getString(INDEX_KOLONE_ODGOVORI_ID);
            stringODGOVORI_ID = prosiriStringDaBiTabeleIzgledalePrirodnije(stringODGOVORI_ID);

            String stringODGOVORI_IDPITANJA = kursorPretragaCijeleTabeleOdgovori.getString(INDEX_KOLONE_ODGOVORI_IDPITANJA);
            stringODGOVORI_IDPITANJA = prosiriStringDaBiTabeleIzgledalePrirodnije(stringODGOVORI_IDPITANJA);

            String stringODGOVORI_TEKST = String.valueOf(kursorPretragaCijeleTabeleOdgovori.getString(INDEX_KOLONE_ODGOVORI_TEKST));
            stringODGOVORI_TEKST = prosiriStringDaBiTabeleIzgledalePrirodnije(stringODGOVORI_TEKST);

            stanjeTabeleOdgovoriUSQLiteu.append("|  "+stringODGOVORI_ID+" | "+stringODGOVORI_IDPITANJA+" | "+stringODGOVORI_TEKST+"  |\n");
        }
        kursorPretragaCijeleTabeleOdgovori.close();

        stanjeTabeleOdgovoriUSQLiteu.append(okvirTabele+"\n");

        return stanjeTabeleOdgovoriUSQLiteu.toString();
    }

    public String dajStringKojimJePrikazanoStanjePovezneTabeleKvizovaIPitanjaULokalnojSQLiteBazi()
    {
        StringBuilder stanjeTabeleOdgovoriUSQLiteu = new StringBuilder("POVEZNA TABELAA IZMEDJU PITANJA I KVIZOVA: \n");
        String kolona1 = prosiriStringDaBiTabeleIzgledalePrirodnije("POVEZNA_KVIZ_PITANJE_IDPITANJA");
        String kolona2 = prosiriStringDaBiTabeleIzgledalePrirodnije("POVEZNA_KVIZ_PITANJE_IDKVIZA");
        stanjeTabeleOdgovoriUSQLiteu.append("KOLONE:\n|"+kolona1+" | "+kolona2+" |\n");
        String okvirTabele = dajOkvirTabeleNaOsnovuBrojaKolona(2);
        stanjeTabeleOdgovoriUSQLiteu.append(okvirTabele);

        //ucitavanje svih ranglista iz sqlite baze
        String query = "SELECT * FROM "+
                DATABASE_TABLE_POVEZNA_KVIZ_PITANJE;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijelePovezneTabeleIzmedjuPitanjaIKvizova = db.rawQuery(query, null);

        int INDEX_KOLONE_POVEZNA_KVIZ_PITANJE_IDPITANJA = kursorPretragaCijelePovezneTabeleIzmedjuPitanjaIKvizova.getColumnIndexOrThrow(POVEZNA_KVIZ_PITANJE_IDPITANJA);
        int INDEX_KOLONE_POVEZNA_KVIZ_PITANJE_IDKVIZA = kursorPretragaCijelePovezneTabeleIzmedjuPitanjaIKvizova.getColumnIndexOrThrow(POVEZNA_KVIZ_PITANJE_IDKVIZA);

        while(kursorPretragaCijelePovezneTabeleIzmedjuPitanjaIKvizova.moveToNext())
        {
            //posto klasa "Ranglista" ima samo konstruktor sa jednim parametnom u koji s eprosljedjuje kviz, prvo se on mora procitati
            String stringPOVEZNA_IDPITANJA = kursorPretragaCijelePovezneTabeleIzmedjuPitanjaIKvizova.getString(INDEX_KOLONE_POVEZNA_KVIZ_PITANJE_IDPITANJA);
            stringPOVEZNA_IDPITANJA = prosiriStringDaBiTabeleIzgledalePrirodnije(stringPOVEZNA_IDPITANJA);

            String stringPOVEZNA_IDKVIZA = kursorPretragaCijelePovezneTabeleIzmedjuPitanjaIKvizova.getString(INDEX_KOLONE_POVEZNA_KVIZ_PITANJE_IDKVIZA);
            stringPOVEZNA_IDKVIZA = prosiriStringDaBiTabeleIzgledalePrirodnije(stringPOVEZNA_IDKVIZA);

            stanjeTabeleOdgovoriUSQLiteu.append("|  "+stringPOVEZNA_IDPITANJA+" | "+stringPOVEZNA_IDKVIZA+"  |\n");
        }
        kursorPretragaCijelePovezneTabeleIzmedjuPitanjaIKvizova.close();

        stanjeTabeleOdgovoriUSQLiteu.append(okvirTabele+"\n");

        return stanjeTabeleOdgovoriUSQLiteu.toString();
    }

    public final static int SIRINA_KOLONE_PRI_ISPISU = 30;
    public String prosiriStringDaBiTabeleIzgledalePrirodnije(String stringKojiSeProsiruje)
    {
        int brojKarakteraKojiSeTrebaDodatiDaBiStringImaoDuzinu30 = SIRINA_KOLONE_PRI_ISPISU - stringKojiSeProsiruje.length();
        if(brojKarakteraKojiSeTrebaDodatiDaBiStringImaoDuzinu30 <= 0)
            return stringKojiSeProsiruje;

        StringBuilder stringBuilder = new StringBuilder(stringKojiSeProsiruje);
        for(int i=0; i<brojKarakteraKojiSeTrebaDodatiDaBiStringImaoDuzinu30; i++)
            stringBuilder.append(" ");

        return stringBuilder.toString();
    }

    private String dajOkvirTabeleNaOsnovuBrojaKolona(int brojKolonaUTabeli)
    {
        StringBuilder stringBuilder = new StringBuilder();

        for(int i=0; i<brojKolonaUTabeli*SIRINA_KOLONE_PRI_ISPISU; i++)
            stringBuilder.append("_");

        //zbog pregrada izmedju tabela i spacea sa obje strane te pregrade
        for(int i=0; i<brojKolonaUTabeli*3; i++)
            stringBuilder.append("_");

        stringBuilder.append("\n");
        return  stringBuilder.toString();
    }

    public String dajStringPrikazStanjaUSvimTabelamaUSQLiteBazi()
    {
        String tabelaKategorije = dajStringKojimJePrikazanoStanjeTabeleKategorijeULokalnojSQLiteBazi();
        String tabelaKvizovi = dajStringKojimJePrikazanoStanjeTabeleKvizoviULokalnojSQLiteBazi();
        String tabelaPitanja = dajStringKojimJePrikazanoStanjeTabelePitanjaULokalnojSQLiteBazi();
        String tabelaOdgovori = dajStringKojimJePrikazanoStanjeTabeleOdgovoriULokalnojSQLiteBazi();
        String poveznaTabelaPitanjaIKvizova = dajStringKojimJePrikazanoStanjePovezneTabeleKvizovaIPitanjaULokalnojSQLiteBazi();
        String tabelaRangliste = dajStringKojimJePrikazanoStanjeTabeleRanglistaULokalnojSQLiteBazi();

        return tabelaKategorije+tabelaKvizovi+tabelaPitanja+tabelaOdgovori+poveznaTabelaPitanjaIKvizova+tabelaRangliste;
    }

    //pretraga tabela po id-u
    public Kategorija pretraziTabeluKategorijePoIduKategorije(String  nazivKategorije)
    {
        Kategorija procitanaKategorijaIzSQLiteBaze = new Kategorija();
        procitanaKategorijaIzSQLiteBaze.setNaziv(nazivKategorije);

        String query = "SELECT * "+
                        " FROM "+DATABASE_TABLE_KATEGORIJE+
                        " WHERE "+KATEGORIJA_ID+" = '"+nazivKategorije+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaKategorijaPoIduKategorije = db.rawQuery(query, null);

        int INDEX_KOLONE_KATEGORIJA_IDIKONICE = kursorPretragaKategorijaPoIduKategorije.getColumnIndexOrThrow(KATEGORIJA_IDIKONICE);

        int brojac = 0;
        while(kursorPretragaKategorijaPoIduKategorije.moveToNext())
        {
            procitanaKategorijaIzSQLiteBaze.setId(kursorPretragaKategorijaPoIduKategorije.getString(INDEX_KOLONE_KATEGORIJA_IDIKONICE));

            brojac++;
        }

        kursorPretragaKategorijaPoIduKategorije.close();

        if(brojac != 1)
            Log.d("UPOZORENJE", "u sqlite bazi se nalazi vise ili nijedna kategorija koja se pokusala procitati");

        return procitanaKategorijaIzSQLiteBaze;
    }

    public Kviz pretraziTabeluKvizoviPoIduKviza(String nazivKviza)
    {
        Kviz kvizKojiOdgovoraProslijedjenomIdu = new Kviz();
        kvizKojiOdgovoraProslijedjenomIdu.setNaziv(nazivKviza);

        String query = "SELECT * "+
                        " FROM "+DATABASE_TABLE_KVIZOVI+
                        " WHERE "+KVIZ_ID+" = '"+nazivKviza+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabeleKvizovi = db.rawQuery(query, null);

        int INDEX_KOLONE_KVIZ_ID = kursorPretragaCijeleTabeleKvizovi.getColumnIndexOrThrow(KVIZ_ID);
        int INDEX_KOLONE_KVIZ_IDKATEGORIJE = kursorPretragaCijeleTabeleKvizovi.getColumnIndexOrThrow(KVIZ_IDKATEGORIJE);

        int brojac = 0;
        while(kursorPretragaCijeleTabeleKvizovi.moveToNext())
        {
            String nazivKategorije = kursorPretragaCijeleTabeleKvizovi.getString(INDEX_KOLONE_KVIZ_IDKATEGORIJE);
            //ucitavanje kategorije kviza na osnovu id-a kviza
            kvizKojiOdgovoraProslijedjenomIdu.setKategorija(pretraziTabeluKategorijePoIduKategorije(nazivKategorije));

            //ucitavanje pitanja kviza na osnovu id-a kviza
            kvizKojiOdgovoraProslijedjenomIdu.setPitanja(pretraziTabeluPitanjaPoIduKvizaUzPomocPovezne(nazivKviza));

            brojac++;
        }

        kursorPretragaCijeleTabeleKvizovi.close();

        if(brojac != 1)
            Log.d("UPOZORENJE", "u sqlite bazi se nalazi vise ili nijedan kviz koja se pokusala procitati na osnovu proslijedjenog ida");

        return kvizKojiOdgovoraProslijedjenomIdu;
    }

    public ArrayList<Kviz> pretraziTabeluKvizoviPoIduPitanjaUzPomocPovezne(String nazivPitanja)
    {
        ArrayList<Kviz> kvizoviKojiSadrzePitanje = new ArrayList<>();

        //pri radu sa poveznom tabelom izemdju kviza i pitanja, trebaju se ove tri tabele povezati (pogledaj where uslov)
        String query = "SELECT k."+KVIZ_ID+", k."+KVIZ_IDKATEGORIJE+
                " FROM "+DATABASE_TABLE_PITANJA+" p, "+DATABASE_TABLE_KVIZOVI+" k, "+DATABASE_TABLE_POVEZNA_KVIZ_PITANJE+" pkp"+
                " WHERE pkp."+POVEZNA_KVIZ_PITANJE_IDPITANJA+" = '"+nazivPitanja+"' AND pkp."+POVEZNA_KVIZ_PITANJE_IDKVIZA+" = "+
                " k."+KVIZ_ID+" AND pkp."+POVEZNA_KVIZ_PITANJE_IDPITANJA+" = p."+PITANJE_ID+";";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaKvizovaPoIduPitanja = db.rawQuery(query, null);

        int INDEX_KOLONE_KVIZ_ID = kursorPretragaKvizovaPoIduPitanja.getColumnIndexOrThrow(KVIZ_ID);
        int INDEX_KOLONE_KVIZ_IDKATEGORIJE= kursorPretragaKvizovaPoIduPitanja.getColumnIndexOrThrow(KVIZ_IDKATEGORIJE);

        while(kursorPretragaKvizovaPoIduPitanja.moveToNext())
        {
            Kviz novoprocitaniKviz = new Kviz();

            novoprocitaniKviz.setNaziv(kursorPretragaKvizovaPoIduPitanja.getString(INDEX_KOLONE_KVIZ_ID));

            String nazivKategorije = kursorPretragaKvizovaPoIduPitanja.getString(INDEX_KOLONE_KVIZ_IDKATEGORIJE);
            //ucitavanje kategorije kviza na osnovu id-a kviza
            novoprocitaniKviz.setKategorija(pretraziTabeluKategorijePoIduKategorije(nazivKategorije));

            //ucitavanje pitanja kviza na osnovu id-a kviza
            novoprocitaniKviz.setPitanja(pretraziTabeluPitanjaPoIduKvizaUzPomocPovezne(novoprocitaniKviz.getNaziv()));

            kvizoviKojiSadrzePitanje.add(novoprocitaniKviz);
        }

        kursorPretragaKvizovaPoIduPitanja.close();

        return kvizoviKojiSadrzePitanje;
    }

    public Pitanje pretraziTabeluPitanjaPoIduPitanja(String nazivPitanja)
    {
        Pitanje pitanjeKojeOdgovaraProslijedjenomIdu = new Pitanje();
        pitanjeKojeOdgovaraProslijedjenomIdu.setNaziv(nazivPitanja);
        pitanjeKojeOdgovaraProslijedjenomIdu.setTekstPitanja(pitanjeKojeOdgovaraProslijedjenomIdu.getNaziv());

        String query = "SELECT * "+
                " FROM "+DATABASE_TABLE_PITANJA+
                " WHERE "+PITANJE_ID+" = '"+nazivPitanja+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaCijeleTabelePitanjaPoIduPitanja = db.rawQuery(query, null);

        int INDEX_KOLONE_PITANJE_TACANODGOVORE= kursorPretragaCijeleTabelePitanjaPoIduPitanja.getColumnIndexOrThrow(PITANJE_TACANODGOVOR);

        int brojac = 0;
        while(kursorPretragaCijeleTabelePitanjaPoIduPitanja.moveToNext())
        {
            pitanjeKojeOdgovaraProslijedjenomIdu.setTacan(kursorPretragaCijeleTabelePitanjaPoIduPitanja.getString(INDEX_KOLONE_PITANJE_TACANODGOVORE));

            ArrayList<String> odgovoriNaPitanje = pretraziTabeluOdvogvoriPoIduPitanja(nazivPitanja);
            pitanjeKojeOdgovaraProslijedjenomIdu.setOdgovori(odgovoriNaPitanje);

            brojac++;
        }

        kursorPretragaCijeleTabelePitanjaPoIduPitanja.close();

        if(brojac != 1)
            Log.d("UPOZORENJE", "u sqlite bazi se nalazi vise ili nijedno pitanje koje se pokusalo procitati ne osnovu proslijedjenog ida pitanja");

        return pitanjeKojeOdgovaraProslijedjenomIdu;
    }

    public ArrayList<Pitanje> pretraziTabeluPitanjaPoIduKvizaUzPomocPovezne(String nazivKviza)
    {
        ArrayList<Pitanje> pitanjaUKvizu = new ArrayList<>();

        //pri radu sa poveznom tabelom izemdju kviza i pitanja, trebaju se ove tri tabele povezati (pogledaj where uslov)
        String query = "SELECT p."+PITANJE_ID+", p."+PITANJE_TACANODGOVOR+
                        " FROM "+DATABASE_TABLE_PITANJA+" p, "+DATABASE_TABLE_KVIZOVI+" k, "+DATABASE_TABLE_POVEZNA_KVIZ_PITANJE+" pkp"+
                        " WHERE pkp."+POVEZNA_KVIZ_PITANJE_IDKVIZA+" = '"+nazivKviza+"' AND pkp."+POVEZNA_KVIZ_PITANJE_IDKVIZA+" = "+
                        " k."+KVIZ_ID+" AND pkp."+POVEZNA_KVIZ_PITANJE_IDPITANJA+" = p."+PITANJE_ID+";";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaPitanjaPoIduKviza = db.rawQuery(query, null);

        int INDEX_KOLONE_PITANJE_ID = kursorPretragaPitanjaPoIduKviza.getColumnIndexOrThrow(PITANJE_ID);
        int INDEX_KOLONE_PITANJE_TACANODGOVOR = kursorPretragaPitanjaPoIduKviza.getColumnIndexOrThrow(PITANJE_TACANODGOVOR);

        while(kursorPretragaPitanjaPoIduKviza.moveToNext())
        {
            Pitanje novoprocitanoPitanje = new Pitanje();
            novoprocitanoPitanje.setNaziv(kursorPretragaPitanjaPoIduKviza.getString(INDEX_KOLONE_PITANJE_ID));
            novoprocitanoPitanje.setTekstPitanja(novoprocitanoPitanje.getNaziv());
            novoprocitanoPitanje.setTacan(kursorPretragaPitanjaPoIduKviza.getString(INDEX_KOLONE_PITANJE_TACANODGOVOR));

            //ucitavanje odgovora na pitanje na osnovu id-a pitanja (tj. naziva pitanja)
            novoprocitanoPitanje.setOdgovori(pretraziTabeluOdvogvoriPoIduPitanja(novoprocitanoPitanje.getNaziv()));

            pitanjaUKvizu.add(novoprocitanoPitanje);
        }

        kursorPretragaPitanjaPoIduKviza.close();

        return pitanjaUKvizu;
    }

    public ArrayList<String> pretraziTabeluOdvogvoriPoIduPitanja(String nazivPitanja)
    {
        ArrayList<String> odgovoriNaPitanje = new ArrayList<>();

        String query = "SELECT * "+
                        "FROM "+DATABASE_TABLE_ODGOVORI+
                        " WHERE "+ODGOVORI_IDPITANJA+" = '"+nazivPitanja+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaOdgvoraPoIduPitanja = db.rawQuery(query, null);

        int INDEX_KOLONE_ODGOVORI_TEKST = kursorPretragaOdgvoraPoIduPitanja.getColumnIndexOrThrow(ODGOVORI_TEKST);

        while(kursorPretragaOdgvoraPoIduPitanja.moveToNext())
        {
            odgovoriNaPitanje.add(kursorPretragaOdgvoraPoIduPitanja.getString(INDEX_KOLONE_ODGOVORI_TEKST));
        }

        kursorPretragaOdgvoraPoIduPitanja.close();

        return odgovoriNaPitanje;
    }

    public ArrayList<Par> pretraziTabeluRanglistaPoIduKviza(String nazivKviza)
    {
        ArrayList<Par> rezultatiKojiOdgovorajuProslijedjenomKvizu = new ArrayList<>();

        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_RANGLISTE+
                " WHERE "+RANGLISTA_IDKVIZA+" = '"+nazivKviza+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorPretragaTabeleRanglistaPoIduKviza = db.rawQuery(query, null);

        int INDEX_KOLONE_RANGLISTA_USERNAME = kursorPretragaTabeleRanglistaPoIduKviza.getColumnIndexOrThrow(RANGLISTA_USERNAME);
        int INDEX_KOLONE_RANGLISTA_OSTAVARENIREZULTAT = kursorPretragaTabeleRanglistaPoIduKviza.getColumnIndexOrThrow(RANGLISTA_OSTAVARENIREZULTAT);

        while(kursorPretragaTabeleRanglistaPoIduKviza.moveToNext())
        {
            String username = kursorPretragaTabeleRanglistaPoIduKviza.getString(INDEX_KOLONE_RANGLISTA_USERNAME);
            Double procentualnoOdgovorenihPitanja = kursorPretragaTabeleRanglistaPoIduKviza.getDouble(INDEX_KOLONE_RANGLISTA_OSTAVARENIREZULTAT);

            Par jedanRezultat = new Par(username, procentualnoOdgovorenihPitanja);

            rezultatiKojiOdgovorajuProslijedjenomKvizu.add(jedanRezultat);
        }

        kursorPretragaTabeleRanglistaPoIduKviza.close();

        return rezultatiKojiOdgovorajuProslijedjenomKvizu;
    }

    //izbaci iz tabele ako postoji u njoj
    public boolean apdejtujKvizUSQLiteBazi(Pair<Kviz, Kviz> stariLijeviUNoviDesni)
    {
        ContentValues updateValues = new ContentValues();

        updateValues.put(KVIZ_ID, stariLijeviUNoviDesni.second.getNaziv());

        //ako ne postoji kategorija novo(tj. modificiranog) kviza u bazi, dodaj jež
        if(postojiLiKategorijaUSQLiteBazi(stariLijeviUNoviDesni.second.getKategorija().getNaziv()) == false)
            dodajKategorijuUTabeluKategorijeUSQLiteBazi(stariLijeviUNoviDesni.second.getKategorija());

        updateValues.put(KVIZ_IDKATEGORIJE, stariLijeviUNoviDesni.second.getKategorija().getNaziv());

        apdejtujStanjeUSQLiteBaziAkoJeKvizPromijenjenTakoStoImaDrugacijaPitanja(stariLijeviUNoviDesni);

        String where = KVIZ_ID+" = '"+stariLijeviUNoviDesni.first.getNaziv()+"'";
        String whereArgs[] = null;

        SQLiteDatabase db = this.getWritableDatabase();
        int brojRedovaNaKojeJeUvajUpdateUticao = db.update(DATABASE_TABLE_KVIZOVI, updateValues, where, whereArgs);

        if(brojRedovaNaKojeJeUvajUpdateUticao == 1)
            return true;

        return false;
    }

    public void apdejtujStanjeUSQLiteBaziAkoJeKvizPromijenjenTakoStoImaDrugacijaPitanja(Pair<Kviz, Kviz> stariLijeviUNoviDesni)
    {
        //dupla petlja za izbacivanje pitanja koja su bila u kvizu prije edita
        for(int i=0; i<stariLijeviUNoviDesni.first.getPitanja().size(); i++)
        {
            boolean pitanjeJeJosUvijekUKvizu = false;

            for(int j=0; j<stariLijeviUNoviDesni.second.getPitanja().size(); j++)
            {
                if(stariLijeviUNoviDesni.first.getPitanja().get(i).getNaziv().equalsIgnoreCase(stariLijeviUNoviDesni.second.getPitanja().get(j).getNaziv()))
                {
                    pitanjeJeJosUvijekUKvizu = true;
                    break;
                }
            }

            if(pitanjeJeJosUvijekUKvizu == false)
            {
                String where = POVEZNA_KVIZ_PITANJE_IDPITANJA+" = '"+stariLijeviUNoviDesni.first.getPitanja().get(i).getNaziv()+"'";
                String whereArgs[] = null;
                SQLiteDatabase db = this.getWritableDatabase();
                db.delete(DATABASE_TABLE_POVEZNA_KVIZ_PITANJE, where, whereArgs);
            }
        }

        //dupla petlja za ubacivanje pitanja kojih nije bilo u starom kvizu, ali ima u novom
        for(int i=0; i<stariLijeviUNoviDesni.second.getPitanja().size(); i++)
        {
            boolean pitanjeDodatoTokomEdita = true;

            for(int j=0; j<stariLijeviUNoviDesni.first.getPitanja().size(); j++)
            {
                if(stariLijeviUNoviDesni.second.getPitanja().get(i).getNaziv().equalsIgnoreCase(stariLijeviUNoviDesni.first.getPitanja().get(j).getNaziv()))
                {
                    pitanjeDodatoTokomEdita = false;
                    break;
                }
            }

            if(pitanjeDodatoTokomEdita == true)
            {
                ContentValues contentValues = new ContentValues();
                contentValues.put(POVEZNA_KVIZ_PITANJE_IDKVIZA, stariLijeviUNoviDesni.second.getNaziv());
                contentValues.put(POVEZNA_KVIZ_PITANJE_IDPITANJA, stariLijeviUNoviDesni.second.getPitanja().get(i).getNaziv());

                SQLiteDatabase db = this.getWritableDatabase();
                db.insert(DATABASE_TABLE_POVEZNA_KVIZ_PITANJE, null, contentValues);
            }
        }

        //ako je promjenjen naziv kviza u poveznoj tabeli se moraju promijeniti sve vrijednosti u koloni sa id-em kviza

        //apdejtujPoveznuTabeluAkoJePromjenjenNazivKvizaPriEdituKviza(stariLijeviUNoviDesni.first, stariLijeviUNoviDesni.second);
        //apdejtujTabeluRanglistaAkoJePromjenjenNazivKvizaPriEdituKviza(stariLijeviUNoviDesni.first, stariLijeviUNoviDesni.second);
    }

    private void apdejtujPoveznuTabeluAkoJePromjenjenNazivKvizaPriEdituKviza(Kviz stariKviz, Kviz noviKviz)
    {
        for(int i=0; i<stariKviz.getPitanja().size(); i++)
        {
            if(postojiLiUnosUPoveznojTabeli(stariKviz, stariKviz.getPitanja().get(i)) == true)
            {
                ContentValues updateValues = new ContentValues();

                updateValues.put(POVEZNA_KVIZ_PITANJE_IDKVIZA, noviKviz.getNaziv());
                //ostaje "stariKviz.getPitanja().get(i).getNaziv()", jer se u ovoj funkciji samo mijenja jedna kolona, apitanje ostaje isto
                updateValues.put(POVEZNA_KVIZ_PITANJE_IDPITANJA, stariKviz.getPitanja().get(i).getNaziv());
                String where = POVEZNA_KVIZ_PITANJE_IDKVIZA+" = '"+stariKviz+"' AND "+
                        POVEZNA_KVIZ_PITANJE_IDPITANJA+" = '"+stariKviz.getPitanja().get(i).getNaziv()+"'";
                String whereArgs[] = null;

                SQLiteDatabase db = this.getWritableDatabase();
                db.update(DATABASE_TABLE_POVEZNA_KVIZ_PITANJE, updateValues, where, whereArgs);
            }
        }
    }

    private void apdejtujTabeluRanglistaAkoJePromjenjenNazivKvizaPriEdituKviza(Kviz stariKviz, Kviz noviKviz)
    {
       ContentValues updateValues = new ContentValues();

       updateValues.put(RANGLISTA_IDKVIZA, noviKviz.getNaziv());
       String where = RANGLISTA_IDKVIZA+" = '"+stariKviz+"'";
       String whereArgs[] = null;

       SQLiteDatabase db = this.getWritableDatabase();
       int brojPromjenjeihPolja = db.update(DATABASE_TABLE_RANGLISTE, updateValues, where, whereArgs);
    }

    public boolean postojiLiKategorijaUSQLiteBazi(String nazivKategorije)
    {
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_KATEGORIJE+
                " WHERE "+KATEGORIJA_ID+" = '"+nazivKategorije+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorIpsitivanjePostojiLiKategorijaUSQLiteBaziPoIduKategorije = db.rawQuery(query, null);

       if(kursorIpsitivanjePostojiLiKategorijaUSQLiteBaziPoIduKategorije.getCount() > 0)
        {
            //ako je kveri ista vratio znaci da postoji
            kursorIpsitivanjePostojiLiKategorijaUSQLiteBaziPoIduKategorije.close();
            return true;
        }

        kursorIpsitivanjePostojiLiKategorijaUSQLiteBaziPoIduKategorije.close();

        return false;
    }

    public boolean postojiLiKvizUSQLiteBazi(String nazivKviza)
    {
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_KVIZOVI+
                " WHERE "+KVIZ_ID+" = '"+nazivKviza+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorIspitivanjeDaLiPostojiKvizUSQLiteBaziPoIduKviza = db.rawQuery(query, null);

        if(kursorIspitivanjeDaLiPostojiKvizUSQLiteBaziPoIduKviza.getCount() > 0)
        {
            //ako je kveri ista vratio znaci da postoji
            kursorIspitivanjeDaLiPostojiKvizUSQLiteBaziPoIduKviza.close();
            return true;
        }

        kursorIspitivanjeDaLiPostojiKvizUSQLiteBaziPoIduKviza.close();

        return false;
    }

    public boolean postojiLiPitanjeUSQLiteBazi(String nazivPitanja)
    {
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_PITANJA+
                " WHERE "+PITANJE_ID+" = '"+nazivPitanja+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja = db.rawQuery(query, null);

        if(kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja.getCount() > 0)
        {
            //ako je kveri ista vratio znaci da postoji
            kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja.close();
            return true;
        }

        kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja.close();

        return false;
    }

    public boolean postojiLiRezultatURanglistiUSQLiteBazi(String nazivKviza, String username, Double ostvareniRezultat)
    {
        String query = "SELECT * "+
                        "FROM "+DATABASE_TABLE_RANGLISTE+
                        " WHERE "+RANGLISTA_IDKVIZA+"='"+nazivKviza+"' AND "+RANGLISTA_OSTAVARENIREZULTAT+" = "+ostvareniRezultat+" AND "+
                            RANGLISTA_USERNAME+" = '"+username+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja = db.rawQuery(query, null);

        if(kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja.getCount() > 0)
        {
            //ako je kveri ista vratio znaci da postoji
            kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja.close();
            return true;
        }

        kursorIspitivanjeDaLiPostojiPitanjeUSQLiteBaziPoIduPitanja.close();

        return false;
    }

    public boolean postojiLiUnosUPoveznojTabeli(Kviz kviz, Pitanje pitanje)
    {
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_POVEZNA_KVIZ_PITANJE+
                " WHERE "+POVEZNA_KVIZ_PITANJE_IDKVIZA+" = '"+kviz.getNaziv()+"' AND "+
                    POVEZNA_KVIZ_PITANJE_IDPITANJA+" = '"+pitanje.getNaziv()+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli = db.rawQuery(query, null);

        if(kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli.getCount() > 0)
        {
            //ako je kveri ista vratio znaci da postoji
            kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli.close();
            return true;
        }

        kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli.close();

        return false;
    }

    private boolean postojiLiOdgovorNaPitanjeUTabeliOdgovoriUSQLiteBazi(String odgovor, Pitanje pitanje)
    {
        String query = "SELECT * "+
                "FROM "+DATABASE_TABLE_ODGOVORI+
                " WHERE "+ODGOVORI_IDPITANJA+" = '"+pitanje.getNaziv()+"' AND "+
                ODGOVORI_TEKST+" = '"+odgovor+"';";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli = db.rawQuery(query, null);

        if(kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli.getCount() > 0)
        {
            //ako je kveri ista vratio znaci da postoji
            kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli.close();
            return true;
        }

        kursorIspitivanjeDaLiPostojiUnosUPoveznojTabeli.close();

        return false;
    }

    //azuriranje loklane baze kada se dobije pristup internetu
    public String azurirajInformacijeULokalnojBaziKadaDobijesPristupInternetu(ArrayList<Kategorija> sveKategorijeSaFirebasea, ArrayList<Kviz> sviKvizoviSaFirebasea,
                                                                            ArrayList<Pitanje> svaPitanjaSaFirebasea, ArrayList<Ranglista> sveRanglisteSaFirebasea)
    {
        //dodaj sve kategorije koje imaju u firebaseu, a ne u SQLite bazi
        int brojDodatihKategorijaUSQLiteBazu = 0;
        for(int i = 0; i<sveKategorijeSaFirebasea.size(); i++)
        {
            if(postojiLiKategorijaUSQLiteBazi(sveKategorijeSaFirebasea.get(i).getNaziv()) == false)
            {
                dodajKategorijuUTabeluKategorijeUSQLiteBazi(sveKategorijeSaFirebasea.get(i));
                brojDodatihKategorijaUSQLiteBazu++;
            }
        }

        int brojDodatihPitanjaUSQLiteBazu = 0;
        for(int i = 0; i<svaPitanjaSaFirebasea.size(); i++)
        {
            if(postojiLiPitanjeUSQLiteBazi(svaPitanjaSaFirebasea.get(i).getNaziv()) == false)
            {
                dodajPitanjeUTabeluPitanjaUSQLiteBazi(svaPitanjaSaFirebasea.get(i));
                brojDodatihPitanjaUSQLiteBazu++;
            }
        }

        int brojDodatihKvizovaUSQLiteBazu = 0;
        for(int i = 0; i<sviKvizoviSaFirebasea.size(); i++)
        {
            if(postojiLiKvizUSQLiteBazi(sviKvizoviSaFirebasea.get(i).getNaziv()) == false)
            {
                dodajKvizUTabeluKvizoviUSQLiteBazi(sviKvizoviSaFirebasea.get(i));
                brojDodatihKvizovaUSQLiteBazu++;
            }
        }

        int brojDodatihRezultataUTabeluRanglistaUSQLiteBazi = 0;
        for(int i=0; i<sveRanglisteSaFirebasea.size(); i++)
        {
            for(int j=0; j<sveRanglisteSaFirebasea.get(i).getOstavreniRezultati().size(); j++)
            {
                if(postojiLiRezultatURanglistiUSQLiteBazi(sveRanglisteSaFirebasea.get(i).getKviz().getNaziv(),
                        sveRanglisteSaFirebasea.get(i).getOstavreniRezultati().get(j).getFirst(),
                        sveRanglisteSaFirebasea.get(i).getOstavreniRezultati().get(j).getSecond()) == false)
                {
                    dodajJedanRezultatUTabeluRanglisteUSQLiteBazi(sveRanglisteSaFirebasea.get(i).getOstavreniRezultati().get(j),
                            sveRanglisteSaFirebasea.get(i).getKviz());

                    brojDodatihRezultataUTabeluRanglistaUSQLiteBazi++;
                }
            }
        }

        return "U SQLITE BAZU JE DODANO: \n-"+brojDodatihKategorijaUSQLiteBazu+" KATEGROIJA \n-"+
                    brojDodatihPitanjaUSQLiteBazu+" PITANJA \n-"+brojDodatihKvizovaUSQLiteBazu+" KVIZOVA \n-"+
                    brojDodatihRezultataUTabeluRanglistaUSQLiteBazi+" UNOSA U TABELU RANGLISTA";
    }

    // closing database
    public void closeDB()
    {
        SQLiteDatabase db = this.getReadableDatabase();

        if (db != null && db.isOpen())
            db.close();
    }

}
