package ba.unsa.etf.rma.contentResolveri;

import android.content.Context;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.util.Pair;

import java.util.ArrayList;

public class ProcitajDogadjajeIzAplikacijeZaKalendar
{
    //ATRIBUTI
    Context context;

    //KONSTRUKTOR
    public ProcitajDogadjajeIzAplikacijeZaKalendar(Context context)
    {
        this.context = context;
    }

    //pri pravljenju kverija treba specifiricarti imena kolona koja se zele dohvatiti
    public static final String[] imenaKolonaKojeSeDohvacaju = new String[]{ CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND};

    public ArrayList<Pair<String, String>> procitajPodatkeIzKalendara()
    {
        ArrayList<Pair<String, String>> rezultati = new ArrayList<>();

        Cursor cursor = null;
        try
        {
            cursor = context.getContentResolver().query(CalendarContract.Events.CONTENT_URI, imenaKolonaKojeSeDohvacaju, null, null, null);
        }
        catch(SecurityException e)
        {
            e.printStackTrace();
        }

        while(cursor != null && cursor.moveToNext())
        {
            String pocetak = cursor.getString(0);
            String kraj = cursor.getString(1);

            Pair<String, String> jedanEventIzKalendara = new Pair<>(pocetak, kraj);
            rezultati.add(jedanEventIzKalendara);
        }
        return rezultati;
    }
}
