package ba.unsa.etf.rma.BroadcastReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.Toast;

import com.google.common.util.concurrent.ServiceManager;

//ova klasa za sada ne radi nista, jer u manifestu je zakomntarisan dio za ovaj srisiver, umjesto nje se koriste risiveri koji su 4
// lokalno napravljeni u aktivnostima
public class OsluskujeImaLiInternetaBroadcastReceiver extends BroadcastReceiver
{
    @Override
    public void onReceive(Context context, Intent intent)
    {
        if(isOnline(context))
        {
            /*Bundle extras = intent.getExtras();
            Intent i = new Intent("nemaInterneta");
            // Data you need to pass to activity
            i.putExtra("nema interneta", "nema interneta");
            context.sendBroadcast(i);*/

            Toast.makeText(context, "Network Available Do operations",Toast.LENGTH_LONG).show();
        }
    }

    public boolean isOnline(Context context)
    {
        /*ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        //should check null because in airplane mode it will be null
        return (netInfo != null && netInfo.isConnected());*/
        return false;
    }
}