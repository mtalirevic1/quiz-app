package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

//implements Parcelable
public class Pitanje implements Serializable
{
    //ATRIBUTI
    private String naziv;
    private String tekstPitanja;
    private ArrayList<String> odgovori = new ArrayList<>();
    private String tacan = null;

    //KONSTRUKTOR
    public Pitanje(String naziv, String tekstPitanja, ArrayList<String> odgovori, String tacan)
    {
        this.naziv = naziv;
        this.tekstPitanja = tekstPitanja;
        this.odgovori = odgovori;
        this.tacan = tacan;
    }

    public Pitanje()
    {}

    //METODE
    public ArrayList<String> dajRandomOdgovore()
    {
        //drugaciji redoslijed pitanja svaki put daje
        ArrayList<String> isprementaniOdgovori = new ArrayList<>();

        isprementaniOdgovori.addAll(odgovori);
        Collections.shuffle(isprementaniOdgovori);

        return  isprementaniOdgovori;
    }

    //GETTERI i SETTERI
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv)
    {
        this.naziv = naziv;
        this.tekstPitanja = naziv;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

}
