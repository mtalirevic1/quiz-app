package ba.unsa.etf.rma.fragmenti;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Handler;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.SQLiteHelper.DAObazaHelper;
import ba.unsa.etf.rma.adapteri.AdapterDetaljiOKvizu;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.contentResolveri.ProcitajDogadjajeIzAplikacijeZaKalendar;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste;
import ba.unsa.etf.rma.intentSevisi.intsDobaviUMogucaPitanjaIzBaze;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.Ranglista;

//fragment u kojem se u gridu prikazuje spisak postojecih kvizova
public class DetailFrag extends Fragment {
    //ATRIBUTI
    private GridView gridKvizovi;

    ArrayList<Kviz> sviKvizovi = new ArrayList<>();
    ArrayList<Pitanje> svaPitanja = new ArrayList<>();
    ArrayList<Kategorija> sveKategorije = new ArrayList();
    int redniBrojOdabraneKategorije = sviKvizovi.size() - 1;
    ArrayList<Kviz> filtriraniKvizovi = new ArrayList<>();

    AdapterDetaljiOKvizu adapterDetaljiOKvizu;

    private boolean imaInterneta = false;

    /*private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE"))
            {
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();

                //should check null because in airplane mode it will be null
                if(netInfo == null || netInfo.isConnected() == false)
                {
                    imaInterneta = false;

                    //KAD NEMA INTERNETA ZABRANJENO DODVANJE PITANJA, KVIZOVA, KATEGORIJA
                    if(gridKvizovi != null)
                        gridKvizovi.setOnItemLongClickListener(null);
                }
                else
                {
                    imaInterneta = true;

                    if(gridKvizovi != null)
                        staviOnItemLongClickNaGrid();
                }
            }
        }
    };*/

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        gridKvizovi = (GridView) getView().findViewById(R.id.gridKvizovi);

        if (getArguments() != null && getArguments().containsKey("sviKvizovi") && getArguments().containsKey("sveKategorije")
                && getArguments().containsKey("svaPitanja") && getArguments().containsKey("selektovana kategorija")) {
            sviKvizovi = (ArrayList<Kviz>) getArguments().getSerializable("sviKvizovi");
            sveKategorije = (ArrayList<Kategorija>) getArguments().getSerializable("sveKategorije");
            svaPitanja = (ArrayList<Pitanje>) getArguments().getSerializable("svaPitanja");

            Kategorija odabranaKategorija = (Kategorija) getArguments().getSerializable("selektovana kategorija");

            filtriraniKvizovi.clear();

            if (odabranaKategorija.getNaziv().equals("Svi") == true)
                filtriraniKvizovi.addAll(sviKvizovi);
            else {
                for (int i = 0; i < sviKvizovi.size(); i++)
                {
                    if (sviKvizovi.get(i).getKategorija().getNaziv().equals(odabranaKategorija.getNaziv()))
                        filtriraniKvizovi.add(sviKvizovi.get(i));
                }
            }

            Kviz dodajKviz = new Kviz();
            dodajKviz.setNaziv("Dodaj kviz");
            dodajKviz.setKategorija(new Kategorija("", "671"));
            filtriraniKvizovi.add(dodajKviz);

            adapterDetaljiOKvizu = new AdapterDetaljiOKvizu(getActivity(), R.layout.adapter_detali_frag, filtriraniKvizovi);
            gridKvizovi.setAdapter(adapterDetaljiOKvizu);

            postaviAtributKojiGovoriImaLiInterneta();

            staviOnItemLongClickNaGrid();
            staviOnItemClickNaGrid();

            adapterDetaljiOKvizu.notifyDataSetChanged();
            /*IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
            getActivity().registerReceiver(broadcastReceiver, intentFilter1);*/
        }
    }

    @Override
    public void onStart()
    {
        super.onStart();

        /*IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        getActivity().registerReceiver(broadcastReceiver, intentFilter1);*/

        postaviAtributKojiGovoriImaLiInterneta();
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
        //getActivity().unregisterReceiver(broadcastReceiver);
    }

    private void staviOnItemClickNaGrid()
    {
        gridKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if(filtriraniKvizovi.get(position).getNaziv().equals("Dodaj kviz") == false)
                {

                    String pattern = "yyyy-MM-dd";
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
                    Date sad = new Date();
                    ArrayList<Pair<String, String>> dogadjajiIzKalendara = new ProcitajDogadjajeIzAplikacijeZaKalendar(getActivity()).
                            procitajPodatkeIzKalendara();

                    for (int i=0; i<dogadjajiIzKalendara.size(); i++)
                    {
                        long pocetakDogadjaja = Long.parseLong(dogadjajiIzKalendara.get(i).first);
                        long krajDogadjaja = Long.parseLong(dogadjajiIzKalendara.get(i).second);
                        Date datumIVrijemeDogadjajaIZKalendara = new Date(pocetakDogadjaja);

                        //provjer ima li dogadjaj na isti datum
                        if(simpleDateFormat.format(sad).equals(simpleDateFormat.format(datumIVrijemeDogadjajaIZKalendara)))
                        {
                            int trajanjeKviza = (int)Math.ceil(sviKvizovi.get(position).getPitanja().size()/2.0);

                            long trenutnoVrijemeUMiliskenudnama = sad.getTime();
                            long vrijemeDogadjajaUMilisekundama = datumIVrijemeDogadjajaIZKalendara.getTime();
                            long trajanjeKvizaUMilisekundama = TimeUnit.MINUTES.toMillis(trajanjeKviza);
                            int minuteDoEventa = (int) (TimeUnit.MILLISECONDS.toMinutes(vrijemeDogadjajaUMilisekundama - trenutnoVrijemeUMiliskenudnama) + 1);

                            if(pocetakDogadjaja < trenutnoVrijemeUMiliskenudnama && trenutnoVrijemeUMiliskenudnama < krajDogadjaja)
                            {
                                android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(getActivity()).create();
                                alertDialog.setTitle("NE MOZETE IGRATI KVIZ");
                                alertDialog.setMessage("Imate događaj koji je u kalendaru aktivan!");
                                alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                alertDialog.show();

                                return;
                            }
                            else if(trenutnoVrijemeUMiliskenudnama + trajanjeKvizaUMilisekundama > vrijemeDogadjajaUMilisekundama && trenutnoVrijemeUMiliskenudnama < vrijemeDogadjajaUMilisekundama)
                            {
                                android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(getActivity()).create();
                                alertDialog.setTitle("NE MOZETE IGRATI KVIZ");
                                alertDialog.setMessage("Imate događaj koji pocinje za "+minuteDoEventa+"minuta!");
                                alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                                        new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                            }
                                        });
                                alertDialog.show();

                                return;
                            }

                        }
                    }

                    Intent mojIntent = new Intent(getActivity(), IgrajKvizAkt.class);
                    mojIntent.putExtra("odabraniKvizZaIgrati", filtriraniKvizovi.get(position));

                    startActivity(mojIntent);
                }
            }
        });

    }

    private void staviOnItemLongClickNaGrid()
    {
        gridKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int position, long id)
            {
                postaviAtributKojiGovoriImaLiInterneta();
                if(imaInterneta == false)
                    return false;

                Intent mojIntent = new Intent(getActivity(), DodajKvizAkt.class);

                // u onClickListener-u na ListView parametar id=-1 za header i footer_dodaj_kviz bude -1, a position=0 za header, a
                // za footer_dodaj_kviz postition = vel_liste ili position = vel_liste+1 ako u ima iznad liste vec header
                mojIntent.putExtra("kljucArraySveKategorije", sveKategorije);
                mojIntent.putExtra("kljucArraySviKvizovi", sviKvizovi);
                mojIntent.putExtra("kljucSvaPitanja", svaPitanja);

                //ako se ne posalje "odabraniKviz" kao kljuc, u sljedecem prozoru ce se pri provjeri tog kljuca
                //sa metodom "getParcelExtra" vratiti se "null" vrijednost
                if(filtriraniKvizovi.get(position).getNaziv().equals("Dodaj kviz") == false)
                {
                    //This is how you will pass a Serializable object
                    // using putExtra(String key, Serializable value) method
                    mojIntent.putExtra("odabraniKviz", filtriraniKvizovi.get(position));
                    mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", position);
                    mojIntent.putExtra("nacinRada", "editovanjeKviza");
                }
                else
                {
                    mojIntent.putExtra("nacinRada", "dodavanjeKviza");
                }

                startActivity(mojIntent);

                return true;
            }
        });
    }

    private void postaviAtributKojiGovoriImaLiInterneta()
    {
        ConnectivityManager cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        //should check null because in airplane mode it will be null
        if(netInfo == null || netInfo.isConnected() == false)
        {
            //Toast.makeText(getActivity(), "NEMA INTERNETA  FRAGMENTU DetailFrag",Toast.LENGTH_LONG).show();
            imaInterneta = false;
            gridKvizovi.setOnItemLongClickListener(null);
        }
        else
        {
            //Toast.makeText(getActivity(), "IMA INTERNETA  FRAGMENTU DetailFrag",Toast.LENGTH_LONG).show();
            imaInterneta = true;
        }

    }
}
