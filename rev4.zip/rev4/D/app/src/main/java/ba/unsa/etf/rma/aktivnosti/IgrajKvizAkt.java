package ba.unsa.etf.rma.aktivnosti;

import android.app.FragmentManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.provider.AlarmClock;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.SQLiteHelper.DAObazaHelper;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RanglistaFrag;
import ba.unsa.etf.rma.intentSevisi.intsDobaviUMogucaPitanjaIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsDodajOstvareniRezultatURangListuIPrikaziJeZaTajKviz;
import ba.unsa.etf.rma.intentSevisi.intsDodajSveOstvareneRezultateIzSQLiteBazeKojiNemajuNaFirebaseu;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Par;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.Ranglista;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.KadKlikneNaOdgovor, resultReceiverZaSveIntentServise.Receiver
{
    private Kviz kvizKojiSeIgra;
    private ArrayList<Pitanje> izmjesanaPitanja = new ArrayList<>();
    private ArrayList<Pitanje> postavljenaPitanja = new ArrayList<>();
    private FrameLayout informacijePlace;
    private FrameLayout pitanjaPlace;

    private int brojTacnoOdogovrenih = 0;

    private boolean kreiranaAkativnostiIliOnRestart = true;
    private DAObazaHelper daoBazaHelper;
    private boolean imaInterneta = false;
    Context kontekst;

    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE"))
            {
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();

                if(kreiranaAkativnostiIliOnRestart == true)
                {
                    kreiranaAkativnostiIliOnRestart = false;
                    return;
                }

                //should check null because in airplane mode it will be null
                if(netInfo == null || netInfo.isConnected() == false)
                {
                    Log.w("BROADCAST:", "NEMA INTERNETA");
                    Toast.makeText(context, "NEMA INTERNETA IgrajKvizAkt",Toast.LENGTH_LONG).show();

                    imaInterneta = false;
                }
                else
                {
                    Toast.makeText(context, "IMA INTERNETA IgrajKvizAkt",Toast.LENGTH_LONG).show();

                    imaInterneta = true;

                    daoBazaHelper = new DAObazaHelper(getApplicationContext());
                    ArrayList<Ranglista> sveRanglisteIzSQLiteBaze = daoBazaHelper.dajSveOstvareneRezultateIzTabeleRangListe();
                    daoBazaHelper.closeDB();

                    dodajSveStoImaUSQLiteuANemaUFirebaseuNaFirebase(sveRanglisteIzSQLiteBaze);
                }
            }
        }
    };

    private void dodajSveStoImaUSQLiteuANemaUFirebaseuNaFirebase(ArrayList<Ranglista> sveRanglisteIzSQLiteBaze)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDodajSveOstvareneRezultateIzSQLiteBazeKojiNemajuNaFirebaseu.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("sve rangliste iz sqlitea", sveRanglisteIzSQLiteBaze);
        startService(mojIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        postaviAtributKojiGovoriImaLiInterneta();

        kontekst = this;
        if(getIntent().getSerializableExtra("odabraniKvizZaIgrati") != null )
            kvizKojiSeIgra = (Kviz) getIntent().getSerializableExtra("odabraniKvizZaIgrati");

        FragmentManager fragmentManager = getFragmentManager();

        informacijePlace = (FrameLayout) findViewById(R.id.informacijePlace);
        pitanjaPlace = (FrameLayout) findViewById(R.id.pitanjaPlace);

        //POSTAVLJANJE PRVOG FRAGMENTA U FREJM
        InformacijeFrag informacijeFrag;
        informacijeFrag = (InformacijeFrag) fragmentManager.findFragmentById(R.id.informacijePlace);

        if(informacijeFrag == null)
        {
            informacijeFrag = new InformacijeFrag();

            Bundle bundle = new Bundle();
            bundle.putString("brojPostavljenjih", "0");
            bundle.putString("brojTacnoOdgovorenih", "0");
            bundle.putSerializable("odabraniKvizKojiSeIgra", kvizKojiSeIgra);
            informacijeFrag.setArguments(bundle);

            fragmentManager.beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
        }

        //POSTAVLJANJE DRUGOG FRAGMENTA U FREJM
        PitanjeFrag pitanjeFrag;
        pitanjeFrag = (PitanjeFrag) fragmentManager.findFragmentById(R.id.pitanjaPlace);

        if(pitanjeFrag == null)
        {
            pitanjeFrag = new PitanjeFrag();

            Bundle bundle = new Bundle();
            izmjesanaPitanja.clear();
            izmjesanaPitanja.addAll(kvizKojiSeIgra.dajRandomRedoslijedPitanja());

            if(izmjesanaPitanja.size() > 0)
            {
                bundle.putSerializable("pitanjeIzOdabranogKviza", izmjesanaPitanja.get(0));
                postavljenaPitanja.add(izmjesanaPitanja.get(0));
            }
            else
                bundle.putString("nemaOdgovora", "0");
            pitanjeFrag.setArguments(bundle);

            fragmentManager.beginTransaction().replace(R.id.pitanjaPlace, pitanjeFrag).commit();
        }

        postaviAlarmZaIgranjeKviza();

        fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }

    private void postaviAlarmZaIgranjeKviza()
    {
        //podrazumijevajuci konstruktor vraca tacan datum koji odgovara trenutku kada je alociran objekat
        Date date = new Date();

        int sati = date.getHours();
        int minute = date.getMinutes();

        Log.d("SATI", String.valueOf(sati));
        Log.d("MINUTE", String.valueOf(minute));

        //"2.0", jer bi se ince imali dva operanda trip int, pa bi doslo dao zaokruzivanja
        int n = (int)Math.ceil(kvizKojiSeIgra.getPitanja().size() / 2.0);

        if(minute + n >= 60)
        {
            sati+=1;
            minute = minute + n - 60;
        }
        else minute += n;

        if(n!=0)
        {
            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
            //postavlja se vrijeme kada alarm pocinje zvoniti
            alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, sati);
            alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            alarmIntent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            IgrajKvizAkt.this.startActivity(alarmIntent);
        }
    }

    private void postaviAtributKojiGovoriImaLiInterneta()
    {
        ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        //should check null because in airplane mode it will be null
        if(netInfo == null || netInfo.isConnected() == false)
            imaInterneta = false;
        else
            imaInterneta = true;
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();

        postaviAtributKojiGovoriImaLiInterneta();
        kreiranaAkativnostiIliOnRestart = true;

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }

    //interfejs iz fagmenta koji se poziva kada se nesto desi u fragmentu sa listom, ap bi prenio informacije
    // o tom dogadjau u drugi fragment
    @Override
    public void klikNaOdgovor(String tacan)
    {
        //AZURIRANJE PITANJE FRAGMENTA
        Bundle bundle2 = new Bundle();
        boolean azurirajZadnjiPut = false;

        if(izmjesanaPitanja.size() != postavljenaPitanja.size())
        {
            bundle2.putSerializable("pitanjeIzOdabranogKviza", izmjesanaPitanja.get(postavljenaPitanja.size()));
            postavljenaPitanja.add(izmjesanaPitanja.get(postavljenaPitanja.size()));
        }
        else
        {
            bundle2.putString("nemaOdgovora", "0");
            azurirajZadnjiPut = true;
        }

        PitanjeFrag pitanjeFrag = new PitanjeFrag();
        pitanjeFrag.setArguments(bundle2);

        getFragmentManager().beginTransaction().replace(R.id.pitanjaPlace, pitanjeFrag).commit();

        //AZURIRANJE INFORMACIJA FRAGMENTA
        if(tacan.equals(izmjesanaPitanja.get(postavljenaPitanja.size()-1).getTacan()))
            brojTacnoOdogovrenih++;

        Bundle bundle = new Bundle();

        // "-1", JER JE GORE IZNAD U ATRIBUT psotavljenaPitanja DODATO NOVO PITANJE KOJE NE TREBA DA SE RACUNA
        if(azurirajZadnjiPut == true)
        {
            bundle.putString("brojPostavljenjih", String.valueOf(postavljenaPitanja.size()));
            bundle.putInt("zadnjePitanje", 1);

            prikaziAlertDialogIDajRanglistu(brojTacnoOdogovrenih, postavljenaPitanja.size());
        }
        else
        bundle.putString("brojPostavljenjih", String.valueOf(postavljenaPitanja.size()-1));

        bundle.putString("brojTacnoOdgovorenih", String.valueOf(brojTacnoOdogovrenih));
        bundle.putSerializable("odabraniKvizKojiSeIgra", kvizKojiSeIgra);

        InformacijeFrag informacijeFrag = new InformacijeFrag();
        informacijeFrag.setArguments(bundle);

        getFragmentManager().beginTransaction().replace(R.id.informacijePlace, informacijeFrag).commit();
    }

    private void prikaziAlertDialogIDajRanglistu(int brojTacnoOdogovrenih, int brojPostavljenihPitanja)
    {
        double pomocniProcenat = 0;
        if(brojPostavljenihPitanja > 0)
            pomocniProcenat = Double.valueOf(brojTacnoOdogovrenih) / brojPostavljenihPitanja;

        final double procenat = pomocniProcenat;

        final AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setTitle("UNESITE IME")
                .setMessage("Unesite ime kakao bi vas spasili u rang listu igara ovog kviza")
                .setPositiveButton(android.R.string.ok, null)
                .create();

        final EditText input = new EditText(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        alertDialog.setView(input);

        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(DialogInterface dialogInterface)
            {
                Button button = ((AlertDialog) alertDialog).getButton(AlertDialog.BUTTON_POSITIVE);

                button.setOnClickListener(new View.OnClickListener()
                {

                    @Override
                    public void onClick(View view)
                    {
                        if(input.getText().toString().trim().equals(""))
                        {
                            Log.w("NISI UPISAO IME", "Upisi ime, ne mozes ostaviti prazno!");
                        }
                        else
                        {
                            String unesenoImeZaRangListu = input.getText().toString();

                            if(imaInterneta == true)
                                dodajRezultatURangLitseIDajRangListuZaOvajKviz(kvizKojiSeIgra, procenat, unesenoImeZaRangListu);
                            else
                            {
                                daoBazaHelper = new DAObazaHelper(getApplicationContext());

                                Par jedanRezultat = new Par(unesenoImeZaRangListu, procenat);
                                daoBazaHelper.dodajJedanRezultatUTabeluRanglisteUSQLiteBazi(jedanRezultat, kvizKojiSeIgra);
                                azurirajInformacijeUFragmentuRanlistiNaOsnovuPodatakaIzSQliteBaze(daoBazaHelper);
                                daoBazaHelper.closeDB();
                            }

                            alertDialog.dismiss();
                        }
                    }
                });
            }
        });
        alertDialog.show();
    }

    private void azurirajInformacijeUFragmentuRanlistiNaOsnovuPodatakaIzSQliteBaze(DAObazaHelper daoBazaHelper)
    {
        FragmentManager fragmentManager = getFragmentManager();

        RanglistaFrag ranglistaFrag =  new RanglistaFrag();

        ArrayList<Par> trazenaRanglista = daoBazaHelper.pretraziTabeluRanglistaPoIduKviza(kvizKojiSeIgra.getNaziv());

        Bundle bundle = new Bundle();
        bundle.putSerializable("ranglista", trazenaRanglista);
        ranglistaFrag.setArguments(bundle);
        fragmentManager.beginTransaction().replace(R.id.pitanjaPlace, ranglistaFrag).commit();
        fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }

    private void dodajRezultatURangLitseIDajRangListuZaOvajKviz(Kviz kvizKojiSeIgra, double procenat, String usernameZaRangListu)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDodajOstvareniRezultatURangListuIPrikaziJeZaTajKviz.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("kviz koji se igra", kvizKojiSeIgra);
        mojIntent.putExtra("procenat tacno odgovorenih", procenat);
        mojIntent.putExtra("username za rang listu", usernameZaRangListu);
        startService(mojIntent);
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        switch (resultCode)
        {
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                if(resultData.getSerializable("zadatak") != null &&
                        resultData.getSerializable("zadatak").equals("dobavljena rang lista za kviz"))
                {
                    ArrayList<Par> ranglista = (ArrayList<Par>) resultData.getSerializable("rezultat");

                    FragmentManager fragmentManager = getFragmentManager();

                    RanglistaFrag ranglistaFrag =  new RanglistaFrag();

                    Bundle bundle = new Bundle();
                    bundle.putSerializable("ranglista", ranglista);
                    ranglistaFrag.setArguments(bundle);
                    fragmentManager.beginTransaction().replace(R.id.pitanjaPlace, ranglistaFrag).commit();
                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }
                else if(resultData.getSerializable("zadatak") != null &&
                        resultData.getSerializable("zadatak").equals("azuriranje stanja na firebaseu kad dodje internet"))
                {
                    ArrayList<Par> azuriranaRanglista = (ArrayList<Par>) resultData.getSerializable("rezultat");

                    FragmentManager fragmentManager = getFragmentManager();

                    RanglistaFrag ranglistaFrag =  new RanglistaFrag();

                    Bundle bundle = new Bundle();
                    bundle.putSerializable("ranglista", azuriranaRanglista);
                    ranglistaFrag.setArguments(bundle);
                    fragmentManager.beginTransaction().replace(R.id.pitanjaPlace, ranglistaFrag).commit();
                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }
                else if(resultData.getSerializable("zadatak") != null &&
                        resultData.getSerializable("zadatak").equals("updjetovane ranglite na firebaseu na osnovu podataka iz sqlitea"))
                {
                    int brojUcitanihRezultataUKolekcijuRanglisteNaFirebase = resultData.getInt("brojUcitanihRezultataNaFirebase");

                    if(brojUcitanihRezultataUKolekcijuRanglisteNaFirebase > 1)
                    Toast.makeText(kontekst, "u firebase dodano "+brojUcitanihRezultataUKolekcijuRanglisteNaFirebase+" rezultata"
                            ,Toast.LENGTH_LONG).show();
                    else if(brojUcitanihRezultataUKolekcijuRanglisteNaFirebase ==1)
                        Toast.makeText(kontekst, "u firebase dodano "+brojUcitanihRezultataUKolekcijuRanglisteNaFirebase+" rezultat"
                                ,Toast.LENGTH_LONG).show();
                }

                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(this).create();
                alertDialog.setTitle("PROBLEM PRI UNOSENJU U RANG LISTU");
                alertDialog.setMessage("nije se rezultat ispravno unio u rang listu!");
                alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
                break;
        }
    }
}
