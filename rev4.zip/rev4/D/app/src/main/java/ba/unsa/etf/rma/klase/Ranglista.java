package ba.unsa.etf.rma.klase;



import java.io.Serializable;
import java.util.ArrayList;

public class Ranglista implements Serializable
{
    //ATRIBUTI
    private ArrayList<Par> ostavreniRezultati = new ArrayList<>();
    private Kviz kviz;

    //KONSTRUKTOR
    public Ranglista(Kviz kviz)
    {
        this.kviz = kviz;
    }

    public Ranglista(){};

    //GETTERI I SETTERI
    public ArrayList<Par> getOstavreniRezultati() {
        return ostavreniRezultati;
    }

    public void setOstavreniRezultati(ArrayList<Par> ostavreniRezultati) {
        this.ostavreniRezultati = ostavreniRezultati;
    }

    public Kviz getKviz() {
        return kviz;
    }

    public void setKviz(Kviz kviz) {
        this.kviz = kviz;
    }
}
