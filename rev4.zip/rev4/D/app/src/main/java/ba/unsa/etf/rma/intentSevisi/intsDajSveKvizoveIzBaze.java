package ba.unsa.etf.rma.intentSevisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class intsDajSveKvizoveIzBaze extends IntentService
{
    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public intsDajSveKvizoveIzBaze()
    {
        super(null);
    }

    public intsDajSveKvizoveIzBaze(String name)
    {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        // Kod koji se nalazi ovdje će se izvršavati u posebnoj niti
        // Ovdje treba da se nalazi funkcionalnost servisa koja je
        // vremenski zahtjevna
        final ResultReceiver resultReceiver = intent.getParcelableExtra("risiver");

        ArrayList<Kviz> alSviKvizovi = new ArrayList<>();
        boolean uspjesnoProcitaniSviKvizovi = false;

        String token = null;
        token = dajToken();

        if(token.equalsIgnoreCase("nema tokena"))
            return;

        boolean nemaKvizovaUBazi = false;
        try
        {
            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kvizovi";

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer " + token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);

            JSONObject jsonObject = new JSONObject(rezultat);
            JSONArray documents;

            try
            {
                documents = jsonObject.getJSONArray("documents");
            }
            catch(Exception e)
            {
                nemaKvizovaUBazi = true;
            }

            documents = jsonObject.getJSONArray("documents");

            //DA OVO NE BI BACILO IZUZETAK, MORAJU PRAVILNO BITI UPISANI KVIZOVI
            for(int i=0; i<documents.length(); i++)
            {
                Kviz novoprocitaniKviz = new Kviz();

                JSONObject jedanDokument = documents.getJSONObject(i);

                JSONObject jsonFields = jedanDokument.getJSONObject("fields");

                JSONObject jsonNaziv = jsonFields.getJSONObject("naziv");
                novoprocitaniKviz.setNaziv(jsonNaziv.getString("stringValue"));

                JSONObject jsonIdKategorije = jsonFields.getJSONObject("idKategorije");
                String stringIdKategorije = jsonIdKategorije.getString("stringValue");

                Kategorija kategorijaKojojPripadaKviz = new Kategorija();
                if(stringIdKategorije.equals("KATEGORIJASvi") == true)
                {
                    kategorijaKojojPripadaKviz.setNaziv("Svi");
                    kategorijaKojojPripadaKviz.setId("0");
                }
                else
                {
                   kategorijaKojojPripadaKviz = dajKategorijuKviza(stringIdKategorije, token);
                }


                if(kategorijaKojojPripadaKviz == null)
                    throw new JSONException("NIJE DOBRO UCITANA KATEGORIJA!!!!!!");
                else
                    novoprocitaniKviz.setKategorija(kategorijaKojojPripadaKviz);

                JSONObject jsonPitanja = jsonFields.getJSONObject("pitanja");
                JSONObject arrayValue = jsonPitanja.getJSONObject("arrayValue");

                try
                {
                    JSONArray values = arrayValue.getJSONArray("values");

                    for(int j = 0; j< values.length(); j++)
                    {
                        JSONObject jsonIdJendogPitanja = values.getJSONObject(j);
                        String stringIdJendogPitanja = jsonIdJendogPitanja.getString("stringValue");

                        Pitanje pitanjeIzKviza = dajPitanjeKviza(stringIdJendogPitanja, token);

                        if(pitanjeIzKviza == null)
                            throw new JSONException("NIJE DOBRO UCITANO PITANJE U "+String.valueOf(j)+"PROLAZU KROZ PETLJU ZA UNOS PITANJA!!!!!!");
                        else
                            novoprocitaniKviz.getPitanja().add(pitanjeIzKviza);
                    }
                }
                catch (JSONException e)
                {
                    Log.d("NEMA U KVIZU PITANJA", "nema u kvizu \""+novoprocitaniKviz.getNaziv()+"\" pitanja");
                }

                alSviKvizovi.add(novoprocitaniKviz);
            }

            uspjesnoProcitaniSviKvizovi = true;
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        catch (ProtocolException e)
        {
            e.printStackTrace();
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            uspjesnoProcitaniSviKvizovi = false;
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        //vracanje elemenata kroz risiver, ili vracanje informacije da je pri citanju iz baze doslo do greske
        Bundle bundle = new Bundle();
        if(uspjesnoProcitaniSviKvizovi == true)
        {
            bundle.putSerializable("alSviKvizovi", alSviKvizovi);

            bundle.putSerializable("zadatak", "dobavljeni svi kvizovi iz baze");
            resultReceiver.send(STATUS_FINISHED, bundle);
        }
        else if(nemaKvizovaUBazi == true)
        {
            bundle.putString("zadatak", "nema kvizova u bazi");
            resultReceiver.send(STATUS_ERROR, bundle);
        }
        else
        {
            bundle.putString(Intent.EXTRA_TEXT, "DOŠLO JE DO GREŠKE PRI ČITANJU IZ BAZE (u klasi \"intsDajSveKvizoveIzBaze\"");
            resultReceiver.send(STATUS_ERROR, bundle);
        }
    }

    private Pitanje dajPitanjeKviza(String stringIdTrazenogPitanja, String token)
    {
        Pitanje procitanoOdgovoarajucePitanje = null;

        try
        {
            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Pitanja";

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer " + token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);

            JSONObject jsonObject = new JSONObject(rezultat);
            JSONArray documents = jsonObject.getJSONArray("documents");

            //DA OVO NE BI BACILO IZUZETAK, MORAJU PRAVILNO BITI UPISANI KVIZOVI
            for(int i=0; i<documents.length(); i++)
            {
                JSONObject jedanDokument = documents.getJSONObject(i);

                JSONObject fields = jedanDokument.getJSONObject("fields");

                JSONObject naziv = fields.getJSONObject("naziv");
                String stringNazivPitanja = "PITANJE"+naziv.getString("stringValue");

                if(stringNazivPitanja.equals(stringIdTrazenogPitanja))
                {
                    procitanoOdgovoarajucePitanje = new Pitanje();

                    // 'naziv.getString("stringValue")', a ne 'stringNazivPitanja', er on sadrzi i "PITANJE" dio u sebi
                    procitanoOdgovoarajucePitanje.setNaziv( naziv.getString("stringValue") );
                    procitanoOdgovoarajucePitanje.setTekstPitanja(procitanoOdgovoarajucePitanje.getNaziv()); // jer je zadato postavkom (forum) da su tekst pitanja i naziv isto

                    ArrayList<String> alOdgovoriNaTrazenoPitanje = new ArrayList<>();
                    JSONObject odgovori = fields.getJSONObject("odgovori");
                    JSONObject arrayValue = odgovori.getJSONObject("arrayValue");
                    JSONArray values = arrayValue.getJSONArray("values");

                    for(int j = 0; j < values.length(); j++)
                    {
                        JSONObject jedanOdogovor = values.getJSONObject(j);
                        alOdgovoriNaTrazenoPitanje.add(jedanOdogovor.getString("stringValue"));
                    }
                    procitanoOdgovoarajucePitanje.setOdgovori(alOdgovoriNaTrazenoPitanje);

                    JSONObject jsonIndexTacnog = fields.getJSONObject("indexTacnog");
                    int intIndexTacnog = jsonIndexTacnog.getInt("integerValue");

                    procitanoOdgovoarajucePitanje.setTacan(procitanoOdgovoarajucePitanje.getOdgovori().get(intIndexTacnog));
                    break;
                }
            }
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        catch (ProtocolException e)
        {
            e.printStackTrace();
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return procitanoOdgovoarajucePitanje;
    }

    private Kategorija dajKategorijuKviza(String stringIdTrazeneKategorije, String token)
    {
        Kategorija procitanaOdgovoarajucaKategorija = null;

        try
        {
            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kategorije";

            URL urlObjekat = new URL(url);

            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            konekcija.setRequestProperty("Authorization", "Bearer " + token);

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);

            JSONObject jsonObject = new JSONObject(rezultat);
            JSONArray documents = jsonObject.getJSONArray("documents");

            //DA OVO NE BI BACILO IZUZETAK, MORAJU PRAVILNO BITI UPISANI KVIZOVI
            for(int i=0; i<documents.length(); i++)
            {
                JSONObject jedanDokument = documents.getJSONObject(i);

                JSONObject fields = jedanDokument.getJSONObject("fields");

                JSONObject jsonNaziv = fields.getJSONObject("naziv");
                String stringNazivKategorije = "KATEGORIJA"+jsonNaziv.getString("stringValue");

                if(stringNazivKategorije.equals(stringIdTrazeneKategorije))
                {
                    procitanaOdgovoarajucaKategorija = new Kategorija();

                    // ide 'jsonNaziv.getString("stringValue")', a ne 'stringNazivKategorije', jer on sadrzi i "KATEGORIJA" dio u sebi
                    procitanaOdgovoarajucaKategorija.setNaziv(jsonNaziv.getString("stringValue"));

                    JSONObject jsonIdIkonice = fields.getJSONObject("idIkonice");
                    //atribut id u klasi kategorija je id izabrane ikonice
                    procitanaOdgovoarajucaKategorija.setId(String.valueOf(jsonIdIkonice.getInt("integerValue")));

                    break;
                }
            }
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        catch (ProtocolException e)
        {
            e.printStackTrace();
        }
        catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }

        return procitanaOdgovoarajucaKategorija;
    }

    public String dajToken()
    {
        String token = null;

        try
        {
            InputStream is = getBaseContext().getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = null;
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            token = credentials.getAccessToken();

            is.close();
            //Log.d("TOKEN", token);
        }
        catch (IOException e)
        {
            e.printStackTrace();
            Log.w("NEMA TOKENA", "nema tokena kada se dobavljaju svi kvizovi (kada se selektuje kategorija svi)");
            token = "nema tokena";
        }

        return token;
    }

    public String convertStreamToString(InputStream is)
    {
        //BufferedReader je klasa wrapper za oboje "InputStreamReader/FileReader". Koristeci bufffer(spremink), efikasnije odradjuje citanje bajta(tj. charova, jer je jedan char jena bajt)
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        //String is immutable, if you try to alter their values, another object gets created, whereas StringBuffer and StringBuilder are mutable so they can change their values.
        // Thread-Safety Difference: The difference between StringBuffer and StringBuilder is that StringBuffer is thread-safe.
        StringBuilder sb = new StringBuilder();
        String line = null;
        try
        {
            while ((line = reader.readLine()) != null)
                sb.append(line + "\n");
        }
        catch (IOException e)
        {
            e.getStackTrace();
        }
        finally
        {
            try
            {
                is.close();
            }
            catch (IOException e)
            {
                e.getStackTrace();
            }
        }

        return sb.toString();
    }
}


