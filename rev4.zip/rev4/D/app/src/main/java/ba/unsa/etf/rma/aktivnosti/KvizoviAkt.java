package ba.unsa.etf.rma.aktivnosti;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.app.FragmentManager;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.SQLiteHelper.DAObazaHelper;
import ba.unsa.etf.rma.contentResolveri.ProcitajDogadjajeIzAplikacijeZaKalendar;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.adapteri.AdapterSpinerKategorijaNaziv;
import ba.unsa.etf.rma.intentSevisi.intsDajKvizoveIzOdabraneKategorije;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKvizoveIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsDodajSveOstvareneRezultateIzSQLiteBazeKojiNemajuNaFirebaseu;
import ba.unsa.etf.rma.intentSevisi.intsNapuniBazuPocetnimVrijednostima;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.adapteri.AdapterListaKvizova;
import ba.unsa.etf.rma.klase.Ranglista;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.KadKlikneNaKategoriju, resultReceiverZaSveIntentServise.Receiver
{
    //ATRIBUTI
    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;

    private AdapterListaKvizova adapterKvizovi;
    private ArrayList<Kviz> alSviKvizovi = new ArrayList<>();
    private ArrayList<Kviz> alFiltriraniKvizovi = new ArrayList<>();
    private View footerView;

    private AdapterSpinerKategorijaNaziv adapterSpinerKategorijaNaziv;
    private ArrayList<Kategorija> alSveKategorije = new ArrayList<>();
    private final Kategorija kategorijaSviFiktivnaKategorija = new Kategorija("Svi", "0");
    private boolean prviPutSeDobavljaSveIzBaze;

    private ArrayList<Pitanje> alSvaPitanja = new ArrayList<>();

    boolean sirina550 = false;

    private boolean kreiranaAkativnostiIliOnRestart = true;
    private boolean imaInterneta;
    private DAObazaHelper daoBazaHelper;

    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver()
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if(intent.getAction().equalsIgnoreCase("android.net.conn.CONNECTIVITY_CHANGE"))
            {
                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netInfo = cm.getActiveNetworkInfo();

                if(kreiranaAkativnostiIliOnRestart == true)
                {
                    kreiranaAkativnostiIliOnRestart = false;
                    return;
                }

                //should check null because in airplane mode it will be null
                if(netInfo == null || netInfo.isConnected() == false)
                {
                    Log.w("BROADCAST:", "NEMA INTERNETA");
                    Toast.makeText(context, "NEMA INTERNETA KvizoviAkt",Toast.LENGTH_LONG).show();

                    imaInterneta = false;

                    //KAD NEMA INTERNETA ZABRANJENO DODVANJE I EDITOVANJE KVIZOVA
                    if(footerView != null)
                        footerView.setOnLongClickListener(null);

                    if(lvKvizovi != null)
                        lvKvizovi.setOnItemLongClickListener(null);

                    //mora se i listener na spiner promijentii ako nema interneta, jer kada ima moraju se sa firebase
                    // ucitati kvizovi koji odgovoraju slektovanoj kategoriji u spienru
                    if(spPostojeceKategorije != null)
                        staviItemSelectedListenerNaSpinerKategorijaAkoNemaInterneta();

                    napuniAtributeNaOsnovuStanjaUSQLiteBazi();
                }
                else
                {
                    Toast.makeText(context, "IMA INTERNETA KvizoviAkt",Toast.LENGTH_LONG).show();

                    imaInterneta = true;

                    if(footerView != null)
                        staviOnLongClickListenerNaFooterListViewa();

                    if(lvKvizovi != null)
                        staviOnItemLongClickListenerNaListuKvizova();

                    if(spPostojeceKategorije != null)
                        staviItemSelectedListenerNaSpinerKategorijaAkoImaInterneta();

                    daoBazaHelper = new DAObazaHelper(getApplicationContext());
                    ArrayList<Ranglista> sveRanglisteIzSQLiteBaze = daoBazaHelper.dajSveOstvareneRezultateIzTabeleRangListe();
                    daoBazaHelper.closeDB();

                    dodajSveRanglisteStoImajuUSQLiteuANemaIhUFirebaseuNaFirebase(sveRanglisteIzSQLiteBaze);
                    //napuniAtributeNaOsnovuStanjaUFirebaseBaziDaBiApdejtovaoLoklanuSQLiteBazu();
                }
            }
        }
    };

    private void dodajSveRanglisteStoImajuUSQLiteuANemaIhUFirebaseuNaFirebase(ArrayList<Ranglista> sveRanglisteIzSQLiteBaze)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDodajSveOstvareneRezultateIzSQLiteBazeKojiNemajuNaFirebaseu.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("sve rangliste iz sqlitea", sveRanglisteIzSQLiteBaze);
        startService(mojIntent);
    }

    private void napuniAtributeNaOsnovuStanjaUFirebaseBaziDaBiApdejtovaoLoklanuSQLiteBazu()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("apdejtovanje loklane SQLite baze", "apdjetuj");

        startService(mojIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //napuni();
        //isprazniLoklanuSQLiteBazuNaPocetkuRadaPrograma();
        postaviAtributKojiGovoriImaLiInterneta();

        if(jeLiPovratakIzKviza() == false)
            dodajFiktivnuKategorijuAkoNePostojiLokalno();

        FragmentManager fragmentManager = getFragmentManager();
        FrameLayout flListaPlace = (FrameLayout) findViewById(R.id.listPlace);

        //znaci da je dovoljno velik ekran
        if(flListaPlace != null)
        {
            reagujNaPovratakIzDodajKvizAkt();
            sirina550 = true;

            ListaFrag listaFrag;
            listaFrag = (ListaFrag) fragmentManager.findFragmentById(R.id.listPlace);

            if(listaFrag == null)
            {
                //kreiramo novi fragment ListaFrag ukoliko već nije kreiran
                listaFrag = new ListaFrag();

                Bundle bundleListaFrag = new Bundle();
                bundleListaFrag.putSerializable("sveKategorije",alSveKategorije);
                bundleListaFrag.putSerializable("sviKvizovi", alSviKvizovi);
                bundleListaFrag.putSerializable("svaPitanja", alSvaPitanja);
                listaFrag.setArguments(bundleListaFrag);

                fragmentManager.beginTransaction().replace(R.id.listPlace, listaFrag).commit();

                //DRUGI FRAGMENT
                DetailFrag detailFrag;
                detailFrag = (DetailFrag) fragmentManager.findFragmentById(R.id.detailPlace);

                //kreiramo novi fragment DetaliFrag ako vec nije kreiran
                if(detailFrag == null)
                {
                    detailFrag = new DetailFrag();
                    Bundle bundleDetailFrag = new Bundle();

                    //OVJDE DODATI DA SE NA POCETKU PRIKAZU PODACI O FIKTIVNOM KVIZU "Svi" PRI PRIKAZU NA EKRANU 500dp ILI VISE
                    bundleDetailFrag.putSerializable("sveKategorije",alSveKategorije);
                    bundleDetailFrag.putSerializable("sviKvizovi", alSviKvizovi);
                    bundleDetailFrag.putSerializable("svaPitanja", alSvaPitanja);
                    bundleDetailFrag.putSerializable("selektovana kategorija", kategorijaSviFiktivnaKategorija);

                    detailFrag.setArguments(bundleDetailFrag);
                    fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
                }
            }
        }
        else
        {
            //NE MOZE SE SVE OVO IZBACITI I POZVATI SAMO JEDAN OD DVA FRAGMENTA KOJI SE POZIVA KADA JE VECI EKRAN, JER
            // NEMAJU ISTE ELEMNETE U SEBI, NITI ISTI IZGLED (VETRIKALNO, POSTOJI SPIENR KATEGORIJA I LIST VIEW KVIZOVA),
            // DOK U POLOŽENOM OBLIKU U TOM FRAGMENTU SE NALATI SAMO LIST VIEW KATEGORIJA (SA SVOJIM IKONAMA, DOK U VERIKALNOM
            // POLOZAJU U SPINERU KATEGORIJA NEMA IKONE KATEGORIJE)
            prviPutSeDobavljaSveIzBaze = true;

            spPostojeceKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
            lvKvizovi = (ListView) findViewById(R.id.lvKvizovi);

            reagujNaPovratakIzDodajKvizAkt();

            adapterSpinerKategorijaNaziv = new AdapterSpinerKategorijaNaziv(this, android.R.layout.simple_spinner_dropdown_item,
                    alSveKategorije, "Kategorije" );
            spPostojeceKategorije.setAdapter(adapterSpinerKategorijaNaziv);
            for(int i=0; i<alSveKategorije.size(); i++)
            {
                if(alSveKategorije.get(i).getNaziv().equalsIgnoreCase("Svi"))
                {
                    spPostojeceKategorije.setSelection(i);
                    break;
                }
            }
            spPostojeceKategorije.setPrompt("Kategorije");

            /* OVAKO SE NISTA NE MOZE PISATI, JER SE METODOM "setContentView" POSTAVLJA xml FAJL IZ "layout" DIREKTORIJA. NAKON TOGA,
                METODOMO "findViewById" MOZE PRISTUPATI SAMO ELEMNTIMA IZ LAYOUT-A POSTAVLJNJEOG PRETHODNO POMENUTOM METODOM, A INACE
                VRACA null

            footerViewText = (TextView) findViewById(R.id.footerText);
            footerViewText.setText(R.string.dodajKviz);*/
            footerView = getLayoutInflater().inflate(R.layout.footer_dodaj_kviz, null);
            lvKvizovi.addFooterView(footerView);

            if(imaInterneta == true)
            staviOnLongClickListenerNaFooterListViewa();

            adapterKvizovi = new AdapterListaKvizova(this, R.layout.adapter_lista_s_ikonama, alFiltriraniKvizovi);
            lvKvizovi.setAdapter(adapterKvizovi);

            osvjeziAdaptereAkoPostoje();

            if(imaInterneta == true)
            staviItemSelectedListenerNaSpinerKategorijaAkoImaInterneta();
            else
                staviItemSelectedListenerNaSpinerKategorijaAkoNemaInterneta();

            if(imaInterneta == true)
            staviOnItemLongClickListenerNaListuKvizova();

            staviOnItemClickListenerNaListuKvizova();
        }

        if(imaInterneta == true)
        napuniAtributeNaOsnovuStanjaUFirebaseBazi();
        else
            napuniAtributeNaOsnovuStanjaUSQLiteBazi();

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    } // kraj "ocCreate()" metode

    private void napuniAtributeNaOsnovuStanjaUSQLiteBazi()
    {
        daoBazaHelper = new DAObazaHelper(getApplicationContext());
        Bundle sveIzSQLiteBaze = daoBazaHelper.dajSveIzSQLiteBaze();

        alSviKvizovi.clear();
        alSviKvizovi.addAll((ArrayList<Kviz>)sveIzSQLiteBaze.getSerializable("sviKvizoviIzSQLiteBaze"));
        alFiltriraniKvizovi.clear();
        alFiltriraniKvizovi.addAll(alSviKvizovi);

        alSveKategorije.clear();
        alSveKategorije.addAll((ArrayList<Kategorija>)sveIzSQLiteBaze.getSerializable("sveKategorijeIzSQLiteBaze"));
        dodajFiktivnuKategorijuAkoNePostojiLokalno();

        alSvaPitanja.clear();
        alSvaPitanja.addAll((ArrayList<Pitanje>)sveIzSQLiteBaze.getSerializable("svaPitanjaIzSQLiteBaze"));

        daoBazaHelper.closeDB();

        if(sirina550 == false)
        {
            for(int i=0; i<alSveKategorije.size(); i++)
            {
                if(alSveKategorije.get(i).getNaziv().equalsIgnoreCase("Svi"))
                {
                    spPostojeceKategorije.setSelection(i);
                    break;
                }
            }

            adapterSpinerKategorijaNaziv.notifyDataSetChanged();
            adapterKvizovi.notifyDataSetChanged();
        }
    }

    private void postaviAtributKojiGovoriImaLiInterneta()
    {
        ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        //should check null because in airplane mode it will be null
        if(netInfo == null || netInfo.isConnected() == false)
        {
            imaInterneta = false;
            Toast.makeText(this, "NEMA INTERNETA KvizoviAkt NA POCETKU/onRestart",Toast.LENGTH_LONG).show();
        }
        else
        {
            imaInterneta = true;
            Toast.makeText(this, "IMA INTERNETA KvizoviAkt NA POCETKU/onRestart",Toast.LENGTH_LONG).show();
        }

    }

    private void isprazniLoklanuSQLiteBazuNaPocetkuRadaPrograma()
    {
        daoBazaHelper = new DAObazaHelper(getApplicationContext());
        daoBazaHelper.izbrisiSveUnoseULoklnuSQLiteBazu(daoBazaHelper.getWritableDatabase());
        daoBazaHelper.closeDB();
    }

    private void staviOnItemClickListenerNaListuKvizova()
    {
        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                //ako dodje do slucaja da se odabere "Dodaj kviz" iz list view da se ne ucini insta, jer za to postoji poseban listener
                ViewGroup red = (ViewGroup) lvKvizovi.getChildAt(position);
                if( red.findViewById(R.id.footerText) != null)
                    return;

                //zabrani igranje kviza ako se poklapa sa nekim dogadjajem iz kalendara
                String pattern = "yyyy-MM-dd";
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
                Date sad = new Date();
                ArrayList<Pair<String, String>> dogadjajiIzKalendara = new ProcitajDogadjajeIzAplikacijeZaKalendar(KvizoviAkt.this).
                                                                            procitajPodatkeIzKalendara();

                for (int i=0; i<dogadjajiIzKalendara.size(); i++)
                {
                    long pocetakDogadjaja = Long.parseLong(dogadjajiIzKalendara.get(i).first);
                    long krajDogadjaja = Long.parseLong(dogadjajiIzKalendara.get(i).second);
                    Date datumIVrijemeDogadjajaIZKalendara = new Date(pocetakDogadjaja);

                    //provjer ima li dogadjaj na isti datum
                    if(simpleDateFormat.format(sad).equals(simpleDateFormat.format(datumIVrijemeDogadjajaIZKalendara)))
                        {
                        int trajanjeKviza = (int)Math.ceil(alSviKvizovi.get(position).getPitanja().size()/2.0);

                        long trenutnoVrijemeUMiliskenudnama = sad.getTime();
                        long vrijemeDogadjajaUMilisekundama = datumIVrijemeDogadjajaIZKalendara.getTime();
                        long trajanjeKvizaUMilisekundama = TimeUnit.MINUTES.toMillis(trajanjeKviza);
                        int minuteDoEventa = (int) (TimeUnit.MILLISECONDS.toMinutes(vrijemeDogadjajaUMilisekundama - trenutnoVrijemeUMiliskenudnama) + 1);

                        if(pocetakDogadjaja < trenutnoVrijemeUMiliskenudnama && trenutnoVrijemeUMiliskenudnama < krajDogadjaja)
                        {
                            android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(KvizoviAkt.this).create();
                            alertDialog.setTitle("NE MOZETE IGRATI KVIZ");
                            alertDialog.setMessage("Imate događaj koji je u kalendaru aktivan!");
                            alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog.show();

                            return;
                        }
                        else if(trenutnoVrijemeUMiliskenudnama + trajanjeKvizaUMilisekundama > vrijemeDogadjajaUMilisekundama && trenutnoVrijemeUMiliskenudnama < vrijemeDogadjajaUMilisekundama)
                        {
                            android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(KvizoviAkt.this).create();
                            alertDialog.setTitle("NE MOZETE IGRATI KVIZ");
                            alertDialog.setMessage("Imate događaj koji pocinje za "+minuteDoEventa+"minuta!");
                            alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog.show();

                            return;
                        }

                    }
                }

                Intent mojIntent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                mojIntent.putExtra("odabraniKvizZaIgrati", alSviKvizovi.get(position));

                KvizoviAkt.this.startActivity(mojIntent);
            }
        });
    }


    private void staviOnItemLongClickListenerNaListuKvizova()
    {
        //lvKvizovi.setLongClickable(true);
        lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int position, long id)
            {
                ViewGroup red = (ViewGroup) lvKvizovi.getChildAt(position);
                //ako je selektovan futer, nek se en desi nista,jer za to postoji zaseban listener
                if( red.findViewById(R.id.footerText) != null)
                    return true;

                Intent mojIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                // u onClickListener-u na ListView parametar id=-1 za header i footer_dodaj_kviz bude -1, a position=0 za header, a
                // za footer_dodaj_kviz postition = vel_liste ili position = vel_liste+1 ako u ima iznad liste vec header
                mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);
                mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);

                //ako se ne posalje "odabraniKviz" kao kljuc, u sljedecem prozoru ce se pri provjeri tog kljuca
                //sa metodom "getParcelExtra" vratiti se "null" vrijednost
                if(id != -1 && position != alFiltriraniKvizovi.size())
                {
                    //This is how you will pass a Serializable object
                    // using putExtra(String key, Serializable value) method
                    mojIntent.putExtra("odabraniKviz", alFiltriraniKvizovi.get(position));
                    mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", position);
                    mojIntent.putExtra("nacinRada", "editovanjeKviza");
                }

                KvizoviAkt.this.startActivity(mojIntent);

                return true;
            }
        });
    }

    private void staviItemSelectedListenerNaSpinerKategorijaAkoImaInterneta()
    {
        //Akcija koja se poduzima ako je selektovan neki element spinnera
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                //alFiltriraniKvizovi.clear();

                //METODA "getSelectedItem" VRACA INSTANCU TIPA KATEGOIJRE, A NE TEKST
                if(spPostojeceKategorije.getSelectedItem().equals(kategorijaSviFiktivnaKategorija))
                {
                    dajSveKvizoveIzBaze();
                }
                else
                {
                    Kategorija selektovanaKategorija = (Kategorija) spPostojeceKategorije.getSelectedItem();
                    dajSveKvizoveIzOdabraneKategorijeIzBaze(selektovanaKategorija);
                }

                adapterKvizovi.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                if(alSveKategorije.size() != 0)
                {
                }
            }
        });
    }

    private void staviItemSelectedListenerNaSpinerKategorijaAkoNemaInterneta()
    {
        //Akcija koja se poduzima ako je selektovan neki element spinnera
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                Kategorija selektovanaKategorija = (Kategorija) spPostojeceKategorije.getSelectedItem();

                alFiltriraniKvizovi.clear();

                if(selektovanaKategorija.getNaziv().equalsIgnoreCase("Svi"))
                    alFiltriraniKvizovi.addAll(alSviKvizovi);
                else
                {
                    for(int i=0; i<alSviKvizovi.size(); i++)
                    {
                        if(alSviKvizovi.get(i).getKategorija().getNaziv().equalsIgnoreCase(selektovanaKategorija.getNaziv()))
                            alFiltriraniKvizovi.add(alSviKvizovi.get(i));
                    }

                }

                adapterKvizovi.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                if(alSveKategorije.size() != 0)
                {
                }
            }
        });
    }

    private void staviOnLongClickListenerNaFooterListViewa()
    {
        footerView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v)
            {
                Intent mojIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);

                // u onClickListener-u na ListView parametar id=-1 za header i footer_dodaj_kviz bude -1, a position=0 za header, a
                // za footer_dodaj_kviz postition = vel_liste ili position = vel_liste+1 ako u ima iznad liste vec header
                mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);
                mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);

                mojIntent.putExtra("nacinRada", "dodavanjeKviza");

                KvizoviAkt.this.startActivity(mojIntent);

                return true;
            }
        });
    }

    private void dodajFiktivnuKategorijuAkoNePostojiLokalno()
    {
        boolean imaKategorijeSvi = false;
        for(int i=0; i<alSveKategorije.size(); i++)
        {
            if(alSveKategorije.get(i).getNaziv().equalsIgnoreCase("Svi"))
            {
                imaKategorijeSvi = true;
                break;
            }
        }
        if(imaKategorijeSvi == false)
            alSveKategorije.add(kategorijaSviFiktivnaKategorija);
    }

    @Override
    protected void onStart()
    {
        super.onStart();

        //LOKALNA SQLite BAZA SE APDEJTUJE PRI SVAKOM ULASKU U OVU AKTIVNOST
        napuniAtributeNaOsnovuStanjaUFirebaseBaziDaBiApdejtovaoLoklanuSQLiteBazu();
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        unregisterReceiver(broadcastReceiver);
    }

    @Override
    protected void onRestart()
    {
        super.onRestart();

        postaviAtributKojiGovoriImaLiInterneta();
        kreiranaAkativnostiIliOnRestart = true;

        IntentFilter intentFilter1 = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(broadcastReceiver, intentFilter1);
    }

    private void dajSveKvizoveIzBaze()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null,this, intsDajSveKvizoveIzBaze.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);

        startService(mojIntent);
    }

    private void dajSveKvizoveIzOdabraneKategorijeIzBaze(Kategorija selektovanaKategorija)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajKvizoveIzOdabraneKategorije.class);
        mojIntent.putExtra("selektovanaKategorija", selektovanaKategorija);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        startService(mojIntent);
    }

    private void napuniAtributeNaOsnovuStanjaUFirebaseBazi()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);

        startService(mojIntent);
    }

    //sluzi za obradu informacija koje se vrate kroz intent servise
    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        switch (resultCode)
        {
            case intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */

                if(imaInterneta == true && sirina550 == false)
                {
                    staviItemSelectedListenerNaSpinerKategorijaAkoImaInterneta();
                }

                //AKO SE UCITAVAJU SVE INFORMACIJE IZ BAZE NA POCETKU RADA PROGRAMA
                if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeno sve iz baze"))
                {
                    alSveKategorije.clear();
                    alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    dodajFiktivnuKategorijuAkoNePostojiLokalno();

                    alSviKvizovi.clear();
                    alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                    alSvaPitanja.clear();
                    alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));

                    if(sirina550 == false)
                    {
                        for(int i = 0; i < alSveKategorije.size(); i++)
                        {
                            if(alSveKategorije.get(i).getNaziv().equals("Svi"))
                            {
                                spPostojeceKategorije.setSelection(i);
                                alFiltriraniKvizovi.clear();
                                alFiltriraniKvizovi.addAll(alSviKvizovi);
                                adapterKvizovi.notifyDataSetChanged();
                                break;
                            }
                        }
                        adapterSpinerKategorijaNaziv.notifyDataSetChanged();
                        adapterKvizovi.notifyDataSetChanged();
                    }
                    else if(sirina550 == true)
                    {
                        ListaFrag listaFrag = new ListaFrag();

                        Bundle bundleListaFrag = new Bundle();
                        bundleListaFrag.putSerializable("sveKategorije",alSveKategorije);
                        bundleListaFrag.putSerializable("sviKvizovi", alSviKvizovi);
                        bundleListaFrag.putSerializable("svaPitanja", alSvaPitanja);
                        listaFrag.setArguments(bundleListaFrag);

                        getFragmentManager().beginTransaction().replace(R.id.listPlace, listaFrag).commit();
                    }

                    if(resultData.getString("zadatak2") != null &&
                            resultData.get("zadatak2").equals("apdejtovanje lokalne SQLite baze"))
                    {
                        ArrayList<Ranglista> alSveRangliste = (ArrayList<Ranglista>) resultData.getSerializable("alSveRangliste");

                        apdejtujLokalnuSQLiteBazuNaOsnovuInformacijaIzFirebasea(alSveKategorije, alSviKvizovi, alSvaPitanja, alSveRangliste);
                    }
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeni kvizovi iz kategorije"))
                {
                    //AKO SE UCITAVAJU KVIZOVI IZ SELEKTOVANE KATEGORIJE

                    ArrayList<Kviz> sviKvizoviIzBazeIzSelektovaneKategorije = (ArrayList<Kviz>) resultData.getSerializable("kvizoviIzOdabraneKategorije");
                    ArrayList<Pitanje> pitanjaIzKvizovaIzKategorije = (ArrayList<Pitanje>) resultData.getSerializable("svaPitanjaIzKvizovaIzKategorije");

                    alFiltriraniKvizovi.clear();
                    alFiltriraniKvizovi.addAll(sviKvizoviIzBazeIzSelektovaneKategorije);
                    //dodavanje kvizova lokalno, iz selektovane kategorije, kojih ima u bazi, a nema lokalno
                    for(int i=0; i < sviKvizoviIzBazeIzSelektovaneKategorije.size(); i++)
                    {
                        boolean dodajKviz = true;
                        for(int j=0; j < alSviKvizovi.size(); j++)
                        {
                            if(sviKvizoviIzBazeIzSelektovaneKategorije.get(i).getNaziv().equals(alSviKvizovi.get(j).getNaziv()))
                            {
                                dodajKviz = false;
                                break;
                            }
                        }

                        if(dodajKviz == true)
                        {
                            alSviKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                            alFiltriraniKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                        }
                    }

                    //dodavanje pitanja koji ne postoje lokalno, iz dobavlejnih kvizova su, a ima ih u bazi
                    for(int i=0; i < pitanjaIzKvizovaIzKategorije.size(); i++)
                    {
                        boolean dodajPitanje = true;
                        for(int j=0; j < alSvaPitanja.size(); j++)
                        {
                            if(pitanjaIzKvizovaIzKategorije.get(i).getNaziv().equals(alSvaPitanja.get(j).getNaziv()))
                            {
                                dodajPitanje = false;
                                break;
                            }
                        }

                        if(dodajPitanje == true)
                            alSviKvizovi.add(sviKvizoviIzBazeIzSelektovaneKategorije.get(i));
                    }

                    if(sirina550 == false)
                    adapterKvizovi.notifyDataSetChanged();
                    else
                    {
                        proslijediOdabraneKvizoveUDetailFrag((Kategorija) resultData.getSerializable("selektovana kategorija"));
                    }
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeni svi kvizovi iz baze"))
                {
                    //ovo je skljucivo dodatno da se ne bi ova lista dva puta azurirala pri porketanju
                    if(prviPutSeDobavljaSveIzBaze == false)
                    {
                        alSviKvizovi.clear();
                        alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                        alFiltriraniKvizovi.clear();
                        alFiltriraniKvizovi.addAll(alSviKvizovi);
                    }
                    else
                        prviPutSeDobavljaSveIzBaze = false;
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.getString("zadatak").equals("updjetovane ranglite na firebaseu na osnovu podataka iz sqlitea"))
                {
                    int brojUcitanihRezultataUKolekcijuRanglisteNaFirebase = resultData.getInt("brojUcitanihRezultataNaFirebase");

                    if(brojUcitanihRezultataUKolekcijuRanglisteNaFirebase > 1)
                        Toast.makeText(KvizoviAkt.this, "u firebase dodano "+brojUcitanihRezultataUKolekcijuRanglisteNaFirebase+" rezultata"
                                ,Toast.LENGTH_LONG).show();
                    else if( brojUcitanihRezultataUKolekcijuRanglisteNaFirebase == 1)
                        Toast.makeText(KvizoviAkt.this, "u firebase dodano "+brojUcitanihRezultataUKolekcijuRanglisteNaFirebase+" rezultat"
                                ,Toast.LENGTH_LONG).show();

                    napuniAtributeNaOsnovuStanjaUFirebaseBaziDaBiApdejtovaoLoklanuSQLiteBazu();
                }


                if(sirina550 == false)
                {
                    adapterSpinerKategorijaNaziv.notifyDataSetChanged();
                    adapterKvizovi.notifyDataSetChanged();
                }
                else if(sirina550 == true)
                {
                    proslijediSveKvizoveUDetaliFrag();
                }

                break;
            case intsDajSveKategorijeSveKvizoveSvaPitanjaSveRangliste.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */
                if(resultData.getString("zadatak") != null &&
                    resultData.get("zadatak").equals("nema kolekcije neke u bazi"))
                {
                    if(resultData.getSerializable("alSveKategorije") != null)
                    {
                        alSveKategorije.clear();
                        alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    }

                    if(resultData.getSerializable("alSviKvizovi") != null)
                    {
                        alSviKvizovi.clear();
                        alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));
                    }

                    if(resultData.getSerializable("alSvaPitanja") != null)
                    {
                        alSvaPitanja.clear();
                        alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                    }

                    if(resultData.getString("zadatak2") != null &&
                            resultData.get("zadatak2").equals("apdejtovanje lokalne SQLite baze"))
                    {
                        ArrayList<Ranglista> alSveRangliste = (ArrayList<Ranglista>) resultData.getSerializable("alSveRangliste");

                        apdejtujLokalnuSQLiteBazuNaOsnovuInformacijaIzFirebasea(alSveKategorije, alSviKvizovi, alSvaPitanja, alSveRangliste);
                    }
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kvizova u bazi"))
                {
                    Log.d("NEMA KVIZOVA U BAZI", "jos nije dodatn nijedan kviz u bazu");
                }

                break;
        }

    }

    private void proslijediOdabraneKvizoveUDetailFrag(Kategorija selektovana)
    {
        DetailFrag detailFrag = new DetailFrag();

        Bundle proslijedi = new Bundle();
        proslijedi.putSerializable("sveKategorije",alSveKategorije);
        proslijedi.putSerializable("sviKvizovi", alSviKvizovi);
        proslijedi.putSerializable("svaPitanja", alSvaPitanja);
        Kategorija selektovanaKategorija = selektovana;
        proslijedi.putSerializable("selektovana kategorija", selektovanaKategorija);

        detailFrag.setArguments(proslijedi);
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
    }

    private void proslijediSveKvizoveUDetaliFrag()
    {
        DetailFrag detailFrag = new DetailFrag();

        Bundle proslijedi = new Bundle();
        proslijedi.putSerializable("sveKategorije",alSveKategorije);
        proslijedi.putSerializable("sviKvizovi", alSviKvizovi);
        proslijedi.putSerializable("svaPitanja", alSvaPitanja);
        Kategorija selektovanaKategorija = kategorijaSviFiktivnaKategorija;
        proslijedi.putSerializable("selektovana kategorija", selektovanaKategorija);

        detailFrag.setArguments(proslijedi);
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
    }

    private void apdejtujLokalnuSQLiteBazuNaOsnovuInformacijaIzFirebasea(ArrayList<Kategorija> alSveKategorije, ArrayList<Kviz> alSviKvizovi,
                                                                         ArrayList<Pitanje> alSvaPitanja, ArrayList<Ranglista> alSveRangliste)
    {
        daoBazaHelper = new DAObazaHelper(getApplicationContext());
        String brojAzuriranihPolja = daoBazaHelper.azurirajInformacijeULokalnojBaziKadaDobijesPristupInternetu(
                alSveKategorije, alSviKvizovi, alSvaPitanja, alSveRangliste);
        String stanjeSvihTabelaUSQLiteBazi = daoBazaHelper.dajStringPrikazStanjaUSvimTabelamaUSQLiteBazi();
        daoBazaHelper.closeDB();

        if(sirina550 == false)
        {
            android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(this).create();
            alertDialog.setTitle("APDEJTOVANA LOKALNA SQLITE BAZA");
            alertDialog.setMessage(brojAzuriranihPolja);
            alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
    }

    private boolean jeLiPovratakIzKviza()
    {
        if(getIntent().getStringExtra("razlogPovratka") == null)
            return false;

        return true;
    }

    private void reagujNaPovratakIzDodajKvizAkt()
    {
        if(getIntent().getStringExtra("razlogPovratka") != null)
        {
            alSveKategorije.clear();
            alSvaPitanja.clear();

            alSveKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("sveKategorije");
            alSvaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("svaPitanja");

            dodajFiktivnuKategorijuAkoNePostojiLokalno();

            int pozicijaKategorijeSvi = alSveKategorije.size();
            for(int i=0; i<alSveKategorije.size(); i++)
            {
                if(alSveKategorije.get(i).getNaziv().equalsIgnoreCase("Svi"))
                {
                    pozicijaKategorijeSvi = i;
                    break;
                }
            }

            if( (alSveKategorije.size()-1) >= 1)
            Collections.swap(alSveKategorije, pozicijaKategorijeSvi, alSveKategorije.size()-1);
        }

        // mojIntent.putExtra("razlogPovratka", "promjenaKviza");
        if(getIntent().getStringExtra("razlogPovratka") != null &&
                getIntent().getStringExtra("razlogPovratka").equals("promjenaKviza"))
        {
            alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizoviIPromjenjeni");
        }
        else if(getIntent().getStringExtra("razlogPovratka") != null &&
                getIntent().getStringExtra("razlogPovratka").equals("dodavanjeKviza"))
        {
            alSviKvizovi.clear();
            alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizoviIDodani");
        }
        else if (getIntent().getStringExtra("razlogPovratka") != null &&
                getIntent().getStringExtra("razlogPovratka").equals("dodavanjeKategorijeBezKviza"))
        {
            alSviKvizovi.clear();
            alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");
        }

        dodajFiktivnuKategorijuAkoNePostojiLokalno();
        osvjeziAdaptereAkoPostoje();
    }

    private void osvjeziAdaptereAkoPostoje()
    {
        if(adapterSpinerKategorijaNaziv != null && adapterKvizovi != null)
        {
            adapterSpinerKategorijaNaziv.notifyDataSetChanged();
            adapterKvizovi.notifyDataSetChanged();
        }
    }

    public void napuni()
    {
        /*alSveKategorije.add(new Kategorija("Biologija", "990"));
        alSveKategorije.add(new Kategorija("Hemija", "130"));
        alSveKategorije.add(new Kategorija("Historija", "1"));
        alSveKategorije.add(new Kategorija("Bosanski", "2"));
        alSveKategorije.add(new Kategorija("Matematika", "3"));
        alSveKategorije.add(new Kategorija("Njemacki", "4"));
        alSveKategorije.add(new Kategorija("Tjlesno", "5"));
        alSveKategorije.add(new Kategorija("Likovno", "6"));

        ArrayList<String> alOdg = new ArrayList<>();
        alOdg.add("prvi odg");
        alOdg.add("drugi odg");
        alOdg.add("treci odg");
        alOdg.add("cetvrti odg");
        alOdg.add("peti odg");
        alSvaPitanja.add(new Pitanje("prvo pitanje", "tekst prvog" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("drugo pitanje", "tekst drugog" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("trece pitanje", "tekst treci" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("cetvrto pitanje", "tekst cetvrti" , alOdg, "prvi odg"));
        alSvaPitanja.add(new Pitanje("peto pitanje", "tekst peti" , alOdg, "prvi odg"));

        ArrayList<Pitanje> prviKvizPitanja = new ArrayList<>();
        prviKvizPitanja.add(new Pitanje("kv1 prvo pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 drugo pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 trece pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 cetvrto pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 peto pitanje", "tekst prvog" , alOdg, "prvi odg"));
        prviKvizPitanja.add(new Pitanje("kv1 sesto pitanje", "tekst prvog" , alOdg, "prvi odg"));

        alSvaPitanja.addAll(prviKvizPitanja);

        alSviKvizovi.add(new Kviz("prvi kviz bio" , prviKvizPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("drugi kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("treci kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("cetvrti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("peti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sedmi kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("osmi kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("deveti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("deseti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("jedanaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("dvanaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("trinaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("cetrnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("petnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sesnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));
        alSviKvizovi.add(new Kviz("sedamnaesti kviz bio", alSvaPitanja, new Kategorija("Biologija", "990") ));

        alSviKvizovi.add(new Kviz("prvi kviz hemija" , alSvaPitanja, new Kategorija("Hemija", "130")));
        alSviKvizovi.add(new Kviz("drugi kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("treci kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("cetvrti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("peti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("sesti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("sedmi kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("osmi kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("deveti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));
        alSviKvizovi.add(new Kviz("deseti kviz hemija", alSvaPitanja, new Kategorija("Hemija", "130") ));*/


        ArrayList<Kategorija> pocetneKategorije = new ArrayList<>();
        ArrayList<Kviz> pocetniKvizovi = new ArrayList<>();
        ArrayList<Pitanje> pocetnaPitanja = new ArrayList<>();

        //KATEGORIJA
        Kategorija kategorija1 = new Kategorija();
        kategorija1.setNaziv("kategorija1");
        kategorija1.setId("1");

        Kategorija kategorija2 = new Kategorija();
        kategorija2.setNaziv("kategorija2");
        kategorija2.setId("2");

        pocetneKategorije.add(kategorija1);
        pocetneKategorije.add(kategorija2);

        //PITANJE
        Pitanje pitanje5 = new Pitanje();
        pitanje5.setNaziv("pitanje5");
        ArrayList<String> odgovori = new ArrayList<>();
        for(int i = 0; i<4; i++)
        {
            odgovori.add("ne"+String.valueOf(i));
        }
        odgovori.add("da");
        pitanje5.setOdgovori(odgovori);
        pitanje5.setTacan("da");
        pitanje5.setTekstPitanja(pitanje5.getNaziv());
        //drugo pitanje
        Pitanje pitanje6 = new Pitanje();
        pitanje6.setNaziv("pitanje6");
        ArrayList<String> odgovori2 = new ArrayList<>();
        for(int i = 0; i<4; i++)
        {
            odgovori2.add("ne"+String.valueOf(i));
        }
        odgovori2.add("da");
        pitanje6.setOdgovori(odgovori2);
        pitanje6.setTacan("da");
        pitanje6.setTekstPitanja(pitanje6.getNaziv());
        //trece pitanje
        Pitanje pitanje7 = new Pitanje();
        pitanje7.setNaziv("pitanje7");
        ArrayList<String> odgovori3 = new ArrayList<>();
        for(int i = 0; i<4; i++)
        {
            odgovori3.add("ne"+String.valueOf(i));
        }
        odgovori3.add("da");
        pitanje7.setOdgovori(odgovori3);
        pitanje7.setTacan("da");
        pitanje7.setTekstPitanja(pitanje7.getNaziv());

        pocetnaPitanja.add(pitanje5);
        pocetnaPitanja.add(pitanje6);
        pocetnaPitanja.add(pitanje7);
        //KVIZ
        Kviz kviz1 = new Kviz();
        kviz1.setNaziv("kviz1");
        kviz1.setKategorija(kategorija1);
        kviz1.getPitanja().add(pitanje5);

        Kviz kviz2 = new Kviz();
        kviz2.setNaziv("kviz2");
        kviz2.setKategorija(kategorija2);
        kviz2.getPitanja().add(pitanje5);
        kviz2.getPitanja().add(pitanje6);

        pocetniKvizovi.add(kviz1);
        pocetniKvizovi.add(kviz2);

        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsNapuniBazuPocetnimVrijednostima.class);
        mojIntent.putExtra("pocetneKategorije", pocetneKategorije);
        mojIntent.putExtra("pocetniKvizovi", pocetniKvizovi);
        mojIntent.putExtra("pocetnaPitanja", pocetnaPitanja);
        startService(mojIntent);
    }

    //metoda koja je implementirana zbog interfejsa iz fragmenta kada je zakrenut telefon
    @Override
    public void klikNaKategoriju(Kategorija odabranaKategorija)
    {
        if(odabranaKategorija.getNaziv().equalsIgnoreCase("Svi") == true)
            dajSveKvizoveIzBaze();
        else
        dajSveKvizoveIzOdabraneKategorijeIzBaze(odabranaKategorija);

        /*
        //PREBACENO U ON RESULT RECIEVED
        DetailFrag detailFrag = new DetailFrag();

        Bundle proslijedi = new Bundle();
        proslijedi.putSerializable("kategorijaSve",alSveKategorije);
        proslijedi.putSerializable("sviKvizovi", alSviKvizovi);
        proslijedi.putSerializable("svaPitanja", alSvaPitanja);

        detailFrag.setArguments(proslijedi);
        getFragmentManager().beginTransaction().replace(R.id.detailPlace, detailFrag).commit();*/
    }

    @Override
    public void onBackPressed()
    {
        moveTaskToBack(true);
    }
}
