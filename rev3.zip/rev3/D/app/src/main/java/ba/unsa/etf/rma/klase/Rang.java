package ba.unsa.etf.rma.klase;

public class Rang {
    int pozicija;
    String imeIgraca;
    String procenatTacnih;


}
