package ba.unsa.etf.rma.aktivnosti;

import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;

public class IgrajKvizAkt extends AppCompatActivity {
    InformacijeFrag gornjiFrag;
    PitanjeFrag donjiFrag;
    RangLista drugiDonjiFrag;
    public static Kviz kviz=new Kviz("",null,null);;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);Bundle extras = getIntent().getExtras();
        if(extras!=null){
            kviz = extras.getParcelable("kviz");
        }

            gornjiFrag = new InformacijeFrag();
            donjiFrag = new PitanjeFrag();
            drugiDonjiFrag = new RangLista();

            android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.informacijePlace,donjiFrag);
            ft.replace(R.id.pitanjePlace,gornjiFrag);
            ft.commit();

    }
}
