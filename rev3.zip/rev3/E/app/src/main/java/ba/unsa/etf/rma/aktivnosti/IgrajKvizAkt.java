package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.PromjenaVrijednosti, InformacijeFrag.Nazad {
    private int brojTacnihPitanja = 0;
    private int brojOstalihPitanja = 0;
    private double procenat = 0;
    private int brojDoTadaOdgovora = 0;
    private Kviz kviz = new Kviz();
    private ArrayList<Pitanje> listPitanjaKviza = new ArrayList<>();
    private int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);
        kviz.setNaziv(getIntent().getStringExtra("nazivKviza"));
        listPitanjaKviza = (ArrayList<Pitanje>) getIntent().getSerializableExtra("pitanja");
        if (listPitanjaKviza.size() != 0) {
            if (listPitanjaKviza.get(listPitanjaKviza.size() - 1).getNaziv().equals("Dodaj pitanje"))
                listPitanjaKviza.remove(listPitanjaKviza.size() - 1);
        }
        brojOstalihPitanja = listPitanjaKviza.size() - 1;
        kviz.setPitanja(listPitanjaKviza);
        Collections.shuffle(kviz.getPitanja());
        Pitanje randomPitanje;
        if (listPitanjaKviza.size() != 0) {
            randomPitanje = kviz.getPitanja().get(0);
        } else {
            brojOstalihPitanja = 0;
            ArrayList<String> odg = new ArrayList<>();
            randomPitanje = new Pitanje("Kviz je završen!", "Kviz je završen!", odg, "");
        }
        if (randomPitanje.getNaziv().equals("Kviz je završen!")) {
            final AlertDialog.Builder alertDialog = new AlertDialog.Builder(IgrajKvizAkt.this);
            alertDialog.setTitle("UNOS");
            alertDialog.setMessage("Unesite ime: ");
            final EditText input = new EditText(IgrajKvizAkt.this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            input.setLayoutParams(lp);
            alertDialog.setView(input);
            alertDialog.setIcon(R.drawable.error);
            alertDialog.setPositiveButton("OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
            //alertDialog.show();
            final AlertDialog ad = alertDialog.create();
            ad.show();
            ad.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //System.out.println("INPUT JEE: " + input.getText().toString());
                    if (input.getText().toString().length() != 0) {
                        Bundle arg = new Bundle();
                        RangLista df = new RangLista();
                        arg.putString("nazivKviza", kviz.getNaziv());
                        arg.putString("imeIgraca", input.getText().toString());
                        arg.putString("procenat", String.valueOf(procenat));
                        df.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.pitanjePlace, df).commit();
                        Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                        ad.dismiss();
                    } else {
                        input.setBackgroundColor(Color.RED);
                        Toast.makeText(getApplicationContext(), "Unesite ime", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            FragmentManager fm = getSupportFragmentManager();
            FrameLayout pitanja = (FrameLayout) findViewById(R.id.pitanjePlace);

            if (pitanja != null) {
                PitanjeFrag fd = (PitanjeFrag) fm.findFragmentById(R.id.pitanjePlace);
                if (fd == null) {
                    fd = new PitanjeFrag();
                    Bundle arg = new Bundle();
                    arg.putString("tekstPitanja", randomPitanje.getNaziv());
                    arg.putStringArrayList("odgovoriPitanja", randomPitanje.getOdgovori());
                    arg.putString("jesteTacan", randomPitanje.getTacan());
                    fd.setArguments(arg);
                    fm.beginTransaction().replace(R.id.pitanjePlace, fd).commit();
                } else {
                    fm.popBackStack(null, android.support.v4.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }
            }
        }
        FragmentManager fm = getSupportFragmentManager();
        FrameLayout inf = (FrameLayout) findViewById(R.id.informacijePlace);

        if (inf != null) {
            InformacijeFrag fd = (InformacijeFrag) fm.findFragmentById(R.id.informacijePlace);
            if (fd == null) {
                fd = new InformacijeFrag();
                Bundle arg = new Bundle();
                arg.putString("naziv", kviz.getNaziv());
                arg.putString("brojTacnihPitanja", String.valueOf(brojTacnihPitanja));
                arg.putString("brojOstalihPitanja", String.valueOf(brojOstalihPitanja));
                arg.putString("procenat", String.valueOf(procenat));
                fd.setArguments(arg);
                fm.beginTransaction().replace(R.id.informacijePlace, fd).commit();
            } else {
                fm.popBackStack(null, android.support.v4.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
            }
        }
    }

    @Override
    public void promijeniVrijednostiTacan() {
        Bundle arg = new Bundle();
        brojTacnihPitanja++;
        if (brojOstalihPitanja == 0) {
            brojOstalihPitanja = 0;
        } else brojOstalihPitanja--;
        brojDoTadaOdgovora++;
        procenat = (double) brojTacnihPitanja / brojDoTadaOdgovora;
        procenat = Math.round(procenat * 100.0) / 100.0;
        arg.putString("naziv", kviz.getNaziv());
        arg.putString("brojTacnihPitanja", String.valueOf(brojTacnihPitanja));
        arg.putString("brojOstalihPitanja", String.valueOf(brojOstalihPitanja));
        arg.putString("procenat", String.valueOf(procenat));
        InformacijeFrag df = new InformacijeFrag();
        df.setArguments(arg);
        getSupportFragmentManager().beginTransaction().replace(R.id.informacijePlace, df).commit();
    }

    @Override
    public void promijeniVrijednostiOstali() {
        if (brojOstalihPitanja == 0) {
            brojOstalihPitanja = 0;
        } else brojOstalihPitanja--;
        Bundle arg = new Bundle();
        brojDoTadaOdgovora++;
        procenat = (double) brojTacnihPitanja / brojDoTadaOdgovora;
        procenat = Math.round(procenat * 100.0) / 100.0;
        arg.putString("naziv", kviz.getNaziv());
        arg.putString("brojTacnihPitanja", String.valueOf(brojTacnihPitanja));
        arg.putString("brojOstalihPitanja", String.valueOf(brojOstalihPitanja));
        arg.putString("procenat", String.valueOf(procenat));
        InformacijeFrag df = new InformacijeFrag();
        df.setArguments(arg);
        getSupportFragmentManager().beginTransaction().replace(R.id.informacijePlace, df).commit();
    }

    @Override
    public void funkcija() {
        Pitanje randomPitanje;
        i++;
        if (i == listPitanjaKviza.size()) {
            ArrayList<String> odg = new ArrayList<>();
            randomPitanje = new Pitanje("Kviz je završen!", "Kviz je završen!", odg, "");
        } else {
            randomPitanje = listPitanjaKviza.get(i);
        }
        if (randomPitanje.getNaziv().equals("Kviz je završen!")) {
            final AlertDialog.Builder alertDialog = new AlertDialog.Builder(IgrajKvizAkt.this);
            alertDialog.setTitle("UNOS");
            alertDialog.setMessage("Unesite ime: ");
            final EditText input = new EditText(IgrajKvizAkt.this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            input.setLayoutParams(lp);
            alertDialog.setView(input);
            alertDialog.setIcon(R.drawable.error);
            alertDialog.setPositiveButton("OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
            //alertDialog.show();
            final AlertDialog ad = alertDialog.create();
            ad.show();
            ad.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //System.out.println("INPUT JEE: " + input.getText().toString());
                    if (input.getText().toString().length() != 0) {
                        Bundle arg = new Bundle();
                        RangLista df = new RangLista();
                        arg.putString("nazivKviza", kviz.getNaziv());
                        arg.putString("imeIgraca", input.getText().toString());
                        arg.putString("procenat", String.valueOf(procenat));
                        df.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.pitanjePlace, df).commit();
                        Toast.makeText(getApplicationContext(), "You clicked on OK", Toast.LENGTH_SHORT).show();
                        ad.dismiss();
                    } else {
                        input.setBackgroundColor(Color.RED);
                        Toast.makeText(getApplicationContext(), "Unesite ime", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            Bundle arg = new Bundle();
            PitanjeFrag df = new PitanjeFrag();
            arg.putString("tekstPitanja", randomPitanje.getNaziv());
            arg.putStringArrayList("odgovoriPitanja", randomPitanje.getOdgovori());
            arg.putString("jesteTacan", randomPitanje.getTacan());
            df.setArguments(arg);
            getSupportFragmentManager().beginTransaction().replace(R.id.pitanjePlace, df).commit();
        }
    }

    @Override
    public void nazad() {
        super.onBackPressed();
    }
}
