package ba.unsa.etf.rma.klase;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class KategorijeAdapter extends BaseAdapter implements View.OnClickListener {

    private Activity activity;
    private ArrayList kategorije;
    private static LayoutInflater inflater = null;
    public Resources res;
    Kategorija kategorija = null;
    int i = 0;

    @Override
    public void onClick(View v) {
    }

    public static class ViewHolder{
        public TextView naziv;
        public ImageView ikona;
    }

    public KategorijeAdapter(Activity activity, ArrayList data, Resources res) {
        this.activity = activity;
        this.kategorije = data;
        this.res = res;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        if (kategorije.size() <= 0)
            return 1;
        return kategorije.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        KategorijeAdapter.ViewHolder holder;
        if (convertView == null) {
            v = inflater.inflate(R.layout.element_liste, null);
            holder = new KategorijeAdapter.ViewHolder();
            holder.naziv = (TextView) v.findViewById(R.id.Itemname);
            holder.ikona = (ImageView) v.findViewById(R.id.icon);
            v.setTag(holder);
        }
        else {
            holder = (KategorijeAdapter.ViewHolder) v.getTag();
        }
        if (kategorije.size() <= 0) {
            holder.naziv.setText(R.string.nema_info);
            holder.ikona.setImageResource(0);
        }
        else {
            kategorija = (Kategorija) kategorije.get(position);
            holder.naziv.setText(kategorija.getNaziv());
            //holder.ikona.setImageResource(res.getIdentifier("ba.unsa.etf.rma:drawable/" + kategorija.getId(),null, null));
            //holder.ikona.setImageResource(Integer.parseInt(kategorija.getId()));
            //v.setOnClickListener(new AdapterView.OnItemClickListener(position));
        }
        return v;
    }
}
