package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijeAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizAdapter;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.PressListView {

    private ListView lvKvizovi;
    private Spinner spPostojeceKategorije;
    public static ArrayList<Kviz> kvizovi = new ArrayList<>();
    public static ArrayList<Kviz> filterKvizovi = new ArrayList<>();
    public static ArrayList<Kviz> filterKvizovi2 = new ArrayList<>();
    private KvizAdapter adapter;
    private KategorijeAdapter adapterKategorija;
    public static ArrayList<Kategorija> kategorije = new ArrayList<>();
    public static ArrayList<Kviz> validacijaKvizova = new ArrayList<>();
    public static int pozicija = 0;
    public static boolean filtrirano = false;
    public static boolean filtrirano2 = false;
    public static ArrayList<Pair<String, Kategorija>> pocetneKategorijeIzBaze = new ArrayList<>();
    public static ArrayList<Pair<String, Pitanje>> pocetnaPitanjaIzBaze = new ArrayList<>();
    public static ArrayList<Pair<String, Kviz>> pocetniKvizoviIzBaze = new ArrayList<>();
    public static boolean imaDodajPitanje = false;
    private Kviz kvizKojiVracam = new Kviz();

    public class FiltrirajKvizoveKlasa extends AsyncTask<String, Void, Void> {

        AsyncResponse ar = null;

        public FiltrirajKvizoveKlasa(AsyncResponse dodaj_kviz) {
            this.ar = dodaj_kviz;
        }

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);
                String query = "{\n" +
                        "\"structuredQuery\": {\n" +
                        "\"where\": {\n" +
                        "\"fieldFilter\": {\n" +
                        "\"field\": {\"fieldPath\": \"idKategorije\"}, \n" +
                        "\"op\": \"EQUAL\",\n" +
                        "\"value\": {\"stringValue\": \"" + strings[0] + "\"}\n" +
                        "}\n" +
                        "},\n" +
                        "\"select\": {\"fields\": [ {\"fieldPath\": \"idKategorije\"}, {\"fieldPath\": \"naziv\"}, {\"fieldPath\": \"pitanja\"} ] }, \n" +
                        "\"from\": [{\"collectionId\" : \"Kvizovi\"}], \n" +
                        "\"limit\" : 1000\n" +
                        "}\n" +
                        "}";
                String url = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents:runQuery?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                connection.setDoOutput(true);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = query.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = connection.getResponseCode();
                StringBuilder response = null;
                InputStream odgovor = connection.getInputStream();
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))
                ) {
                    response = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        response.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR QUERIJAA:  ", response.toString());
                }

                String rezultatKvizovi = response.toString();
                rezultatKvizovi = "{ \"documents\": " + rezultatKvizovi + "}";
                if (!rezultatKvizovi.equals("{}")) {
                    JSONObject joKvizovi = new JSONObject(rezultatKvizovi);
                    JSONArray documentsKvizovi = joKvizovi.getJSONArray("documents");
                    System.out.println("DOKUMENT: " + documentsKvizovi.toString());
                    System.out.println("parsDokument" + documentsKvizovi.toString().substring(4, 11));
                    for (int i = 0; i < documentsKvizovi.length(); i++) {
                        JSONObject doc = documentsKvizovi.getJSONObject(i);
                        if (doc.has("document")) {
                            JSONObject docc = doc.getJSONObject("document");
                            String nameKviza = docc.getString("name");
                            int brojac3 = 0;
                            for (int kv = 0; kv < nameKviza.length(); kv++) {
                                if (nameKviza.charAt(kv) == '/') {
                                    brojac3++;
                                }
                                if (brojac3 == 6) {
                                    nameKviza = nameKviza.substring(++kv, nameKviza.length());
                                    break;
                                }
                            }
                            JSONObject fields = docc.getJSONObject("fields");
                            JSONObject stringValue = fields.getJSONObject("naziv");
                            String nazivKviza = stringValue.getString("stringValue");
                            if (nazivKviza.equals("Dodaj kviz")) continue;
                            JSONObject referenceValue = fields.getJSONObject("idKategorije");
                            String idKategorijeKviza = referenceValue.getString("stringValue");
                            Kategorija kat = new Kategorija();
                            for (int k = 0; k < pocetneKategorijeIzBaze.size(); k++) {
                                if (idKategorijeKviza.equals(pocetneKategorijeIzBaze.get(k).first)) {
                                    kat = pocetneKategorijeIzBaze.get(k).second;
                                    break;
                                }
                            }

                            JSONObject pitt = fields.getJSONObject("pitanja");
                            JSONObject arrayValue = pitt.getJSONObject("arrayValue");
                            if (!arrayValue.toString().equals("{}")) {
                                JSONArray values = arrayValue.getJSONArray("values");
                                ArrayList<String> trenutniIdeviPitanja = new ArrayList<>();
                                for (int j = 0; j < values.length(); j++) {
                                    JSONObject item = values.getJSONObject(j);
                                    String pit = item.getString("stringValue");
                                    trenutniIdeviPitanja.add(pit);
                                }
                                ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                                for (int s = 0; s < pocetnaPitanjaIzBaze.size(); s++) {
                                    for (int h = 0; h < trenutniIdeviPitanja.size(); h++) {
                                        if (trenutniIdeviPitanja.get(h).equals(pocetnaPitanjaIzBaze.get(s).first)) {
                                            pitanjaZaKviz.add(pocetnaPitanjaIzBaze.get(s).second);
                                        }
                                    }
                                }
                                trenutniIdeviPitanja.clear();
                                Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                                filterKvizovi.add(trenutniKviz);
                            } else {
                                ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                                Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                                filterKvizovi.add(trenutniKviz);
                            }
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            ar.processFinish();
        }
    }

    public class KlasaUcitajBazu extends AsyncTask<String, Void, Void> {

        AsyncResponse ar = null;

        public KlasaUcitajBazu(AsyncResponse asyncResponse) {
            this.ar = asyncResponse;
        }

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);
                String urlKategorije = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Kategorije?access_token=";
                URL urlObjKategorija = new URL(urlKategorije + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connectionKategorija = (HttpURLConnection) urlObjKategorija.openConnection();
                connectionKategorija.connect();
                InputStream odgovorKategorija = connectionKategorija.getInputStream();
                StringBuilder responseKategorija = null;
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovorKategorija, "utf-8"))
                ) {
                    responseKategorija = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        responseKategorija.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR KATEGORIJA: ", responseKategorija.toString());
                }
                Kategorija trenutnaKategorija = new Kategorija();
                String rezultatKategorija = responseKategorija.toString();
                if (!rezultatKategorija.equals("{}")) {
                    JSONObject jo = new JSONObject(rezultatKategorija);
                    JSONArray documents = jo.getJSONArray("documents");
                    for (int i = 0; i < documents.length(); i++) {
                        JSONObject doc = documents.getJSONObject(i);
                        String nameKategorije = doc.getString("name");
                        int brojac1 = 0;
                        for (int kat = 0; kat < nameKategorije.length(); kat++) {
                            if (nameKategorije.charAt(kat) == '/') {
                                brojac1++;
                            }
                            if (brojac1 == 6) {
                                nameKategorije = nameKategorije.substring(++kat, nameKategorije.length());
                                break;
                            }
                        }
                        JSONObject fields = doc.getJSONObject("fields");
                        JSONObject stringValue = fields.getJSONObject("naziv");
                        String nazivKategorije = stringValue.getString("stringValue");
                        if (nazivKategorije.equals("Svi")) continue;
                        if (nazivKategorije.equals("Dodaj kategoriju")) continue;
                        JSONObject integerValue = fields.getJSONObject("idIkonice");
                        int idIkoniceKategorije = integerValue.getInt("integerValue");
                        trenutnaKategorija = new Kategorija(nazivKategorije, String.valueOf(idIkoniceKategorije));
                        pocetneKategorijeIzBaze.add(new Pair<String, Kategorija>(nameKategorije, trenutnaKategorija));
                        kategorije.add(trenutnaKategorija);
                    }
                }

                String urlPitanja = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Pitanja?access_token=";
                URL urlObjPitanja = new URL(urlPitanja + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connectionPitanja = (HttpURLConnection) urlObjPitanja.openConnection();
                connectionPitanja.connect();
                InputStream odgovorPitanja = connectionPitanja.getInputStream();
                StringBuilder responsePitanja = null;
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovorPitanja, "utf-8"))
                ) {
                    responsePitanja = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        responsePitanja.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR PITANJA: ", responsePitanja.toString());
                }
                String rezultatPitanja = responsePitanja.toString();
                if (!rezultatPitanja.equals("{}")) {
                    JSONObject joPitanja = new JSONObject(rezultatPitanja);
                    JSONArray documentsPitanja = joPitanja.getJSONArray("documents");
                    for (int i = 0; i < documentsPitanja.length(); i++) {
                        JSONObject doc = documentsPitanja.getJSONObject(i);
                        String namePitanja = doc.getString("name");
                        int brojac2 = 0;
                        for (int pit = 0; pit < namePitanja.length(); pit++) {
                            if (namePitanja.charAt(pit) == '/') {
                                brojac2++;
                            }
                            if (brojac2 == 6) {
                                namePitanja = namePitanja.substring(++pit, namePitanja.length());
                                break;
                            }
                        }
                        JSONObject fields = doc.getJSONObject("fields");
                        JSONObject stringValue = fields.getJSONObject("naziv");
                        String nazivPitanja = stringValue.getString("stringValue");
                        if (nazivPitanja.equals("Dodaj pitanje")) continue;
                        JSONObject integerValue = fields.getJSONObject("indexTacnog");
                        int indexTacnog = integerValue.getInt("integerValue");
                        JSONObject odgg = fields.getJSONObject("odgovori");
                        JSONObject arrayValue = odgg.getJSONObject("arrayValue");
                        JSONArray values = arrayValue.getJSONArray("values");
                        ArrayList<String> trenutnabazaOdgovori = new ArrayList<>();
                        for (int j = 0; j < values.length(); j++) {
                            JSONObject item = values.getJSONObject(j);
                            String odg = item.getString("stringValue");
                            trenutnabazaOdgovori.add(odg);
                        }
                        String trenutniTacanOdgovorBaza = "";
                        for (int j = 0; j < trenutnabazaOdgovori.size(); j++) {
                            if (j == indexTacnog) {
                                trenutniTacanOdgovorBaza = trenutnabazaOdgovori.get(j);
                                break;
                            }
                        }
                        Pitanje trenutnoPitanje = new Pitanje(nazivPitanja, nazivPitanja, trenutnabazaOdgovori, trenutniTacanOdgovorBaza);
                        pocetnaPitanjaIzBaze.add(new Pair<String, Pitanje>(namePitanja, trenutnoPitanje));
                    }
                }

                String urlKvizovi = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Kvizovi?access_token=";
                URL urlObjKvizovi = new URL(urlKvizovi + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connectionKvizovi = (HttpURLConnection) urlObjKvizovi.openConnection();
                connectionKvizovi.connect();
                InputStream odgovorKvizovi = connectionKvizovi.getInputStream();
                StringBuilder responseKvizovi = null;
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovorKvizovi, "utf-8"))
                ) {
                    responseKvizovi = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        responseKvizovi.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR KVIZOVI: ", responseKvizovi.toString());
                }
                String rezultatKvizovi = responseKvizovi.toString();
                if (!rezultatKvizovi.equals("{}")) {
                    JSONObject joKvizovi = new JSONObject(rezultatKvizovi);
                    JSONArray documentsKvizovi = joKvizovi.getJSONArray("documents");
                    for (int i = 0; i < documentsKvizovi.length(); i++) {
                        JSONObject doc = documentsKvizovi.getJSONObject(i);
                        String nameKviza = doc.getString("name");
                        int brojac3 = 0;
                        for (int kv = 0; kv < nameKviza.length(); kv++) {
                            if (nameKviza.charAt(kv) == '/') {
                                brojac3++;
                            }
                            if (brojac3 == 6) {
                                nameKviza = nameKviza.substring(++kv, nameKviza.length());
                                break;
                            }
                        }
                        JSONObject fields = doc.getJSONObject("fields");
                        JSONObject stringValue = fields.getJSONObject("naziv");
                        String nazivKviza = stringValue.getString("stringValue");
                        if (nazivKviza.equals("Dodaj kviz")) continue;
                        JSONObject referenceValue = fields.getJSONObject("idKategorije");
                        String idKategorijeKviza = referenceValue.getString("stringValue");
                        Kategorija kat = new Kategorija();
                        for (int k = 0; k < pocetneKategorijeIzBaze.size(); k++) {
                            if (idKategorijeKviza.equals(pocetneKategorijeIzBaze.get(k).first)) {
                                kat = pocetneKategorijeIzBaze.get(k).second;
                                break;
                            }
                        }
                        if(kat.getNaziv().length() == 0) kat.setNaziv("Svi");
                        JSONObject pitt = fields.getJSONObject("pitanja");
                        JSONObject arrayValue = pitt.getJSONObject("arrayValue");
                        if (!arrayValue.toString().equals("{}")) {
                            JSONArray values = arrayValue.getJSONArray("values");
                            ArrayList<String> trenutniIdeviPitanja = new ArrayList<>();
                            for (int j = 0; j < values.length(); j++) {
                                JSONObject item = values.getJSONObject(j);
                                String pit = item.getString("stringValue");
                                trenutniIdeviPitanja.add(pit);
                            }
                            ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                            for (int s = 0; s < pocetnaPitanjaIzBaze.size(); s++) {
                                for (int h = 0; h < trenutniIdeviPitanja.size(); h++) {
                                    if (trenutniIdeviPitanja.get(h).equals(pocetnaPitanjaIzBaze.get(s).first)) {
                                        pitanjaZaKviz.add(pocetnaPitanjaIzBaze.get(s).second);
                                    }
                                }
                            }
                            trenutniIdeviPitanja.clear();
                            Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                            pocetniKvizoviIzBaze.add(new Pair<String, Kviz>(nameKviza, trenutniKviz));
                            kvizovi.add(kvizovi.size() - 1, trenutniKviz);
                            validacijaKvizova.add(trenutniKviz);
                            imaDodajPitanje = true;
                        } else {
                            ArrayList<Pitanje> pitanjaZaKviz = new ArrayList<>();
                            Kviz trenutniKviz = new Kviz(nazivKviza, pitanjaZaKviz, kat);
                            pocetniKvizoviIzBaze.add(new Pair<String, Kviz>(nameKviza, trenutniKviz));
                            kvizovi.add(kvizovi.size() - 1, trenutniKviz);
                            validacijaKvizova.add(trenutniKviz);
                            imaDodajPitanje = true;
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void string) {
            ar.processFinish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi_akt);
        lvKvizovi = (ListView) findViewById(R.id.lvKvizovi);
        if (kvizovi.size() == 0) {
            new KlasaUcitajBazu(new AsyncResponse() {
                @Override
                public void processFinish() {
                    //kvizovi.addAll(kvizovi.size() - 1, kvizovi);
                    if (lvKvizovi != null) {
                        adapter.notifyDataSetChanged();
                        adapterKategorija.notifyDataSetChanged();
                    } else {
                        Bundle arg = new Bundle();
                        DetailFrag df = new DetailFrag();
                        arg.putParcelableArrayList("kvizovi", kvizovi);
                        df.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, df).commitAllowingStateLoss();
                        ListaFrag df2 = new ListaFrag();
                        arg.putSerializable("sveKategorije", kategorije);
                        df2.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, df2).commitAllowingStateLoss();
                    }
                }
            }).execute();
        }
        if (lvKvizovi != null) {
            spPostojeceKategorije = (Spinner) findViewById(R.id.spPostojeceKategorije);
            Resources res = getResources();
            boolean imaSvi = false;
            for (int i = 0; i < kategorije.size(); i++) {
                if (kategorije.get(i).getNaziv().equals("Svi")) {
                    imaSvi = true;
                }
            }
            if (!imaSvi) {
                kategorije.add(new Kategorija("Svi"));
            }
            final Kategorija svi = kategorije.get(0);
            validacijaKvizova.addAll(kvizovi);
            boolean imaDodaj = false;
            for (int i = 0; i < kvizovi.size(); i++) {
                if (kvizovi.get(i).getNaziv().equals("Dodaj kviz")) imaDodaj = true;
            }
            if (!imaDodaj) kvizovi.add(new Kviz("Dodaj kviz"));
            adapter = new KvizAdapter(this, kvizovi, res);
            lvKvizovi.setAdapter(adapter);
            adapterKategorija = new KategorijeAdapter(this, kategorije, res);
            spPostojeceKategorije.setAdapter(adapterKategorija);

            spPostojeceKategorije.setSelected(false);
            spPostojeceKategorije.setSelection(0, true);
            spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    if (kategorije.get(spPostojeceKategorije.getSelectedItemPosition()).getNaziv().equals(svi.getNaziv())) {
                        filtrirano = false;
                        Resources res = getResources();
                        adapter = new KvizAdapter(KvizoviAkt.this, kvizovi, res);
                        lvKvizovi.setAdapter(adapter);
                    } else {
                        String idKategorijeZaFiltriranje = "";
                        String kategorijaIzSpinneraNaziv = kategorije.get(spPostojeceKategorije.getSelectedItemPosition()).getNaziv();
                        for (int i = 0; i < pocetneKategorijeIzBaze.size(); i++) {
                            if (kategorijaIzSpinneraNaziv.equals(pocetneKategorijeIzBaze.get(i).second.getNaziv())) {
                                idKategorijeZaFiltriranje = pocetneKategorijeIzBaze.get(i).first;
                                break;
                            }
                        }

                        new FiltrirajKvizoveKlasa(new AsyncResponse() {
                            @Override
                            public void processFinish() {
                                filtrirano = true;
                                filterKvizovi.add(new Kviz("Dodaj kviz"));
                                Resources res = getResources();
                                adapter = new KvizAdapter(KvizoviAkt.this, filterKvizovi, res);
                                lvKvizovi.setAdapter(adapter);
                            }
                        }).execute(idKategorijeZaFiltriranje);
                        filterKvizovi = new ArrayList<Kviz>();
                    }
                }

                public void onNothingSelected(AdapterView<?> arg0) {
                    filtrirano = false;
                    Resources res = getResources();
                    adapter = new KvizAdapter(KvizoviAkt.this, kvizovi, res);
                    lvKvizovi.setAdapter(adapter);
                }
            });

            lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (!filtrirano) {
                        if (position != kvizovi.size() - 1) {
                            Intent myIntent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                            myIntent.putExtra("nazivKviza", kvizovi.get(position).getNaziv());
                            myIntent.putExtra("pitanja", kvizovi.get(position).getPitanja());
                            KvizoviAkt.this.startActivityForResult(myIntent, 2);
                        }
                    } else {
                        if (position != filterKvizovi.size() - 1) {
                            Intent myIntent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                            myIntent.putExtra("nazivKviza", filterKvizovi.get(position).getNaziv());
                            myIntent.putExtra("pitanja", filterKvizovi.get(position).getPitanja());
                            KvizoviAkt.this.startActivityForResult(myIntent, 2);
                        }
                    }
                }
            });

            lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    if (!filtrirano) {
                        if (position == kvizovi.size() - 1) {
                            Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            KvizoviAkt.this.startActivityForResult(myIntent, 0);
                        } else {
                            Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            myIntent.putExtra("nazivKviza", kvizovi.get(position).getNaziv());
                            myIntent.putExtra("kategorija", kvizovi.get(position).getKategorija());
                            myIntent.putExtra("pitanja", kvizovi.get(position).getPitanja());
                            pozicija = position;
                            KvizoviAkt.this.startActivityForResult(myIntent, 1);
                        }
                    } else {
                        if (position == filterKvizovi.size() - 1) {
                            Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            KvizoviAkt.this.startActivityForResult(myIntent, 0);
                        } else {
                            Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                            myIntent.putExtra("nazivKviza", filterKvizovi.get(position).getNaziv());
                            myIntent.putExtra("kategorija", filterKvizovi.get(position).getKategorija());
                            myIntent.putExtra("pitanja", filterKvizovi.get(position).getPitanja());
                            pozicija = position;
                            KvizoviAkt.this.startActivityForResult(myIntent, 1);
                        }
                    }
                    //new Klasa().execute();
                    return true;
                }
            });
        } else {
            //validacijaKvizova = new ArrayList<>();
            if (kvizovi.size() == 0) {
                kvizovi.add(new Kviz("Dodaj kviz"));
            }
            FragmentManager fm = getSupportFragmentManager();
            FrameLayout lista = (FrameLayout) findViewById(R.id.listPlace);

            if (lista != null) {
                ListaFrag fd = (ListaFrag) fm.findFragmentById(R.id.listPlace);
                if (fd == null) {
                    fd = new ListaFrag();
                    Bundle arg = new Bundle();
                    ArrayList<Kategorija> sveKategorije = kategorije;
                    boolean imaSvi = false;
                    for (int i = 0; i < sveKategorije.size(); i++) {
                        if (sveKategorije.get(i).getNaziv().equals("Svi")) {
                            imaSvi = true;
                        }
                    }
                    if (!imaSvi) sveKategorije.add(new Kategorija("Svi"));
                    arg.putSerializable("sveKategorije", sveKategorije);
                    fd.setArguments(arg);
                    fm.beginTransaction().replace(R.id.listPlace, fd).commit();
                } else {
                    fm.popBackStack(null, android.support.v4.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }
            }

            FrameLayout detalji = (FrameLayout) findViewById(R.id.detailPlace);

            if (detalji != null) {
                DetailFrag fd = (DetailFrag) fm.findFragmentById(R.id.detailPlace);
                if (fd == null) {
                    fd = new DetailFrag();
                    Bundle arg = new Bundle();
                    arg.putParcelableArrayList("kvizovi", kvizovi);
                    fd.setArguments(arg);
                    fm.beginTransaction().replace(R.id.detailPlace, fd).commit();
                } else {
                    fm.popBackStack(null, android.support.v4.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                if (lvKvizovi != null) {
                    if (!filtrirano) {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("Kategorija"));
                        kvizovi.add(kvizovi.size() - 1, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        validacijaKvizova.add(new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        adapter.notifyDataSetChanged();
                    } else {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("Kategorija"));
                        filterKvizovi.add(filterKvizovi.size() - 1, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        kvizovi.add(kvizovi.size() - 1, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        validacijaKvizova.clear();
                        validacijaKvizova.addAll(kvizovi);
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    if (!filtrirano2) {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("Kategorija"));
                        kvizovi.add(kvizovi.size() - 1, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        validacijaKvizova.add(new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        Bundle arg = new Bundle();
                        DetailFrag df = new DetailFrag();
                        arg.putParcelableArrayList("kvizovi", kvizovi);
                        df.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, df).commitAllowingStateLoss();
                        ListaFrag df2 = new ListaFrag();
                        arg.putSerializable("sveKategorije", kategorije);
                        df2.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, df2).commitAllowingStateLoss();
                    } else {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("Kategorija"));
                        filterKvizovi2.add(filterKvizovi2.size() - 1, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        kvizovi.add(kvizovi.size() - 1, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        validacijaKvizova.clear();
                        validacijaKvizova.addAll(kvizovi);
                        Bundle arg = new Bundle();
                        DetailFrag df = new DetailFrag();
                        arg.putParcelableArrayList("kvizovi", filterKvizovi2);
                        df.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, df).commitAllowingStateLoss();
                        ListaFrag df2 = new ListaFrag();
                        arg.putSerializable("sveKategorije", kategorije);
                        df2.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, df2).commitAllowingStateLoss();
                    }
                }
            } else if (resultCode == RESULT_CANCELED) {
                if (lvKvizovi == null) {
                    Bundle arg = new Bundle();
                    ListaFrag df2 = new ListaFrag();
                    arg.putSerializable("sveKategorije", kategorije);
                    df2.setArguments(arg);
                    getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, df2).commitAllowingStateLoss();
                }
            }

        } else if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                if (lvKvizovi != null) {
                    if (!filtrirano) {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("kategorija"));
                        kvizovi.set(pozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        kvizKojiVracam = new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat);
                        validacijaKvizova.set(pozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        adapter.notifyDataSetChanged();
                    } else {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("kategorija"));
                        String naziv = filterKvizovi.get(pozicija).getNaziv();
                        filterKvizovi.set(pozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        kvizKojiVracam = new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat);
                        int novaPozicija = 0;
                        for (int i = 0; i < kvizovi.size() - 1; i++) {
                            if (kvizovi.get(i).getNaziv().equals(naziv)) {
                                novaPozicija = i;
                            }
                        }
                        kvizovi.set(novaPozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        validacijaKvizova.clear();
                        validacijaKvizova.addAll(kvizovi);
                        //validacijaKvizova.set(pozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        adapter.notifyDataSetChanged();
                    }
                } else {
                    if (!filtrirano2) {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("kategorija"));
                        kvizovi.set(pozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        kvizKojiVracam = new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat);
                        validacijaKvizova.set(pozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        Bundle arg = new Bundle();
                        DetailFrag df = new DetailFrag();
                        arg.putParcelableArrayList("kvizovi", kvizovi);
                        df.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, df).commitAllowingStateLoss();
                        ListaFrag df2 = new ListaFrag();
                        arg.putSerializable("sveKategorije", kategorije);
                        df2.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, df2).commitAllowingStateLoss();
                    } else {
                        Kategorija kat = ((Kategorija) data.getSerializableExtra("kategorija"));
                        String naziv = filterKvizovi2.get(pozicija).getNaziv();
                        filterKvizovi2.set(pozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        kvizKojiVracam = new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat);
                        int novaPozicija = 0;
                        for (int i = 0; i < kvizovi.size() - 1; i++) {
                            if (kvizovi.get(i).getNaziv().equals(naziv)) {
                                novaPozicija = i;
                            }
                        }
                        kvizovi.set(novaPozicija, new Kviz(data.getStringExtra("nazivKviza"), (ArrayList<Pitanje>) data.getSerializableExtra("pitanja"), kat));
                        validacijaKvizova.clear();
                        validacijaKvizova.addAll(kvizovi);
                        Bundle arg = new Bundle();
                        DetailFrag df = new DetailFrag();
                        arg.putParcelableArrayList("kvizovi", filterKvizovi2);
                        df.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, df).commitAllowingStateLoss();
                        ListaFrag df2 = new ListaFrag();
                        arg.putSerializable("sveKategorije", kategorije);
                        df2.setArguments(arg);
                        getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, df2).commitAllowingStateLoss();
                    }
                }
            } else if (resultCode == RESULT_CANCELED) {
                if (lvKvizovi == null) {
                    Bundle arg = new Bundle();
                    ListaFrag df2 = new ListaFrag();
                    arg.putSerializable("sveKategorije", kategorije);
                    df2.setArguments(arg);
                    getSupportFragmentManager().beginTransaction().replace(R.id.listPlace, df2).commitAllowingStateLoss();
                }
                else{
                    pocetniKvizoviIzBaze.add(new Pair<String, Kviz>(DodajKvizAkt.idKvizaZaEdit, kvizKojiVracam));
                }
            }
        } else if (requestCode == 2) {

        }
    }

    @Override
    public void pressLV(ArrayList<Kviz> k) {
        Bundle arg = new Bundle();
        DetailFrag df = new DetailFrag();
        arg.putParcelableArrayList("kvizovi", k);
        df.setArguments(arg);
        getSupportFragmentManager().beginTransaction().replace(R.id.detailPlace, df).commit();
    }
}
