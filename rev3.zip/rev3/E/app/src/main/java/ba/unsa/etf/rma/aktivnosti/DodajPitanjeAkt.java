package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {
    private EditText etNaziv;
    private EditText etOdgovor;
    private ListView lvOdgovori;
    private Button btnDodajOdgovor;
    private Button btnDodajTacan;
    private Button btnDodajPitanje;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> odgovori = new ArrayList<>();
    private Pitanje trenutnoPitanje = new Pitanje();
    private boolean ima = false;
    private String tacanOdgovor = "";
    private boolean imaTacan = false;
    private boolean imaOdgovor = false;
    private boolean imaTacanOdgovor = false;
    public static int pozicijaTacnog = 0;
    public static ArrayList<String> idPitanja = new ArrayList<String>();

    public class KlasaPitanja extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            InputStream is = getResources().openRawResource(R.raw.secret);
            try {
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                System.out.println("SADA JE TOKEN: " + TOKEN);
                String url = "https://firestore.googleapis.com/v1/projects/fir-konzolaid/databases/(default)/documents/Pitanja?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
                connection.setDoOutput(true);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");

                String dokument = "{ \"fields\": { \"naziv\": {\"stringValue\":\"" + etNaziv.getText().toString() + "\"} , \"odgovori\" : { \"arrayValue\" : { \"values\" : [";
                for (int i = 0; i < odgovori.size(); i++) {
                    if (i != odgovori.size() - 1) {
                        dokument += "{\"stringValue\" : \"" + odgovori.get(i) + "\"},";
                    } else {
                        dokument += "{\"stringValue\" : \"" + odgovori.get(i) + "\"}";
                    }
                }
                dokument += "]}} , \"indexTacnog\": {\"integerValue\":\"" + pozicijaTacnog + "\"}}}";
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = connection.getResponseCode();
                InputStream odgovor = connection.getInputStream();
                StringBuilder response = null;
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(odgovor, "utf-8"))
                ) {
                    response = new StringBuilder();
                    String rensponseLine = null;
                    while ((rensponseLine = br.readLine()) != null) {
                        response.append(rensponseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                }
                String rezultat = response.toString();
                JSONObject jo = new JSONObject(rezultat);
                String name = jo.getString("name");
                JSONObject fields = jo.getJSONObject("fields");
                JSONObject stringValue = fields.getJSONObject("naziv");
                String naziv = stringValue.getString("stringValue");
                //System.out.println("NAZIVVVV:   " + naziv);
                JSONObject integerValue = fields.getJSONObject("indexTacnog");
                int indexTacnog = integerValue.getInt("integerValue");
                //System.out.println("TACAN ODGOVORRR BROJ:   " + indexTacnog);
                JSONObject odgg = fields.getJSONObject("odgovori");
                JSONObject arrayValue = odgg.getJSONObject("arrayValue");
                JSONArray values = arrayValue.getJSONArray("values");
                ArrayList<String> bazaOdgovori = new ArrayList<>();
                for (int i = 0; i < values.length(); i++) {
                    JSONObject item = values.getJSONObject(i);
                    String odg = item.getString("stringValue");
                    bazaOdgovori.add(odg);
                }
                String tacanOdgovorBaza = "";
                for (int i = 0; i < bazaOdgovori.size(); i++) {
                    if (i == indexTacnog) {
                        tacanOdgovorBaza = bazaOdgovori.get(i);
                        break;
                    }
                }
                int brojac = 0;
                for (int i = 0; i < name.length(); i++) {
                    if (name.charAt(i) == '/') {
                        brojac++;
                    }
                    if (brojac == 6) {
                        name = name.substring(++i, name.length());
                        break;
                    }
                }
                idPitanja.add(name);
                Pitanje novoBazaPitanje = new Pitanje(naziv, naziv, bazaOdgovori, tacanOdgovorBaza);
                KvizoviAkt.pocetnaPitanjaIzBaze.add(new Pair<String, Pitanje>(name, novoBazaPitanje));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        etOdgovor = (EditText) findViewById(R.id.etOdgovor);
        lvOdgovori = (ListView) findViewById(R.id.lvOdgovori);
        btnDodajOdgovor = (Button) findViewById(R.id.btnDodajOdgovor);
        btnDodajTacan = (Button) findViewById(R.id.btnDodajTacan);
        btnDodajPitanje = (Button) findViewById(R.id.btnDodajPitanje);
        etNaziv.setHint("Naziv kviza - INPUT");
        etOdgovor.setHint("Odgovor");
        Resources res = getResources();
        adapter = new ArrayAdapter<String>(this, R.layout.element_liste, R.id.Itemname, odgovori) {
            @Override
            public View getView(int position, @Nullable View convertView, @Nullable ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                String s = odgovori.get(position);
                TextView naziv = (TextView) view.findViewById(R.id.Itemname);
                ImageView ikona = (ImageView) view.findViewById(R.id.icon);
                ikona.setImageResource(R.drawable.slika);
                naziv.setText(s);
                if (s.equals(tacanOdgovor)) {
                    naziv.setBackgroundColor(Color.GREEN);
                    pozicijaTacnog = position;
                } else {
                    naziv.setBackgroundColor(0);
                }
                return view;
            }
        };

        lvOdgovori.setAdapter(adapter);

        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (odgovori.get(position).equals(tacanOdgovor)) btnDodajTacan.setEnabled(true);
                odgovori.remove(position);
                adapter.notifyDataSetChanged();
            }
        });

        btnDodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (String odg : odgovori) {
                    if (odg.equals(etOdgovor.getText().toString())) {
                        imaOdgovor = true;
                    }
                }
                if (imaOdgovor) {
                    etOdgovor.setBackgroundColor(Color.RED);
                    imaOdgovor = false;
                } else if (etOdgovor.getText().toString().equals("")) {
                    etOdgovor.setBackgroundColor(Color.RED);
                } else {
                    etOdgovor.setBackgroundColor(Color.WHITE);
                    odgovori.add(etOdgovor.getText().toString());
                    adapter.notifyDataSetChanged();
                    etOdgovor.setText("");
                }
            }
        });

        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (String odg : odgovori) {
                    if (odg.equals(etOdgovor.getText().toString())) {
                        imaTacanOdgovor = true;
                    }
                }
                if (imaTacanOdgovor) {
                    etOdgovor.setBackgroundColor(Color.RED);
                    imaTacanOdgovor = false;
                } else if (etOdgovor.getText().toString().equals("")) {
                    etOdgovor.setBackgroundColor(Color.RED);
                } else {
                    etOdgovor.setBackgroundColor(Color.WHITE);
                    odgovori.add(etOdgovor.getText().toString());
                    tacanOdgovor = etOdgovor.getText().toString();
                    trenutnoPitanje.setTacan(etOdgovor.getText().toString());
                    adapter.notifyDataSetChanged();
                    etOdgovor.setText("");
                    btnDodajTacan.setEnabled(false);
                }
            }
        });

        btnDodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < DodajKvizAkt.validacijaPitanja.size(); i++) {
                    if (DodajKvizAkt.validacijaPitanja.get(i).getNaziv().equals(etNaziv.getText().toString())) {
                        ima = true;
                    }
                }
                for (int i = 0; i < KvizoviAkt.pocetnaPitanjaIzBaze.size(); i++) {
                    if (KvizoviAkt.pocetnaPitanjaIzBaze.get(i).second.getNaziv().equals(etNaziv.getText().toString())) {
                        ima = true;
                    }
                }
                for (String odgovor : odgovori) {
                    if (odgovor.equals(tacanOdgovor)) imaTacan = true;
                }
                if (etNaziv.getText().toString().length() == 0 || ima) {
                    etNaziv.setBackgroundColor(Color.RED);
                    ima = false;
                } else if (!imaTacan) {
                    //ne radi nista, nema tacnog odgovora
                } else {
                    new KlasaPitanja().execute();
                    etNaziv.setBackgroundColor(Color.WHITE);
                    trenutnoPitanje.setNaziv(etNaziv.getText().toString());
                    trenutnoPitanje.setTekstPitanja(etNaziv.getText().toString());
                    trenutnoPitanje.setOdgovori(odgovori);
                    //Pitanje pitanje = new Pitanje(etNaziv.getText().toString(), etNaziv.getText().toString(), odgovori, tacanOdgovor);
                    Intent returnIntent = getIntent();
                    returnIntent.putExtra("nazivPitanja", trenutnoPitanje.getNaziv());
                    returnIntent.putExtra("tekstPitanja", trenutnoPitanje.getTekstPitanja());
                    returnIntent.putExtra("odgovori", trenutnoPitanje.getOdgovori());
                    returnIntent.putExtra("isTacan", trenutnoPitanje.getTacan());
                    setResult(RESULT_OK, returnIntent);
                    finish();
                }
            }
        });
    }
}
